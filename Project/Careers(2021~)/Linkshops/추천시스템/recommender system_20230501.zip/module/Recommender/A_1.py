import numpy as np
import pandas as pd
from pandas import DataFrame, Series
import time
from utility import utils
from utility.utils import retrieval_wishes
from engine import profiling_engine
import scipy

from sklearn.metrics.pairwise import cosine_similarity

def A_1ALgorithm(target_product_list,
                 product_list, 
                 product_profile_Id,
                 product_profile_numpy, 
                 favorite_pivot_Id_set, 
                 productId_set, 
                 productId_dict,
                 wishes_coo,
                 drop_duplicated = True):
    start_time = time.time()
    Id_product_profile = {j : i for i,j in product_profile_Id.items()}
    retrieval_dict = dict()
    params_dict = dict()
    for num in range(0, len(product_list)):
        # 구매 내역이 있는 상품들만 추려내기
        temp_id = [product_profile_Id[i] 
                    for i in set(product_profile_Id.keys()).intersection(product_list[num])]
        temp_target_id = [product_profile_Id[i] 
                            for i in set(product_profile_Id.keys()).intersection(target_product_list[num])]
        # 중복 제거 = true면 타겟 바이어가 구매한 상품은 product_list에서 제외
        if drop_duplicated :
            temp_id = np.array(temp_id)[[i not in temp_target_id for i in temp_id]]
            temp = product_profile_numpy[temp_id.tolist()]
        else :
            temp = product_profile_numpy[temp_id]
        # 카테고리 행렬에서 타겟 상품 리스트의 데이터 추출
        temp_target = product_profile_numpy[temp_target_id]
        if (temp_target.shape[0] == 0):
            retrieval_dict.update({favorite_pivot_Id_set[num] : ['no_target']})
            params_dict.update({favorite_pivot_Id_set[num] : ['no_target']})
            continue
        temp = np.concatenate([temp_target, temp])
        # 코사인 유사도를 구한 후 대각성분을 0으로 만듦
        csm = cosine_similarity(temp)
        csm -= np.eye(temp.shape[0])
        # 동일 카테고리 추출부
        result, param = profiling_engine(csm, 
                                         [i for i in range(0, temp_target.shape[0])], 
                                         k = 9999,
                                         threshold = 0.9,
                                         drop_ind=[i for i in range(0, temp_target.shape[0])],
                                         core = None)
        # 인덱스를 상품ID로 변환한 후, 위시리스트에 존재하는 상품ID만 Intersection하여 담기
        result = [list(productId_set.intersection([int(Id_product_profile[temp_id[int(j)]])
                                                   for j in i if np.isnan(j) == False]))
                  for i in (result - temp_target.shape[0])]
        # 타겟 바이어의 상품ID에도 동일한 처리를 수행
        target_ids = pd.merge(Series([int(Id_product_profile[int(i)]) for i in temp_target_id if np.isnan(i) == False],
                                     name = 'productId').reset_index(),
                              Series(list(productId_set), name = 'productId').astype('int'),
                              on = 'productId',
                              how = 'inner')
        if len(target_ids) == 0:
            retrieval_dict.update({favorite_pivot_Id_set[num] : ['no_target']})
            params_dict.update({favorite_pivot_Id_set[num] : ['no_target']})
            continue
        elif len(result) == 0:
            retrieval_dict.update({favorite_pivot_Id_set[num] : ['no_prod']})
            params_dict.update({favorite_pivot_Id_set[num] : ['no_prod']})
            continue

        result_dict = dict()
        for i in target_ids.iterrows():
            origin_index = i[1]['index']
            prod_id = i[1]['productId']
            result_dict.update({prod_id : result[origin_index]})

        final_result = dict()
        final_param = dict()
        # 도출된 타겟 상품ID목록, 상품ID 목록으로 순회
        for vec, ind in zip(result_dict.values(), result_dict.keys()):
            # 상품ID -> 위시리스트 인덱스 변환 후, 위시리스트 행렬에서 값 추출
            wishes_target = wishes_coo[productId_dict[int(ind)]]
            wishes_product = [wishes_coo[productId_dict[int(i)]] for i in vec]
            if (wishes_target.shape[0] == 0) | (len(wishes_product) == 0):
                retrieval_dict.update({favorite_pivot_Id_set[num] : ['no_wishlist']})
                params_dict.update({favorite_pivot_Id_set[num] : ['no_wishlist']})
                continue
            wishes_temp = np.vstack([wishes_target, wishes_product])
            # 코사인 유사도 구하고 대각성분 0으로 만들기
            csm = cosine_similarity(wishes_temp)
            csm -= np.eye(csm.shape[0])
            result, param = profiling_engine(csm,
                                            [0],
                                            k = 30,
                                            threshold = 0,
                                            drop_ind=[0],
                                            core = None)
            # 인덱스를 상품ID로 재변환
            result = [result_dict[ind][int(i) - 1] for i in result[0] if (np.isnan(i) == False)]
            final_result.update({ind : result})
            final_param.update({ind : param})
        retrieval_dict.update({favorite_pivot_Id_set[num] : final_result})
        params_dict.update({favorite_pivot_Id_set[num] : final_param})
        if num % 10 == 0:
            print(num)
            print(time.time() - start_time)
    return retrieval_dict, params_dict
