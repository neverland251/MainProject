import numpy as np
import pandas as pd
from pandas import DataFrame, Series
import time
from utility import utils
from utility.utils import retrieval_wishes
from engine import profiling_engine
import scipy

from sklearn.metrics.pairwise import cosine_similarity
def A_3ALgorithm(favorite_pivot,
                 result_buyer,
                 wishes_coo,
                 wishes_reduced_dict,
                 productId_dict,
                 IdBuyer_favorite_dict,
                 drop_duplicated = True):
    start_time = time.time()
    retrieval_dict = dict()
    params_dict = dict()
    for num in range(0, len(result_buyer)):
        # 단골 브랜드 피봇 테이블(favorite_pivot)에서 buyerId를 조회하여
        # 카테고리 전처리 테이블(favorite_pivot)에서 해당 바이어가 위시리스트 추가한 상품의 카테고리 정보 추출(wishes_reduced_dict)
        result_wishes_target = [retrieval_wishes(i, wishes_reduced_dict) for i in [favorite_pivot.iloc[num,0]]]
        # 상품ID별로 묶여있는 카테고리 테이블 평탄화(list flattened) 후 상품ID별 Unique
        result_wishes_target = [item for items in result_wishes_target for item in items]
        result_wishes_target = np.unique(result_wishes_target, axis = 0)
        if result_wishes_target.shape[0] > 0:
            result_wishes_target = result_wishes_target[np.where(result_wishes_target[:,0] != '0')]
        # 유사 바이어들도 위와 동일한 처리 수행
        result_wishes_prod = [retrieval_wishes(i, wishes_reduced_dict) for i in result_buyer[num]]
        result_wishes_prod = [item for items in result_wishes_prod for item in items]
        result_wishes_prod = np.unique(result_wishes_prod, axis = 0)
        if result_wishes_prod.shape[0] > 0:
            result_wishes_prod = result_wishes_prod[np.where(result_wishes_prod[:,0] != '0')]

        if (result_wishes_target.shape[0] == 0) & (result_wishes_prod.shape[0] == 0):
            retrieval_dict.update({favorite_pivot.iloc[num, 0] : ['no_target_and_prod']})
            params_dict.update({favorite_pivot.iloc[num, 0] : ['no_target_and_prod']})
            continue
        elif (result_wishes_target.shape[0] == 0):
            retrieval_dict.update({favorite_pivot.iloc[num, 0] : ['no_target']})
            params_dict.update({favorite_pivot.iloc[num, 0] : ['no_target']})
            continue

        elif (result_wishes_prod.shape[0] == 0):
            retrieval_dict.update({favorite_pivot.iloc[num, 0] : ['no_prod']})
            params_dict.update({favorite_pivot.iloc[num, 0] : ['no_prod']})
            continue
        # duplicated = True일시 타겟바이어가 추가한 상품과 동일한 유사바이어 상품은 리스트에서 제외
        if drop_duplicated :
            result_wishes_prod = np.array([i for i in result_wishes_prod if i[0] not in result_wishes_target[:,0]])
        # 카테고리값의 인덱스를 저장
        cols_dict = {j : i for i,j in enumerate(np.unique(np.vstack([result_wishes_target,result_wishes_prod])[:,2]))}
        # 카테고리 인덱스의 최댓값을 저장한다(70줄 참조)
        cols_ind_max = np.max(list(cols_dict.values()))
        # 상품ID의 인덱스를 저장
        rows_dict_prod = {j : i for i,j in enumerate(np.unique(result_wishes_prod[:,0]))}
        # 상품ID -> row, 카테고리값 -> col, [1,1,1......1] -> value
        row = [rows_dict_prod[i] for i in result_wishes_prod[:,0]]
        col = [cols_dict[i] for i in result_wishes_prod[:,2]]
        values = result_wishes_prod[:,1].astype('int')

        rows_dict_target = {j : i for i,j in enumerate(np.unique(result_wishes_target[:,0]))}
        # sparse_matrix로 변환함과 동시에 피보팅을 수행한다
        result_wishes_prod = scipy.sparse.coo_matrix((values, (row, col)))
        result_wishes_prod = result_wishes_prod.astype('float64')
        result_wishes_prod = result_wishes_prod.toarray()
        # -----------
        # 각각의 상품ID가 갖고있는 카테고리 정보가 다르다
        # 이를 그냥 냅두면 각 상품마다 제각각의 카테고리 인덱스 번호를 갖는다
        ## ex) 상품ID = 1234의 'Knit'는 인덱스가 23이나, 상품Id = 3245의 'Knit'는 인덱스가 37
        # 이를 통합해주고, 빈 공간은 np.zeros로 영행렬을 만들어 concat해준다
        result_wishes_prod = \
        np.hstack([result_wishes_prod,
                  np.zeros(
                          (result_wishes_prod.shape[0],
                           (cols_ind_max + 1) - result_wishes_prod.shape[1])
                           )]
                 )
        # -----------
        # 유사 바이어의 상품들에 대해서도 동일한 처리 수행
        row = [rows_dict_target[i] for i in result_wishes_target[:,0]]
        col = [cols_dict[i] for i in result_wishes_target[:,2]]
        values = result_wishes_target[:,1].astype('int')

        result_wishes_target = scipy.sparse.coo_matrix((values, (row, col)))
        result_wishes_target = result_wishes_target.astype('float64')
        result_wishes_target = result_wishes_target.toarray()
        result_wishes_target = \
        np.hstack([result_wishes_target,
                  np.zeros(
                          (result_wishes_target.shape[0],
                           (cols_ind_max + 1) - result_wishes_target.shape[1])
                           )]
                 )
        temp = np.vstack([result_wishes_target, result_wishes_prod])
        # 동일 카테고리 상품 추출
        csm = cosine_similarity(temp)
        csm -= np.eye(temp.shape[0])
        result, param = profiling_engine(csm,
                                  [i for i in range(0, result_wishes_target.shape[0])],
                                  k = 50,
                                  threshold = 0.9,
                                  drop_ind=[i for i in range(0, result_wishes_target.shape[0])],
                                  core = None)
        # 상품ID - 인덱스 딕셔너리를 키-밸류 반전하여 인덱스 - 상품ID 딕셔너리로 변환
        prod_dict_rows = {(j + result_wishes_target.shape[0]) :i for i,j in rows_dict_prod.items()}
        # result의 인덱스를 조회하여 상품ID로 변환
        result = [[prod_dict_rows[int(j)]  for j in i if np.isnan(j) == False]
                  for i in result]
        result_dict = {i:j for i,j in zip(rows_dict_target, result)}
        final_result = dict()
        final_param = dict()
        for vec, ind in zip(result_dict.values(), result_dict.keys()):
            # 위시리스트 피봇행렬에서 상품ID에 해당하는 정보를 조회
            wishes_temp = np.vstack([wishes_coo[productId_dict[int(ind)]],
                                    wishes_coo[[productId_dict[int(i)] for i in vec]]])
            if wishes_temp.shape[0] == 0:
                final_result.update({ind : ['no_wishlist']})
                final_param.update({ind : ['no_wishlist']})
                continue
            # 각 상품별 코사인 유사도를 구함
            csm = cosine_similarity(wishes_temp)
            csm -= np.eye(wishes_temp.shape[0])
            result, param = profiling_engine(csm,
                                      [0],
                                      k = 50,
                                      threshold = 0,
                                      drop_ind=[0],
                                      core = None)
            # 인덱스를 다시 상품ID로 전환
            result = [[vec[int(j) - 1] for j in i if np.isnan(j) == False] for i in result]
            final_result.update({ind : result[0]})
            final_param.update({ind : param})
        retrieval_dict.update({IdBuyer_favorite_dict[num] : final_result})
        params_dict.update({IdBuyer_favorite_dict[num] : final_param})
        if num % 10 == 0:
            print(num)
            print(time.time() - start_time)
    return retrieval_dict, params_dict