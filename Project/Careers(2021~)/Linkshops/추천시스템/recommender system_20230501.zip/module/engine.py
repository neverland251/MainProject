
import numpy as np
import time
import multiprocessing as mp
from utility import utils

def profiling_engine(csm,
                     target_ind_list,
                     k,
                     threshold = 0.8,
                     drop_ind = None,
                     core = 8):
    csm_mat = csm.copy()
    csm_mat = csm_mat[target_ind_list]

    threshold_below = np.where(csm_mat < threshold)
    csm_mat[threshold_below[0], threshold_below[1]] = np.nan
    if drop_ind is not None:
        csm_mat[:,drop_ind] = np.nan
        
    ind_not_nan = np.where(np.isnan(csm_mat) == False)
    list_ind = list()
    for i,j in zip(ind_not_nan[0], ind_not_nan[1]):
        list_ind.append([i,j])
    list_ind = np.array(list_ind)
    if len(list_ind) == 0:
        sorting_mat = np.zeros((len(target_ind_list), k))
        sorting_mat[sorting_mat == 0] = np.nan
        params = np.zeros((len(target_ind_list), k))
        params[params == 0] = np.nan    
        return sorting_mat, params

    if core is not None:
        args = ((csm_mat[i * round(csm_mat.shape[0]/core) : (i + 1) * round(csm_mat.shape[0]/core)],
                 list_ind,
                 i * round(csm_mat.shape[0]/core))
                 for i in range(core))
        with mp.Pool(core) as pool:
            sorting_mat = pool.starmap(utils.sorting_except_nan, args)
        sorting_mat = np.concatenate(sorting_mat)[:,0:k]
    else :
        sorting_mat = utils.sorting_except_nan(csm_mat, list_ind, 0)
        sorting_mat = np.stack(sorting_mat)[:,0:k]

    params = [csm[x[0], x[1][np.isnan(x[1]) == False].astype('int')] for x in zip(target_ind_list, sorting_mat)]
    return sorting_mat, params
