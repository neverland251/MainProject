import psycopg2
from pymongo import MongoClient

import pandas as pd
from pandas import DataFrame, Series
import numpy as np

class ConnectModule():
    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, client):
        self._phase = set()
        self._has_nosql = False
        self.client = client
        self.connect_inform = {'host_ip' : host_ip,
                               'DBname' : DBname,
                               'port' : port,
                               'username' : username,
                               'password' : password}
        self.connect(**self.connect_inform)

    def connect(self, host_ip, DBname, port, username, password):

        self.conn = psycopg2.connect(f"host={host_ip} " + (
                                f"port={port} ") + (
                                f"user={username} ") + (
                                f"password={password} ") + (
                                f"dbname={DBname}"))
        self.curs = self.conn.cursor()

        self.db_datamart = self.client['datamart']

    def __setattr__(self, name, value):
        if name == "NOSQL":
            self._has_nosql = True
        elif isinstance(value, dict):
            if any(['SQL' in value.keys()]):
                self._phase.add(name)
        super().__setattr__(name, value)

    def load_table(self, connect_close = True):
        for name in self._phase:
            SQL = self.__dict__[name]['SQL']
            columns = self.__dict__[name]['columns']
            while True:
                try:
                    self.curs.execute(SQL)
                    break
                except Exception as e:
                    print(e)
                    print('connection retry...')

                    self.connect(self.host_ip,
                                 self.DBname,
                                 self.port,
                                 self.username,
                                 self.password)
                    continue
            temp = DataFrame(self.curs)
            if temp.shape[0] >= 1:
                temp.columns = columns
            else:
                temp = DataFrame(columns=columns)
            self.__dict__[f'dataframe_{name}'] = temp
            print(f'Table : {name} Load Complete')

        if self._has_nosql:
            for name, value in self.__dict__['NOSQL'].items():
                collection = self.db_datamart[name]
                if isinstance(value['SQL'], list):
                    temp = DataFrame(collection.find(*value['SQL']))
                if isinstance(value['SQL'], dict):
                    temp = DataFrame(collection.find(value['SQL']))
                if any([True if i == 'columns' else False for i in value]):
                    if temp.shape[0] >= 1:
                        temp.columns = columns
                    else:
                        temp = DataFrame(columns=columns)
                self.__dict__[f'dataframe_{name}'] = temp
                print(f'NoSQLTable : {name} Load Complete')
        if connect_close:
            self.curs.close()
    def run(self):
        raise NotImplementedError()

    def delete_table(self, table_name, type_num, connect_close = True):
        self.connect(**self.connect_inform)
        psycopg2.extras.execute_values(self.curs,
                               f'DELETE FROM public.{table_name} WHERE type::integer = %s',
                               [[type_num]],
                               template=None)
        self.conn.commit()
        if connect_close:
            self.curs.close()
    def insert_table(self, table_name, tuples, connect_close = True):
        self.connect(**self.connect_inform)
        psycopg2.extras.execute_values(self.curs,
                               f'INSERT INTO public.{table_name} VALUES %s',
                               tuples,
                               template=None,
                               page_size=1000)
        self.conn.commit()
        if connect_close:
            self.curs.close()