import numpy as np
import pandas as pd
from pandas import DataFrame, Series
import math
import os

def sorting_except_nan(csm_mat, list_ind, init_num):
    sorting_mat = list()
    for num in range(csm_mat.shape[0]):
        not_nan_value = csm_mat[num][list_ind[list_ind[:,0] == (num + init_num)]][:,1]
        lower_ind = np.argsort(not_nan_value)[::-1]
        list_ind_reorder = list_ind[list_ind[:,0] == (num + init_num)][:,1][lower_ind]
        nan_mat = np.zeros(csm_mat.shape[1] - len(list_ind_reorder))
        nan_mat[nan_mat == 0] = np.nan
        sorting_mat.append(np.hstack([list_ind_reorder, list(nan_mat)]))
    return sorting_mat

def type_extractor(x, types, recursive=None):
    try:
        if recursive is None:
            return x[0][types]
        else:
            return type_extractor([x[0][types]],
                                  types=recursive)
    except:
        return 'NaN'

def retrieval_wishes(x, wishes_reduced_dict):
    try:
        return wishes_reduced_dict[x]

    except KeyError as e:
        return [['0', '0', '0']]

def softmax_function(x):
    max_val = np.max(x)
    denominator = np.sum(np.exp(x - max_val))
    numerator = np.exp(x - max_val)
    return numerator / denominator

def making_image_list(keys, values, params,orderseries_merchandise,
                      size = (200,150),
                      max_prod = 40):

    temp_total = DataFrame()
    for i,j,k in zip(keys, values, params):
        k = np.array(k)
        temp = DataFrame({'productId' : j,
                          'params' : k[np.isnan(k) == False]})
        temp['target_prod'] = i
        if len(j) == 0:
            temp = DataFrame({'target_prod' : i,
                              'productId' : [np.nan],
                              'params' : [np.nan]})
        temp_total = pd.concat([temp_total, temp])
    temp_total = temp_total.iloc[:max_prod]
    urls = pd.merge(orderseries_merchandise.astype({'productId' : int}),
                    Series(temp_total['target_prod'].unique(), name = 'productId', dtype = 'int')
                    )[['productId','images',]].drop_duplicates().values

    [os.system("curl http:" + i + f" > ./temp/target/{num}.jpg") for num, i in urls]
    frame_image = pd.concat([
                    DataFrame({'target_prod' : num,
                            'target_img' : [f'<img src=./temp/target/{num}.jpg + \
                             style="width:{size[0]}px;height:{size[1]}px;">']}) for num, i in urls])
    temp_total = pd.merge(temp_total,frame_image)
    urls = pd.merge(orderseries_merchandise.astype({'productId' : int}),
            Series(temp_total['productId'].dropna().unique(), name = 'productId', dtype = 'int')
            )[['productId','images','status']].drop_duplicates().values

    [os.system("curl http:" + i + f" > ./temp/retrieval/{num}.jpg") for num, i, status in urls]
    frame_image = pd.concat([
                    DataFrame({'productId' : num,
                            'product_img' : [f'<img src=./temp/retrieval/{num}.jpg + \
                             style="width:{size[0]}px;height:{size[1]}px;">'],
                             'status' : status}) for num, i, status in urls])
    temp_total = pd.merge(temp_total,
             frame_image,
             how = 'left')
    return temp_total

def making_image_list_flattened(keys, values, params, orderseries_merchandise, size = (200,150), max_prod = 40):
    temp_total = \
        pd.concat([DataFrame({'target_prod': keys}).astype('int'),
                   DataFrame({'productId': values}).astype('int'),
                   DataFrame({'params': params})],
                  axis=1)
    temp_total = temp_total.iloc[:max_prod]
    urls = pd.merge(orderseries_merchandise.astype({'productId': int}),
                    Series(temp_total['target_prod'].unique(), name='productId', dtype='int'),
                    on='productId',
                    )[['productId', 'images', ]].drop_duplicates().values
    [os.system("curl http:" + i + f" > ./temp/target/{num}.jpg") for num, i in urls]
    frame_image = pd.concat([
        DataFrame({'target_prod': num,
                   'target_img': [f'<img src=./temp/target/{num}.jpg + \
                             style="width:{size[0]}px;height:{size[1]}px;">']}) for num, i in urls])
    temp = pd.merge(temp_total, frame_image)
    urls = pd.merge(orderseries_merchandise,
                    Series(temp_total['productId'].dropna().unique().astype('int'), name='productId', dtype='str')
                    )[['productId', 'images', 'status']].drop_duplicates().values
    [os.system("curl http:" + i + f" > ./temp/retrieval/{num}.jpg") for num, i, status in urls]
    frame_image = pd.concat([DataFrame({'productId': num,
                                        'product_img': [f'<img src=./temp/retrieval/{num}.jpg + \
                                         style="width:{size[0]}px;height:{size[1]}px;">'],
                                         'status': status}) for num, i, status in urls])
    frame_image['productId'] = frame_image['productId'].astype('int')
    frame_image = pd.merge(temp_total, frame_image)
    temp_total = pd.merge(temp,
                          frame_image,
                          how='outer')
    temp_total = temp_total.drop_duplicates()
    return temp_total

def flatten_result(retrieval_dict, params_dict, types):
    result_flatten = dict()
    for buyerId, recommend in zip(retrieval_dict.keys(), retrieval_dict.values()):
        temp_list = list()
        if not isinstance(recommend, list):
            for item in recommend.values():
                item = [int(i) for i in item]
                temp_list.extend(item)
            result_flatten.update({buyerId: temp_list})
        else:
            temp_list.extend(recommend)
            result_flatten.update({buyerId: temp_list})

    params_flatten = dict()
    for buyerId, param in zip(params_dict.keys(), params_dict.values()):
        temp_list = list()
        if not isinstance(param, list):
            for items in param.values():
                for i in items:
                    i = i.tolist()
                    for j in i:
                        if np.isnan(j) == False:
                            temp_list.append(j)
            params_flatten.update({buyerId: temp_list})
        else:
            temp_list.extend(param)
            params_flatten.update({buyerId: temp_list})

    result_flatten_reorder = {buyerId: np.array(recommend_list)[np.argsort(params_flatten[buyerId])[::-1]].tolist()
                              for buyerId, recommend_list in zip(result_flatten.keys(), list(result_flatten.values()))}

    params_flatten_reorder = {buyerId: np.sort(params_list)[::-1].tolist()
                              for buyerId, params_list in zip(params_flatten.keys(), list(params_flatten.values()))}

    result_table = pd.merge(DataFrame(result_flatten_reorder.items()),
                            DataFrame(params_flatten_reorder.items()),
                            on=0)
    result_table.columns = ['buyerId', 'productId', 'parameter']
    result_table['type'] = types

    return result_table

def afterprocessing_minimum_num(dataframe_products,
                                retrieval_dict,
                                params_dict,
                                orderseries_merchandise,
                                minimum_num,
                                recommend_type):
    categories = dataframe_products[['productId', 'cat_0', 'cat_1', 'cat_2', 'status']]
    categories['cats'] = categories['cat_0'] + categories['cat_1'].fillna('') + categories['cat_2'].fillna('')

    flattened_list = flatten_result(retrieval_dict, params_dict, recommend_type)
    equal_zero_ind = flattened_list['productId'].apply(lambda x: len(x) == 0)
    flattened_list = flattened_list[~equal_zero_ind].reset_index(drop=True)

    except_ind = flattened_list['productId'].apply(lambda x: isinstance(x[0], str))
    flattened_list = flattened_list[~except_ind].reset_index(drop=True)

    flattened_list['count'] = flattened_list['productId'].apply(lambda x: minimum_num - len(x))
    filling_needed = flattened_list[flattened_list['count'] > 0][['buyerId', 'count']]

    weights = orderseries_merchandise.groupby('productId')['finalQuantity'].sum().reset_index()
    weights['productId'] = weights['productId'].astype('int')
    categories = pd.merge(categories, weights, on='productId', how='left')

    afterprocessing_list = list()
    for _, (buyerId, count) in filling_needed.iterrows():
        cat = [categories[categories['productId'] == int(i)]['cats'].values[0] for i in
               list(retrieval_dict[buyerId].keys())]
        param = Series(cat).value_counts()
        param = softmax_function(param)
        portion = [(i[0], math.floor(count * i[1]))
                   if math.floor(count * i[1]) > 0
                   else (i[0], 1) for i in param.items()]
        break_point = np.cumsum(np.array(portion)[:, 1].astype('int')) <= count
        if break_point.shape[0] > 1:
            portion = portion[0:np.max(np.where(break_point)) + 1]

        if np.sum(np.array(portion)[:, 1].astype('int')) < count:
            remain_num = count - np.sum(np.array(portion)[:, 1].astype('int'))
            n = 1
            temp = [1 for i in range(len(portion))]
            while True:
                if remain_num > len(temp):
                    portion = [(i[0], i[1] + j) for i, j in zip(portion, temp)]
                    remain_num -= len(temp)
                else:
                    temp = temp[0:remain_num] + [0 for i in range(0, len(temp) - remain_num)]
                    portion = [(i[0], i[1] + j) for i, j in zip(portion, temp)]
                    break
        random_sampled = list()
        for i in portion:
            exist_prodid = flattened_list.loc[flattened_list['buyerId'] == buyerId, 'productId'].iloc[0]
            prod_temp = categories[categories['cats'] == i[0]]['productId'].values
            prod_temp = list(set(prod_temp).difference(exist_prodid))
            categories_temp = pd.merge(categories,
                                       Series(prod_temp, name = 'productId'),
                                       how = 'right')
            weight_numerator = categories_temp['finalQuantity'].to_numpy() + 1
            weight_denominator = np.sum(categories_temp['finalQuantity'].to_numpy() + 1)
            sampling_weight = weight_numerator / weight_denominator
            random_sampled.append(np.random.choice(prod_temp,
                                                   size=min(len(prod_temp), i[1]),
                                                   p=sampling_weight,
                                                   replace=False))
        afterprocessing_list.append(np.concatenate(random_sampled))

    for (_, (buyerId, _)), j in zip(filling_needed.iterrows(), afterprocessing_list):
        unpack = flattened_list.loc[flattened_list['buyerId'] == buyerId, 'productId']
        concat = np.concatenate([unpack.values[0], j])
        if len(concat) >= minimum_num:
            flattened_list.at[int(np.where(flattened_list['buyerId'] == buyerId)[0]), 'productId'] = concat.tolist()
        else:
            flattened_list = flattened_list.drop(index=np.where(flattened_list['buyerId'] == buyerId)[0]).reset_index(
                drop=True)

    return flattened_list
