from utility.Network import ConnectModule
import psycopg2
import psycopg2.extras
from pymongo import MongoClient
import time
import numpy as np
import pandas as pd
from pandas import DataFrame, Series
import gc
import datetime
from dateutil.relativedelta import relativedelta

from utility import utils
from Recommender import A_1, A_3
from engine import profiling_engine
from Recommender.A_1 import A_1ALgorithm
from Recommender.A_3 import A_3ALgorithm
from Preprocessing import common
from Preprocessing import common,A_1_preprocessing,A_3_preprocessing

class RecommenderSystemA1(ConnectModule):
    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, from_date, to_date, client):
        super().__init__(host_ip, DBname, port, username, password, email_id, to_date, client)
        self.from_date = from_date
        self.to_date = to_date

    def load_table(self):
        self.NOSQL = {'dm_orderseries_recommend': {'SQL': {}}}
        super().load_table(connect_close=False)
        productid = tuple(self.dataframe_dm_orderseries_recommend.loc[
                              self.dataframe_dm_orderseries_recommend['productId'].apply(
                                  lambda x: len(str(x).split('_')) <= 1),
                              'productId'].astype(int).unique())
        self.brand_favorite = {"SQL": "select tfb.\"brand\"" + (
            ", tfb.\"buyer\"") + (
                                          ", tfb.\"created_at\" at time zone 'Asia/Seoul'") + (
                                          " from tb_favorite_brand tfb"),
                               "columns": ['brandId', 'buyerId', 'yeramon']}
        self.wishes = {"SQL": "select wis.\"brandId\"" + (
            ", \"userId\"") + (
                                  ", \"productId\"") + (
                                  ", \"createdAt\"") + (
                                  " from wishes wis where ") + (
                                  "wis.status = 100 "),
                       "columns": ['brandId', 'buyerId', 'productId', 'createdAt']}
        self.products = {"SQL": "select id" + (
            ", \"name\"->'ko'") + (
                                    ", \"appImages\"") + (
                                    ", \"data\"") + (
                                    ", \"brand\"") + (
                                    ", \"status\"") + (
                                    ", \"createdAt\" at time zone 'Asia/Seoul'") + (
                                    " from products where ") + (
                                    f"id in {productid}"),
                         "columns": ['productId', 'name', 'images', 'SKUdata', 'brand', 'status', 'createdAt']}

        self.blacklist = {'SQL': "select * from tb_exception_intro_products",
                          'columns': ['id', 'productId', 'delete_at', 'delete_id']}
        self.NOSQL = {'dm_buyer': {'SQL': {}}}
        super().load_table()

    def run(self):
        if not hasattr(self, 'dataframe_dm_buyer'):
            self.load_table()

        self.dataframe_products = \
            self.dataframe_products[
                ~self.dataframe_products['productId'].isin(self.dataframe_blacklist['productId'])].reset_index(
                drop=True)
        # 상품 정보 전처리
        merchandise_reduced, self.orderseries_merchandise = \
                                common.merchandise_preprocessing(self.dataframe_products,
                                                                 self.dataframe_dm_orderseries_recommend)
        # 단골브랜드 전처리
        favorite_pivot = common.favorite_preprocessing(self.dataframe_brand_favorite,
                                                       self.orderseries_merchandise)
        # 위시리스트 전처리
        wishes_reduced, buyerId_dict, buyerId_favorite_dict, productId_dict, productId_set = \
            common.wishes_preprocessing(self.dataframe_wishes, favorite_pivot, self.orderseries_merchandise)
        # SVD Matrix Factorization + 코사인 유사도
        self.csm_total = common.svd_preprocessing(favorite_pivot)
        # 카테고리 데이터 전처리
        favorite_pivot_Id_set, product_profile_numpy, product_profile_Id = \
            A_1_preprocessing.product_profile_preprocessing(self.orderseries_merchandise, favorite_pivot)
        # 위시리스트 피보팅
        wishes_coo = A_1_preprocessing.wishes_preprocessing(buyerId_dict, productId_dict, wishes_reduced)
        # 단골브랜드 Top-N 유사도 도출(Profiling_engine)
        result, param = profiling_engine(self.csm_total,
                                         [i for i in range(0, self.csm_total.shape[0])],
                                         k=20,
                                         threshold=0.2,
                                         core=8)
        # 타겟 상품 전처리
        target_product_list = A_1_preprocessing.target_product_list_preprocessing(self.orderseries_merchandise,
                                                                                  favorite_pivot, result)
        # 상품 전처리
        product_list = A_1_preprocessing.product_list_preprocessing(favorite_pivot, self.orderseries_merchandise,
                                                                    result)
        # A-1 알고리즘부
        self.retrieval_dict, self.params_dict = A_1ALgorithm(target_product_list,
                                                             product_list,
                                                             product_profile_Id,
                                                             product_profile_numpy,
                                                             favorite_pivot_Id_set,
                                                             productId_set,
                                                             productId_dict,
                                                             wishes_coo,
                                                             drop_duplicated=True)

class RecommenderSystemA3(ConnectModule):
    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, from_date, to_date, client):
        super().__init__(host_ip, DBname, port, username, password, email_id, to_date, client)
        self.from_date = from_date
        self.to_date = to_date

    def load_table(self):
        self.NOSQL = {'dm_orderseries_recommend': {'SQL': {}}}
        super().load_table(connect_close=False)
        productid = tuple(self.dataframe_dm_orderseries_recommend.loc[
                              self.dataframe_dm_orderseries_recommend['productId'].apply(
                                  lambda x: len(str(x).split('_')) <= 1),
                              'productId'].astype(int).unique())
        self.brand_favorite = {"SQL": "select tfb.\"brand\"" + (
            ", tfb.\"buyer\"") + (
                                          ", tfb.\"created_at\" at time zone 'Asia/Seoul'") + (
                                          " from tb_favorite_brand tfb"),
                               "columns": ['brandId', 'buyerId', 'yeramon']}
        self.wishes = {"SQL": "select wis.\"brandId\"" + (
                                  ", \"userId\"") + (
                                  ", \"productId\"") + (
                                  ", \"createdAt\"") + (
                                  " from wishes wis where ") + (
                                  "wis.status = 100 "),
                       "columns": ['brandId', 'buyerId', 'productId', 'createdAt']}
        self.products = {"SQL": "select id" + (
            ", \"name\"->'ko'") + (
                                    ", \"appImages\"") + (
                                    ", \"data\"") + (
                                    ", \"brand\"") + (
                                    ", \"status\"") + (
                                    ", \"createdAt\" at time zone 'Asia/Seoul'") + (
                                    " from products where ") + (
                                    f"id in {productid}"),
                         "columns": ['productId', 'name', 'images', 'SKUdata', 'brand', 'status', 'createdAt']}

        self.blacklist = {'SQL': "select * from tb_exception_intro_products",
                          'columns': ['id', 'productId', 'delete_at', 'delete_id']}
        self.NOSQL = {'dm_buyer': {'SQL': {}}}
        super().load_table()

    def run(self):
        if not hasattr(self, 'dataframe_dm_buyer'):
            self.load_table()
        self.dataframe_products = \
            self.dataframe_products[
                ~self.dataframe_products['productId'].isin(self.dataframe_blacklist['productId'])].reset_index(
                drop=True)
        # 상품 정보 전처리
        merchandise_reduced, self.orderseries_merchandise = \
                                common.merchandise_preprocessing(self.dataframe_products,
                                                                 self.dataframe_dm_orderseries_recommend)
        # 단골 브랜드 전처리
        buyer_list = self.dataframe_dm_buyer[self.dataframe_dm_buyer['lastLoginAt'] > self.from_date].reset_index(
                                                                                                        drop = True)
        favorite_pivot = common.favorite_preprocessing(self.dataframe_brand_favorite,
                                                       self.orderseries_merchandise,
                                                       buyer_reduce = buyer_list)
        # 위시리스트 전처리
        wishes_reduced, buyerId_dict, buyerId_favorite_dict, productId_dict, productId_set = \
            common.wishes_preprocessing(self.dataframe_wishes, favorite_pivot, self.orderseries_merchandise)
        # SVD Matrix Factorization + 코사인 유사도
        self.csm_total = common.svd_preprocessing(favorite_pivot)
        # 위시리스트 피보팅
        wishes_coo = A_3_preprocessing.wishes_preprocessing(buyerId_dict, productId_dict, wishes_reduced)
        # 단골브랜드 Top-N 유사도 도출
        result, param = profiling_engine(self.csm_total,
                                         [i for i in range(0, self.csm_total.shape[0])],
                                         k=20,
                                         threshold=0.2)
        # Top - N 유사도 바이어 인덱스 -> ID 변환
        result_buyer = [favorite_pivot.iloc[i[np.isnan(i) == False].astype('int'), 0].values for i in result]
        IdBuyer_favorite_dict = {j: i for i, j in buyerId_favorite_dict.items()}
        merchandise_reduced['cats'] = merchandise_reduced['cat_0'] + merchandise_reduced['cat_1'] + merchandise_reduced[
            'cat_2']
        # 카테고리 전처리
        merchandise_reduced = merchandise_reduced[~merchandise_reduced['cats'].isna()]
        wishes_reduced = pd.merge(wishes_reduced,
                                  merchandise_reduced[['productId', 'cats']].astype({'productId': int})
                                  )
        wishes_reduced_dict = wishes_reduced.groupby('buyerId').apply(lambda x: x.values[:, 1:].tolist())
        # A-3 알고리즘부
        self.retrieval_dict, self.params_dict = A_3ALgorithm(favorite_pivot,
                                                             result_buyer,
                                                             wishes_coo,
                                                             wishes_reduced_dict,
                                                             productId_dict,
                                                             IdBuyer_favorite_dict,
                                                             drop_duplicated=True
                                                             )

if __name__ == '__main__':

    client = MongoClient(host='10.10.224.28',
                         port=27017,
                         username='vida',
                         password='qwer123$')
    db_datamart = client['datamart']
    start_time = time.time()

    time_now = pd.Timestamp(datetime.datetime.now(), tz='UTC')
    time_from = str(datetime.datetime.strptime(str(time_now.date()), '%Y-%m-%d') - relativedelta(months=6)).split('-')
    time_from = time_from[0] + '-' + time_from[1] + '-' + '01'
    time_from_to = str(time_now.date())

    A_1Module = RecommenderSystemA1('restore.cy1gcw3mvrbf.ap-northeast-2.rds.amazonaws.com',
                                    'linkshops',
                                    '5432',
                                    'linkshops',
                                    '$dpdlvmflf4',
                                    'ji.kwon@linkshops.com','cjswp25*',
                                    '','',
                                    client)

    A_3Module = RecommenderSystemA3('restore.cy1gcw3mvrbf.ap-northeast-2.rds.amazonaws.com',
                                    'linkshops',
                                    '5432',
                                    'linkshops',
                                    '$dpdlvmflf4',
                                    'ji.kwon@linkshops.com','cjswp25*',
                                    time_from,'',
                                     client)

    # A_1 RUN
    A_1Module.run()
    # 디버깅용 추천 rawdata 저장
    a = pd.concat([DataFrame(i).T for i in A_1Module.retrieval_dict.items()])
    a = a.reset_index(drop=True)
    b = pd.concat([DataFrame(i).T for i in A_1Module.params_dict.items()])
    b = b.reset_index(drop=True)
    recommened_brand_for_debug = pd.merge(a, b, on=0)
    recommened_brand_for_debug.columns = ['buyerId', 'retrieval', 'params']
    recommened_brand_for_debug['retrieval'] = recommened_brand_for_debug['retrieval'].astype('str')
    recommened_brand_for_debug['params'] = recommened_brand_for_debug['params'].astype('str')
    recommened_brand_for_debug['type'] = 0

    col_dm = db_datamart['recommend_brand_debug']
    db_datamart.drop_collection('recommend_brand_debug')
    col_dm.insert_many(recommened_brand_for_debug.T.to_dict().values())
    # n = 30 최소 채운 Flattened list 저장
    flattened_list_A1 = utils.afterprocessing_minimum_num(A_1Module.dataframe_products,
                                                       A_1Module.retrieval_dict,
                                                       A_1Module.params_dict,
                                                       A_1Module.orderseries_merchandise,
                                                       30,
                                                       0)
    flattened_list_A1 = flattened_list_A1[['buyerId','productId','parameter','type']]
    tuples = [tuple(x) for x in flattened_list_A1.to_numpy()]
    A_1Module.delete_table('recommended_brand',0)
    A_1Module.insert_table('recommended_brand', tuples)

    col_dm = db_datamart['recommend_brand']
    db_datamart.drop_collection('recommend_brand')
    col_dm.insert_many(flattened_list_A1.T.to_dict().values())
    del A_1Module
    gc.collect()
    print(f'A_1 End : {time.time() - start_time}')

    #A_3 RUN
    A_3Module.run()
    # 디버그용 추천 rawdata 저장
    a = pd.concat([DataFrame(i).T for i in A_3Module.retrieval_dict.items()])
    a = a.reset_index(drop=True)
    b = pd.concat([DataFrame(i).T for i in A_3Module.params_dict.items()])
    b = b.reset_index(drop=True)
    recommened_brand_for_debug = pd.merge(a, b, on=0)
    recommened_brand_for_debug.columns = ['buyerId', 'retrieval', 'params']
    recommened_brand_for_debug['retrieval'] = recommened_brand_for_debug['retrieval'].astype('str')
    recommened_brand_for_debug['params'] = recommened_brand_for_debug['params'].astype('str')
    recommened_brand_for_debug['type'] = 1

    col_dm = db_datamart['recommend_brand_debug']
    col_dm.insert_many(recommened_brand_for_debug.T.to_dict().values())
    # n=30 채운 flattened_list 저장
    flattened_list_A3 = utils.afterprocessing_minimum_num(A_3Module.dataframe_products,
                                                       A_3Module.retrieval_dict,
                                                       A_3Module.params_dict,
                                                       A_3Module.orderseries_merchandise,
                                                       30,
                                                       1)
    flattened_list_A3 = flattened_list_A3[['buyerId', 'productId', 'parameter', 'type']]
    tuples = [tuple(x) for x in flattened_list_A3.to_numpy()]
    A_3Module.delete_table('recommended_brand',1)
    A_3Module.insert_table('recommended_brand', tuples)

    flattened_list = pd.concat([flattened_list_A1, flattened_list_A3], axis=0).reset_index(drop=True)
    col_dm = db_datamart['recommend_brand']
    db_datamart.drop_collection('recommend_brand')
    col_dm.insert_many(flattened_list.T.to_dict().values())

    print(f'A_3 End : {time.time() - start_time}')