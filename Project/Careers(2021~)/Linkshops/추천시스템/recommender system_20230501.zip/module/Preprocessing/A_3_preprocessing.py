import numpy as np
import pandas as pd
from pandas import DataFrame, Series
import scipy
import time

def wishes_preprocessing(buyerId_dict, productId_dict, wishes_reduced):
    wishes_mat = wishes_reduced.copy()
    wishes_mat['buyerId'] = [buyerId_dict[i] for i in wishes_mat['buyerId']]
    wishes_mat['productId'] = [productId_dict[i] for i in wishes_mat['productId']]

    row = np.array(wishes_mat['productId'])
    col = np.array(wishes_mat['buyerId'])
    values = np.array(wishes_mat['values'])
    wishes_coo = scipy.sparse.coo_matrix((values, (row, col)))
    wishes_coo = wishes_coo.astype('float64')
    wishes_coo = wishes_coo.toarray()

    return wishes_coo