from utility.utils import type_extractor
from utility import utils
import numpy as np
import pandas as pd
from pandas import DataFrame, Series
from sklearn.metrics.pairwise import cosine_similarity

def merchandise_preprocessing(merchandise, dataframe_orderseries):
    merchandise['category'] = \
        merchandise['SKUdata'].apply(lambda x: utils.type_extractor(utils.type_extractor([x], 'categoryPath'), 'en'))
    merchandise['brandId'] = merchandise['brand'].apply(lambda x: utils.type_extractor([x], 'id'))
    merchandise['cat_0'] = merchandise['category'].apply(lambda x: x[0])
    merchandise['cat_1'] = merchandise['category'].apply(lambda x: x[1] if len(x) > 2 else None)
    merchandise['cat_2'] = merchandise['category'].apply(lambda x: x[2] if len(x) > 2 else None)
    merchandise['images'] = \
        merchandise['images'].apply(lambda x: utils.type_extractor(utils.type_extractor([x],
                                                                            'default'),
                                                             'url'))
    merchandise = merchandise.rename({'name': 'prodName'}, axis=1)
    merchandise['productId'] = merchandise['productId'].astype('str')
    dataframe_orderseries['productId'] = dataframe_orderseries['productId'].astype('str')
    merchandise_reduced = merchandise[['productId', 'images', 'prodName', 'status', 'cat_0', 'cat_1', 'cat_2']]
    merchandise_reduced = merchandise_reduced.drop_duplicates()
    orderseries_merchandise = pd.merge(dataframe_orderseries,
                                       merchandise_reduced,
                                       on='productId',
                                       how='inner')
    return merchandise_reduced, orderseries_merchandise


def favorite_preprocessing(favorite, orderseries_merchandise, buyer_reduce = None):
    favorite['value'] = 1
    favorite = pd.merge(favorite, orderseries_merchandise['brandId'].drop_duplicates())
    if buyer_reduce is None:
        favorite = pd.merge(favorite, orderseries_merchandise['buyerId'].drop_duplicates())
    else :
        favorite = pd.merge(favorite, buyer_reduce['buyerId'].drop_duplicates())
    favorite_pivot = \
        favorite[['brandId', 'buyerId', 'value']].pivot_table(index='buyerId',
                                                              columns='brandId',
                                                              values='value')
    favorite_pivot = favorite_pivot.reset_index()
    favorite_pivot = favorite_pivot.fillna(0)
    favorite_pivot['values'] = np.log1p(favorite_pivot.iloc[:, 1:].sum(axis=1))
    favorite_pivot = favorite_pivot[favorite_pivot['values'] >= 1.3]
    favorite_pivot = favorite_pivot.drop(['values'], axis=1)
    favorite_pivot_t = favorite_pivot.iloc[:, 1:].T
    favorite_pivot_t['values'] = favorite_pivot_t.sum(axis=1)
    favorite_pivot_t = favorite_pivot_t[favorite_pivot_t['values'] >= 2]
    favorite_pivot = pd.concat([favorite_pivot['buyerId'],
                                favorite_pivot_t.T.drop('values')],
                               axis=1)

    return favorite_pivot

def wishes_preprocessing(wishes, favorite_pivot, orderseries_merchandise):
    wishes_reduced = \
        pd.merge(wishes,
                 orderseries_merchandise[['productId']].drop_duplicates().astype('int'))
    wishes_reduced = wishes_reduced[['buyerId', 'productId']].drop_duplicates()
    wishes_reduced['values'] = 1

    buyerId_dict = {j: i for i, j in enumerate(wishes_reduced['buyerId'].unique())}
    productId_dict = {j: i for i, j in enumerate(wishes_reduced['productId'].unique())}
    buyerId_favorite_dict = {j: i for i, j in enumerate(favorite_pivot['buyerId'].unique())}

    productId_set = set(productId_dict.keys())

    return wishes_reduced, buyerId_dict, buyerId_favorite_dict, productId_dict, productId_set


def svd_preprocessing(favorite_pivot):
    u, s, v = np.linalg.svd(favorite_pivot.iloc[:, 1:].to_numpy(), full_matrices=False)
    # 특이값의 총합, 즉 에너지가 90%가 넘는 지점의 축을 도출한다.
    energy_where = np.max(np.where(s.cumsum() / s.sum() < 0.9))
    # 위에서 도출한 값을 토대로 상위 53개 특이값에 해당하는 축들을 뽑아 재조합한다.
    print(energy_where)
    print(s.shape)
    order_matrix_reconstruct = np.dot(u[:, 0:energy_where], np.dot(np.diag(s[0:energy_where]), v[0:energy_where]))
    csm_total = cosine_similarity(order_matrix_reconstruct)
    csm_total -= np.eye(csm_total.shape[0])

    return csm_total