import numpy as np
import pandas as pd
from pandas import DataFrame, Series
import scipy
import time

def product_profile_preprocessing(orderseries_merchandise, favorite_pivot):
    orderseries_merchandise['cats'] = \
        orderseries_merchandise['cat_0'] + orderseries_merchandise['cat_1'] + orderseries_merchandise['cat_2']
    b = orderseries_merchandise[['productId', 'cats']].drop_duplicates()
    b['value'] = 1
    product_profile = b.pivot_table(index='productId',
                                    columns='cats',
                                    values='value').fillna(0).reset_index()
    product_profile['productId'] = product_profile['productId'].astype('int')
    favorite_pivot_Id_set = favorite_pivot['buyerId'].reset_index(drop=True).to_dict()
    product_profile_numpy = product_profile.iloc[:, 1:].to_numpy()
    product_profile_Id = {str(j): i for i, j in product_profile.iloc[:, 0].to_dict().items()}

    return favorite_pivot_Id_set, product_profile_numpy, product_profile_Id

def wishes_preprocessing(buyerId_dict, productId_dict, wishes_reduced):
    wishes_reduced['buyerId'] = [buyerId_dict[i] for i in wishes_reduced['buyerId']]
    wishes_reduced['productId'] = [productId_dict[i] for i in wishes_reduced['productId']]
    row = np.array(wishes_reduced['productId'])
    col = np.array(wishes_reduced['buyerId'])
    values = np.array(wishes_reduced['values'])

    wishes_coo = scipy.sparse.coo_matrix((values, (row, col)))
    wishes_coo = wishes_coo.astype('float64')
    wishes_coo = wishes_coo.toarray()

    return wishes_coo

def target_product_list_preprocessing(orderseries_merchandise,favorite_pivot,result,verbose = True):
    target_product_list = list()
    start_time = time.time()
    for num in range(0, result.shape[0]):
        target_list = favorite_pivot.iloc[[num], 0]
        target_products = pd.merge(orderseries_merchandise[['buyerId', 'productId']],
                                   target_list)['productId'].unique()
        target_product_list.append(target_products)
        if verbose & (num % 100 == 0):
            print(num)
            print(time.time() - start_time)
    return target_product_list

def product_list_preprocessing(favorite_pivot, orderseries_merchandise, result, verbose = True):
    product_list = list()
    start_time = time.time()
    for num in range(0, result.shape[0]):
        buyer_list = favorite_pivot.iloc[result[num][np.where(np.isnan(result[num]) == False)], 0]
        products = pd.merge(orderseries_merchandise[['buyerId', 'productId']],
                            buyer_list)['productId'].unique()
        product_list.append(products)
        if verbose & (num % 100 == 0):
            print(num)
            print(time.time() - start_time)
    return product_list