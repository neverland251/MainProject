import dm_seller,dm_buyer,dm_merchandise,dm_orderseries
from pymongo import MongoClient
import time
import pandas as pd
import datetime

password = '$dpdlvmflf4'
id_mongo = 'vida'
password_mongo = 'qwer123$'
email_id = 'ji.kwon@linkshops.com'
email_pw = 'cjswp25*'

client = MongoClient(host='10.10.224.28',
                     port=27017,
                     username = id_mongo,
                     password = password_mongo)

db_datamart = client['datamart']

# ----- running start ------ #
if __name__ == '__main__':

    time_now = pd.Timestamp(datetime.datetime.now(), tz='Asia/Seoul').tz_convert('UTC')
    time_from = time_now.date() - pd.Timedelta(31, unit='d')
    time_from_to = time_now.date()

    # ---- dm_seller ----#
    start_time = time.time()
    dm_maker = dm_seller.DM_SELLERMaker('restore.cy1gcw3mvrbf.ap-northeast-2.rds.amazonaws.com',
                                          'linkshops',
                                          '5432',
                                          'linkshops',
                                          password,
                                          email_id, email_pw,
                                          time_from, time_from_to,
                                          client)
    dm_maker.load_table()
    dm_maker.run()
    col_dm = db_datamart['dm_seller']
    print(f'dm_seller END : {time.time() - start_time}')
    db_datamart.drop_collection('dm_seller')
    for num, i in enumerate(dm_maker.dm_seller.T.to_dict().values()):
        col_dm.insert_one(i)
        if num % 1000 == 0:
            print(f'{round(num / dm_maker.dm_seller.shape[0], 2) * 100} % complete')

    # ---- dm_buyer ---- #

    start_time = time.time()
    dm_maker = dm_buyer.DM_BUYERMaker('restore.cy1gcw3mvrbf.ap-northeast-2.rds.amazonaws.com',
                                          'linkshops',
                                          '5432',
                                          'linkshops',
                                          password,
                                          email_id, email_pw,
                                          time_from, time_from_to,
                                          client)
    dm_maker.run()
    col_dm = db_datamart['dm_buyer']
    db_datamart.drop_collection('dm_buyer')
    for num, i in enumerate(dm_maker.dm_buyer.T.to_dict().values()):
        col_dm.insert_one(i)
        if num % 1000 == 0:
            print(f'{round(num / dm_maker.dm_buyer.shape[0], 2) * 100} % complete')

    print(f'dm_buyer END : {time.time() - start_time}')

    # ---- dm_merchandise ---- #
    start_time = time.time()
    dm_maker = dm_merchandise.DM_MerchandiseMaker('restore.cy1gcw3mvrbf.ap-northeast-2.rds.amazonaws.com',
                                                  'linkshops',
                                                  '5432',
                                                  'linkshops',
                                                  password,
                                                  email_id, email_pw,
                                                  time_from, time_from_to,
                                                  time_from, time_from_to,
                                                  client)
    dm_maker.run()
    col_dm = db_datamart['dm_merchandise']
    db_datamart.drop_collection('dm_merchandise')
    for num, i in enumerate(dm_maker.dm_merchandise.T.to_dict().values()):
        col_dm.insert_one(i)
        if num % 1000 == 0:
            print(f'{round(num / dm_maker.dm_merchandise.shape[0], 2) * 100} % complete')

    print(f'dm_merchandise END : {time.time() - start_time}')

    # ---- dm_orderseries ---- #

    start_time = time.time()
    dm_maker = dm_orderseries.DmOrderSeries('restore.cy1gcw3mvrbf.ap-northeast-2.rds.amazonaws.com',
                                      'linkshops',
                                      '5432',
                                      'linkshops',
                                      password,
                                      email_id,email_pw,
                                      time_from, time_from_to,
                                      client)

    dm_maker.load_table()
    dm_maker.run()
    col_dm = db_datamart['dm_orderseries']
    db_datamart.drop_collection('dm_orderseries')
    for num, i in enumerate(dm_maker.dm_orderseries.T.to_dict().values()):
        col_dm.insert_one(i)
        if num % 1000 == 0:
            print(f'{round(num / dm_maker.dm_orderseries.shape[0], 2) * 100} % complete')
    print(f'dm_orderseries END : {time.time() - start_time}')