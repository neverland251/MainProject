from engine import DatamartMaker
import pandas as pd
from pandas import DataFrame, Series
import scipy.stats as stats
import numpy as np
import datetime
import time
import json

class DM_BUYERMaker(DatamartMaker):

    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, from_date, to_date, client):
        super().__init__(host_ip, DBname, port, username, password, email_id, email_pw, client)
        self.from_date = from_date
        self.to_date = to_date

    def load_table(self, demo_test=False):

        self.users = {'SQL': "SELECT \"id\"," + (
            "\"name\",") + (
                                 "\"status\",") + (
                                 "\"roles\",") + (
                                 "\"createdAt\",") + (
                                 "\"updatedAt\",") + (
                                 "\"type\",") + (
                                 "\"isActive\",") + (
                                 "\"lastLoginAt\",") + (
                                 "\"data\"") + (
                                 " FROM users"),
                      'columns': ['buyerId',
                                  'name',
                                  'status',
                                  'roles',
                                  'createdAt',
                                  'updatedAt',
                                  'type',
                                  'isActive',
                                  'lastLoginAt',
                                  'data']}

        self.history = {'SQL': "SELECT \"target_id\"," + (
            "\"key\",") + (
                                   "\"before\",") + (
                                   "\"after\",") + (
                                   "\"updated_at\" FROM tb_update_history ") + (
                                   "where \"key\"='membership_buyer'"),
                        'columns': ['buyerId', 'key', 'before', 'after', 'historyUpdatedAt']}

        self.order = {'SQL': "select \"id\"," + (
                                 "\"buyerId\",") + (
                                 "\"brand\", ") + (
                                 "\"totalKRW\",") + (
                                 "\"finalTotalKRW\",") + (
                                 "\"finalQuantity\",") + (
                                 "\"quantity\",") + (
                                 "\"createdAt\"") + (
                                 " from order_products WHERE ") + (
                                 f"\"createdAt\" > '{self.from_date}' AND ") + (
                                 f"\"createdAt\" < '{self.to_date}'"),
                      'columns': ['orderProductId',
                                  'buyerId',
                                  'brand',
                                  'cusumOrderAmount',
                                  'cusumPurchaseAmount',
                                  'cusumPurchaseQuantity',
                                  'cusumOrderQuantity',
                                  'createdAt']}

        self.address = {'SQL': "SELECT \"userId\"," + (
            "\"countryCode\"") + (
                                   " FROM addresses"),
                        'columns': ['buyerId',
                                    'countryCodeShipment']
                        }

        self.coupling = {
            'SQL': "select distinct(value.buyerId), ids.description, ids.discount_promotion_id, value.created_at, ids.start_at, ids.end_at from(" + (
                "select \"id\" as discount_promotion_id, ") + (
                       "\"description\",") + (
                       "\"start_at\",") + (
                       "\"end_at\" ") + (
                       "from tb_discount_promotion ") + (
                       "where ") + (
                       # "\"end_at\" > '2022-06-01' and ") + (
                       "\"title\" like '%커플링%') ids ") + (
                       "join(") + (
                       "select \"buyer_id\" as buyerId") + (
                       ", \"discount_promotion_id\"") + (
                       ", \"use_yn\"") + (
                       ", \"created_at\"") + (
                       "from tb_discount_promotion_target_buyer ") + (
                       "where \"use_yn\" = 'Y') value ") + (
                       "on ids.\"discount_promotion_id\"=value.\"discount_promotion_id\""),
            'columns': ['buyerId',
                        'description',
                        'discount_promotion_id',
                        'createdAt',
                        'startAt',
                        'endAt']
            }

        super().load_table()

    def run(self,
            threshold_active=365,
            threshold_coupling=28,
            start_point=400,
            end_point=1,
            offset=10):

        def type_extractor(x, types, recursive=None):
            try:
                if recursive is None:
                    return x[0][types]
                else:
                    return type_extractor([x[0][types]],
                                          types=recursive)
            except:
                return 'NaN'

        def history_date_shifter(x):
            x = x.reset_index(drop=True)
            x = x.sort_values('historyUpdatedAt')
            if x.shape[0] > 1:
                x['historyUpdatedAtShift'] = x.iloc[1:, col_where[0]].reset_index(drop=True)
            else:
                x['historyUpdatedAtShift'] = np.nan
            return x

        def making_membership_history_dictionary(x):
            dictionary = dict()
            keys = str(int(x['before'])) + ' -> ' + str(int(x['after']))
            history_dict = pd.concat([x[['historyUpdatedAt', 'historyUpdatedAtShift']].astype('str'),
                                      Series(x['historyUpdatedAtDeriv'].days,
                                             index=['historyUpdatedAtDeriv'])]).to_dict()
            if (isinstance(history_dict, float) != True):
                if not isinstance(x['historyUpdatedAtDeriv'],
                                  (type(pd._libs.NaT), type(np.nan))):
                    dictionary[keys] = history_dict
                    return dictionary

        def making_membership_group(num, promotion_id_category, promotion_table, threshold_coupling):

            def generating_group_num(init=None):
                if init is None:
                    num = 0
                else:
                    num = init
                while True:
                    num += 1
                    yield num

            group_num = generating_group_num()
            promotion_ids = promotion_id_category[promotion_id_category['buyerId'] == num].reset_index(drop=True)
            promotion_ids = promotion_ids.columns[np.where(promotion_ids.iloc[0, 1:] == 1)[0] + 1]
            start_date = pd.merge(promotion_table,
                                  Series(promotion_ids, name='discount_promotion_id'),
                                  on='discount_promotion_id')['startAt']
            end_date = pd.merge(promotion_table,
                                Series(promotion_ids, name='discount_promotion_id'),
                                on='discount_promotion_id')['endAt']
            date_frame = DataFrame({'startDate': start_date, 'endDate': end_date})
            date_frame = date_frame.sort_values('endDate').reset_index(drop=True)
            startDate_shift = Series(date_frame.loc[1: date_frame.shape[0] - 1, 'startDate'].reset_index(drop=True),
                                     name='startDate_shift')
            date_frame = pd.concat([date_frame, startDate_shift], axis=1)
            last_end_date = date_frame.loc[date_frame.shape[0] - 1, 'endDate']
            date_frame = date_frame.fillna(last_end_date)
            TF_frame = DataFrame(
                (date_frame['startDate_shift'] - date_frame['endDate']) < pd.Timedelta(threshold_coupling, unit='D'))
            TF_frame['is_negative'] = (date_frame['startDate_shift'] - date_frame['endDate']) < pd.Timedelta(0,
                                                                                                             unit='D')
            tape = list()
            num = 0
            for i in TF_frame.iterrows():
                tape.append(num)
                if (i[1][0] == False) | (i[1]['is_negative'] == True):
                    num = next(group_num)
            date_frame['group'] = tape
            membership_term = date_frame.groupby('group').apply(
                lambda x: x.reset_index(drop=True).loc[x.shape[0] - 1, 'endDate'] - (
                    x.reset_index(drop=True).loc[0, 'startDate'])).astype('str').to_dict()
            jsons = date_frame.groupby('group').apply(
                lambda x: {'start_date': str(x.reset_index(drop=True).loc[0, 'startDate']),
                           'end_date': str(x.reset_index(drop=True).loc[x.shape[0] - 1, 'endDate'])})
            last_date = date_frame.loc[date_frame.shape[0] - 1, 'endDate']
            return date_frame[['startDate', 'endDate', 'group']], membership_term, jsons.to_dict(), last_date

        if not hasattr(self, 'dataframe_coupling'):
            self.load_table()

        # -------DM_BUYER START---------- #

        TF_table = np.array(self.dataframe_users['roles'].apply(lambda x: type_extractor(x, 'type')))
        start_time = time.time()
        self.dm_buyer = self.dataframe_users[(TF_table == 'buyer') | (TF_table =='bigBuyer')]
        self.dm_buyer['roles'] = self.dm_buyer['roles'].apply(lambda x: type_extractor(x, 'type'))
        print(f'dm_buyer : {time.time() - start_time}')

        # -------sinceLastLogined START---------- #

        start_time = time.time()
        last_login_buyer = self.dm_buyer[['lastLoginAt', 'isActive', 'status']]
        user_isactive = last_login_buyer['isActive']
        user_not_approval_member = last_login_buyer['status']
        last_login_buyer = last_login_buyer['lastLoginAt'].apply(
            lambda x: x.tz_convert('Asia/Seoul'))
        last_login_buyer = (pd.Timestamp(datetime.datetime.now(), tz='Asia/Seoul') - last_login_buyer).apply(
            lambda x: x.days)
        last_login_buyer = last_login_buyer.fillna(-9999)
        last_login_buyer.loc[user_isactive == False] = -9999
        last_login_buyer.loc[user_not_approval_member != 100] = -9999
        last_login_buyer.name = 'sinceLastLogined'
        self.dm_buyer = pd.concat([self.dm_buyer, last_login_buyer], axis=1)
        activeYn = Series((last_login_buyer == -9999) |
                          (last_login_buyer > threshold_active), name='activeYn')
        self.dm_buyer = pd.concat([self.dm_buyer, activeYn], axis=1)
        print(f'sinceLastLogined : {time.time() - start_time}')

        # -------sinceLastLogined END------------#

        # ------- membership START -------------#

        start_time = time.time()
        dataframe_history_buyer = pd.merge(self.dm_buyer, self.dataframe_history,
                                           on=['buyerId'])
        dm_buyer_for_membership = dataframe_history_buyer.drop([
            'roles',
            'type',
            'isActive'],
            axis=1)
        dm_buyer_for_membership = dm_buyer_for_membership[~dm_buyer_for_membership['key'].isna()].sort_values(
            'historyUpdatedAt').reset_index()
        col_where = np.where(dm_buyer_for_membership.columns == 'historyUpdatedAt')[0]
        if dm_buyer_for_membership.shape[0] > 0:
            dm_buyer_for_membership = dm_buyer_for_membership.groupby('buyerId').apply(
                lambda x: history_date_shifter(x)).reset_index(drop=True)
        else:
            dm_buyer_for_membership['historyUpdatedAtShift'] = []
        if dm_buyer_for_membership.shape[0] > 1:
            dm_buyer_for_membership['historyUpdatedAtDeriv'] = dm_buyer_for_membership.apply(
                lambda x: x['historyUpdatedAtShift'] - x['historyUpdatedAt'], axis=1)
        else:
            dm_buyer_for_membership['historyUpdatedAtDeriv'] = pd._libs.NaT
        dm_buyer_for_membership['activeYn'] = 'Y'
        dm_buyer_for_membership.set_index('index', inplace=True)
        dm_buyer_for_membership.index.name = ''
        brandId = dm_buyer_for_membership['buyerId'].unique()
        history_frame = DataFrame()
        if len(brandId) == 0:
            history_frame = DataFrame({'buyerId': [],
                                       'membershipHistory': [],
                                       'before_membership_date': [],
                                       'before_membership_due': [],
                                       'membership_term': []})
        for i in brandId:
            temp = dm_buyer_for_membership[dm_buyer_for_membership['buyerId'] == i]
            membership_history = list(temp.apply(lambda x: making_membership_history_dictionary(x), axis=1))
            membership_history = [i for i in membership_history if i is not None]
            before_membership_date = [list(i.values())[0]['historyUpdatedAt'] for i in membership_history]
            if len(before_membership_date) > 1:
                before_membership_date = before_membership_date[len(before_membership_date) - 2]
            else:
                before_membership_date = before_membership_date
            before_membership_due = [list(i.values())[0]['historyUpdatedAtShift'] for i in membership_history]
            if len(before_membership_due) > 1:
                before_membership_due = before_membership_due[len(before_membership_due) - 2]
            else:
                before_membership_due = before_membership_due
            membership_term = [list(i.values())[0]['historyUpdatedAtDeriv'] for i in membership_history]
            if len(membership_term) > 1:
                membership_term = membership_term[len(membership_term) - 2]
            else:
                membership_term = membership_term
            temp = DataFrame({'brandId': i,
                              'membershipHistory': [membership_history],
                              'before_membership_date': [before_membership_date],
                              'before_membership_due': [before_membership_due],
                              'membership_term': [membership_term]
                              })
            history_frame = pd.concat([history_frame, temp])
        self.dm_buyer = pd.merge(self.dm_buyer, history_frame, how='left', on='buyerId')

        # -------- membership END ---------#

        print(f'membership : {time.time() - start_time}')

        # -------- abnormal Order start -------#

        start_time = time.time()
        dataframe_order = self.dataframe_order.copy()
        dataframe_order['brandId'] = dataframe_order['brand'].apply(
            lambda x: type_extractor([x], 'id'))
        dataframe_order = dataframe_order.rename(
            {'cusumOrderQuantity': 'quantity',
             'cusumPurchaseQuantity': 'finalQuantity'}, axis=1)
        dataframe_order['createdAt_date'] = dataframe_order['createdAt'].dt.date
        abnormal_result = DataFrame()
        normal_dist_std = dataframe_order.groupby(['buyerId', 'createdAt_date'])['quantity'].sum().reset_index()
        normal_dist_std = normal_dist_std.groupby('buyerId')['quantity'].apply(lambda x: np.std(np.diff(x)))
        normal_dist_std = normal_dist_std.dropna()
        normal_dist_std.columns = ['std']
        for ind in normal_dist_std.index:
            buyerId_series = dataframe_order[dataframe_order['buyerId'] == ind]
            buyerId_series = buyerId_series.groupby('createdAt_date')['quantity'].sum()
            buyerId_series = buyerId_series[-start_point: -end_point]
            diff_series = np.diff(buyerId_series)
            bound = stats.norm.ppf(q=0.99,
                                   loc=0,
                                   scale=np.max([normal_dist_std.loc[ind], 0.1]) + offset)

            abnormal_point = np.where(diff_series > bound)[0]
            if abnormal_point.shape[0] > 0:
                abnormal_table = pd.concat([
                    Series(buyerId_series.iloc[abnormal_point], name='previousOrder').reset_index(drop=True),
                    Series(buyerId_series.iloc[abnormal_point + 1], name='currentOrder').reset_index(drop=True),
                    Series(str(buyerId_series.index[abnormal_point + 1].values[0]),
                           name='where')],
                    axis=1)
                abnormal_table['averageOrder'] = np.round(np.mean(buyerId_series), 2)
                abnormal_table = list(abnormal_table.apply(lambda x: x.to_dict(), axis=1))
                temp = DataFrame({'buyerId': ind,
                                  'overorderHistory': [abnormal_table],
                                  'cusumOverorder': len(abnormal_table),
                                  'last_overorder_previous': abnormal_table[-1]['previousOrder'],
                                  'last_overorder_current': abnormal_table[-1]['currentOrder'],
                                  'last_overorder_when': abnormal_table[-1]['where'],
                                  'last_overorder_avg': abnormal_table[-1]['averageOrder']})
                abnormal_result = pd.concat([abnormal_result, temp])
        self.dm_buyer = pd.merge(self.dm_buyer, abnormal_result, on='buyerId', how='left')

        # -------------------abnormal_order END--------------#
        print(f'abnormal_order : {time.time() - start_time}')

        if 'membership' not in self.dm_buyer.columns:
            self.dm_buyer['membership'] = 0
        # ---------- order, purchase START ------------#

        start_time = time.time()
        self.dm_buyer = pd.merge(self.dm_buyer,
                                 pd.concat([self.dataframe_order.groupby('buyerId')['cusumOrderAmount'].sum(),
                                            self.dataframe_order.groupby('buyerId')['cusumPurchaseAmount'].sum(),
                                            self.dataframe_order.groupby('buyerId')['cusumOrderQuantity'].sum(),
                                            self.dataframe_order.groupby('buyerId')['cusumPurchaseQuantity'].sum()],
                                           axis=1).reset_index(),
                                 on='buyerId',
                                 how='left')
        print(f'order, purchase : {time.time() - start_time}')

        # ----------- order, purchase END ---------#

        # ----------- country Start ---------#

        start_time = time.time()
        users = self.dataframe_users.copy()
        address = self.dataframe_address.copy()
        address = address.drop_duplicates()
        users = users[users['roles'].apply(lambda x: type_extractor(x, 'type')) == 'buyer']
        users = users.dropna(subset='data')
        users_address = pd.merge(users, address, how='left')
        users_address['countryCodePlace'] = users_address['data'].apply(
            lambda x: type_extractor([x], 'country'))
        users_address = users_address[['buyerId',
                                       'countryCodeShipment',
                                       'countryCodePlace']]
        self.dm_buyer = pd.merge(self.dm_buyer,
                                 users_address,
                                 on='buyerId',
                                 how='left')
        print(f'country : {time.time() - start_time}')

        # ----------- country End ---------#

        # ----------- couplingpass Start ------- #
        start_time = time.time()
        promotion_table = self.dataframe_coupling[
            ['description', 'discount_promotion_id', 'createdAt', 'startAt', 'endAt']
        ].drop_duplicates('discount_promotion_id').reset_index(drop=True)
        promotion_id_category = self.dataframe_coupling.groupby('buyerId')['discount_promotion_id'].apply(
            lambda x: pd.get_dummies(x).sum())
        promotion_id_category = promotion_id_category.unstack().fillna(0).reset_index()
        couplingpass_result = dict()
        for i in promotion_id_category['buyerId']:
            temp_result = dict()
            result = making_membership_group(i,
                                             promotion_id_category,
                                             promotion_table,
                                             threshold_coupling)
            temp_result['couplingpassTerm'] = json.dumps(result[1])
            temp_result['couplingpassHistory'] = json.dumps(result[2])
            temp_result['couplingpassCurrent'] = (result[3] > pd.Timestamp(time.ctime(), tz='UTC'))
            couplingpass_result[i] = temp_result
        coupling_pass_history = DataFrame(couplingpass_result).T
        coupling_pass_history.index.name = 'buyerId'
        coupling_pass_history = coupling_pass_history.reset_index()
        self.dm_buyer = pd.merge(self.dm_buyer,
                                 coupling_pass_history,
                                 on='buyerId',
                                 how='left')
        print(f'couplingpass : {time.time() - start_time}')

        # ----------- couplingpass End ------- #

        # --------- posterior Processing START ---------#
        self.dm_buyer['lastLoginAt'] = self.dm_buyer['lastLoginAt'].astype('str')
        self.dm_buyer['sinceLastLogined'] = self.dm_buyer['sinceLastLogined'].astype('int')
        self.dm_buyer[['cusumOverorder',
                       'cusumOrderAmount',
                       'cusumPurchaseAmount',
                       'cusumOrderQuantity',
                       'cusumPurchaseQuantity']] = self.dm_buyer[['cusumOverorder',
                                                                  'cusumOrderAmount',
                                                                  'cusumPurchaseAmount',
                                                                  'cusumOrderQuantity',
                                                                  'cusumPurchaseQuantity']].astype('float')
        self.dm_buyer = self.dm_buyer.drop(['type',
                                            'data',
                                            'isActive',
                                            'status'], axis=1)