from engine import DatamartMaker
import pandas as pd
import numpy as np
from pandas import DataFrame, Series
import time


class DM_MerchandiseMaker(DatamartMaker):

    def __init__(self,
                 host_ip,
                 DBname,
                 port,
                 username,
                 password,
                 email_id,
                 email_pw,
                 from_date,
                 to_date,
                 prod_from_date,
                 prod_to_date,
                 client):
        super().__init__(host_ip, DBname, port, username, password, email_id, email_pw, client)
        self.from_date = from_date
        self.to_date = to_date
        self.prod_from_date = prod_from_date
        self.prod_to_date = prod_to_date

    def load_table(self, demo_test=False):

        self.order_prod = {'SQL': "select \"buyerId\"," + (
            "\"brand\", ") + (
                                      "\"totalKRW\",") + (
                                      "\"finalTotalKRW\",") + (
                                      "\"finalQuantity\",") + (
                                      "\"quantity\",") + (
                                      "\"product\",") + (
                                      "\"productVariant\",") + (
                                      "\"orderId\",") + (
                                      "\"createdAt\",") + (
                                      "\"updatedAt\"") + (
                                      " from order_products WHERE ") + (
                                      f"\"createdAt\" > '{self.from_date}' AND ") + (
                                      f"\"createdAt\" < '{self.to_date}'"),
                           'columns': ['buyerId',
                                       'brand',
                                       'totalKRW',
                                       'finalTotalKRW',
                                       'finalQuantity',
                                       'quantity',
                                       'product',
                                       'productVariant',
                                       'orderId',
                                       'createdAt',
                                       'updatedAt']}

        self.prod = {'SQL': "select \"id\"," + (
                                "\"brand\", ") + (
                                "\"categories\",") + (
                                "\"appImages\",") + (
                                "\"name\",") + (
                                "\"data\",") + (
                                "\"createdAt\",") + (
                                "\"status\"") + (
                                " from products WHERE ") + (
                                f"\"createdAt\" > '{self.prod_from_date}' AND ") + (
                                f"\"createdAt\" < '{self.prod_to_date}' AND ") + (
                                "\"isActive\""),
                     'columns': ['productId',
                                 'brand',
                                 'categories',
                                 'appImages',
                                 'name',
                                 'data',
                                 'createdAt',
                                 'status']}

        self.variant = {'SQL': "select  " + (
                                            "\"id\",") + (
                                             "\"CNY\",") + (
                                             "\"KRW\",") + (
                                             "\"TWD\",") + (
                                             "\"USD\",") + (
                                             "\"sku\",") + (
                                             "\"data\",") + (
                                             "\"version\",") + (
                                             "\"productId\",") + (
                                             "\"appImages\",") + (
                                             "\"createdAt\",") + (
                                             "\"updatedAt\"") + (
                                             " from product_variants WHERE ") + (
                                             f"\"createdAt\" > '{self.prod_from_date}' AND ") + (
                                             f"\"createdAt\" < '{self.prod_to_date}' AND ") + (
                                             "\"status\" = 100"),
                                  'columns': ['variantId',
                                              'CNY',
                                              'KRW',
                                              'TWD',
                                              'USD',
                                              'sku',
                                              'data',
                                              'version',
                                              'productId',
                                              'image_variant',
                                              'createdAt',
                                              'updatedAt']}

        super().load_table()

    def run(self, threshold_active=365, start_point=400, end_point=1, offset=20):

        def type_extractor(x, types, recursive=None):
            try:
                if recursive is None:
                    return x[0][types]
                else:
                    return type_extractor([x[0][types]],
                                          types=recursive)
            except:
                return 'NaN'

        if not hasattr(self, 'dataframe_variant'):
            self.load_table()

        # -------DM_Merchandise START---------- #

        prod_variant = pd.merge(self.dataframe_prod,
                                self.dataframe_variant,
                                on='productId',
                                how='right',
                                suffixes=['_prod', '_variant'])

        start_time = time.time()
        dataframe_order_prod = self.dataframe_order_prod.copy()
        dataframe_prod = self.dataframe_prod.copy()
        dataframe_order_prod['productId'] = dataframe_order_prod['product'].apply(
            lambda x: type_extractor([x], 'id'))
        dataframe_order_prod['variantId'] = dataframe_order_prod['productVariant'].apply(
            lambda x: type_extractor([x], 'id'))
        dataframe_order_prod['date'] = dataframe_order_prod['createdAt'].dt.date.apply(lambda x: str(x))
        dataframe_order_prod[['totalKRW', 'finalTotalKRW', 'finalQuantity', 'quantity']] = (
            dataframe_order_prod[['totalKRW', 'finalTotalKRW', 'finalQuantity', 'quantity']].astype('float'))
        self.dm_merchandise = dataframe_order_prod.groupby(
            ['productId', 'variantId', 'date'])[
            ['totalKRW', 'finalTotalKRW', 'finalQuantity', 'quantity']
        ].sum().reset_index()
        order_prod = dataframe_order_prod[['productId', 'variantId', 'product', 'productVariant', 'brand']].rename(
            {'product': 'SKUdata', 'productVariant': 'variantData'}, axis=1)
        order_prod = order_prod.drop_duplicates('variantId')
        self.dm_merchandise = pd.merge(self.dm_merchandise,
                                       order_prod,
                                       on=['productId', 'variantId'],
                                       how='left')
        self.dm_merchandise['createdAt'] = self.dm_merchandise['SKUdata'].apply(
            lambda x: x['createdAt']
            if np.any(np.array(list(x.keys())) == 'createdAt')
            else np.nan)
        self.dm_merchandise = pd.concat([self.dm_merchandise,
                                         Series(self.dm_merchandise.apply(
                                             lambda x: np.any(np.array(list(x['SKUdata'].keys())) == 'bulkProductId'),
                                             axis=1),
                                             name='isBulkOrder')],
                                        axis=1)
        full_prod_variant = set(prod_variant['variantId'])
        order_prod_variant = set(self.dm_merchandise['variantId'].unique())
        variantid_not_in_order = Series(list(full_prod_variant.difference(order_prod_variant)),
                                        name='variantId')
        dm_merchandise_not_in_order = pd.merge(prod_variant,
                                               variantid_not_in_order,
                                               on='variantId',
                                               how='right').drop(['createdAt_prod'], axis=1).rename(
            {'createdAt_variant': 'createdAt'}, axis=1)
        dm_merchandise_not_in_order[['CNY', 'KRW', 'TWD', "USD"]] = dm_merchandise_not_in_order[[
            'CNY', 'KRW', 'TWD', "USD"]].astype('float')
        dm_merchandise_not_in_order[['createdAt',
                                     'updatedAt']] = dm_merchandise_not_in_order[['createdAt',
                                                                                  'updatedAt']].astype('str')

        dm_merchandise_not_in_order['data_prod'] = dm_merchandise_not_in_order.rename(
            {'productId': 'id',
             'data_prod': 'data'}, axis=1)[['id',
                                            'CNY',
                                            'KRW',
                                            'TWD',
                                            'USD',
                                            'data',
                                            'appImages',
                                            'name',
                                            'createdAt',
                                            'updatedAt']].to_dict(orient='records')
        dm_merchandise_not_in_order['data_variant'] = dm_merchandise_not_in_order.rename(
            {'variantId': 'id',
             'data_variant': 'data',
             'imageVariant': 'appImages'}, axis=1)[['id',
                                                    'CNY',
                                                    'KRW',
                                                    'TWD',
                                                    'USD',
                                                    'sku',
                                                    'data',
                                                    'appImages',
                                                    'createdAt',
                                                    'updatedAt']].to_dict(orient='records')
        dm_merchandise_not_in_order = dm_merchandise_not_in_order[['productId', 'variantId', 'data_prod',
                                                                   'data_variant', 'brand', 'createdAt']]
        dm_merchandise_not_in_order['date'] = str(self.to_date)
        dm_merchandise_not_in_order.columns = ['productId', 'variantId', 'SKUdata', 'variantData', 'brand', 'createdAt',
                                               'date']
        diff_col = list(set(self.dm_merchandise.columns).difference(set(dm_merchandise_not_in_order.columns)))
        dm_merchandise_not_in_order[diff_col] = 0
        dm_merchandise_not_in_order = dm_merchandise_not_in_order[~dm_merchandise_not_in_order['createdAt'].isna()]
        self.dm_merchandise = pd.concat([self.dm_merchandise,
                                         dm_merchandise_not_in_order]).reset_index(drop=True)
        print(f'dm_merchandise : {time.time() - start_time}')

        # ===== preprocessing Start ========#
        self.dm_merchandise = self.dm_merchandise[self.dm_merchandise['isBulkOrder'] != 1].reset_index(drop=True)
        self.dm_merchandise[['totalKRW',
                             'finalTotalKRW',
                             'finalQuantity',
                             'quantity',
                             'isBulkOrder']] = self.dm_merchandise[['totalKRW',
                                                                    'finalTotalKRW',
                                                                    'finalQuantity',
                                                                    'quantity',
                                                                    'isBulkOrder']].astype('float')