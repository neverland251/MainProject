from engine import DatamartMaker
import pandas as pd
import numpy as np
from pandas import DataFrame, Series
import datetime
import time


class DM_SeriesMaker(DatamartMaker):

    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, from_date, unit_day, client):
        super().__init__(host_ip, DBname, port, username, password, email_id, email_pw, client)
        self.from_date = from_date
        self.unit_day = unit_day

    def load_table(self, demo=False):

        if demo:
            self.time_now = pd.Timestamp('2022-06-20', tz='Asia/Seoul').tz_convert('UTC')
        else:
            self.time_now = self.from_date
        self.time_from = self.time_now.date() - pd.Timedelta(self.unit_day + 0.5, unit='d')
        self.time_from_to = self.time_now.date()

        self.sku = {'SQL': "select  " + (
            "\"brand\",") + (
                               "\"createdAt\"") + (
                               " from products WHERE ") + (
                               f"\"createdAt\" > '{self.time_from}' AND ") + (
                               f"\"createdAt\" <= '{self.time_from_to}'"),
                    'columns': ['brand',
                                'createdAt']}

        self.order = {'SQL': "select \"buyerId\"," + (
            "\"brand\", ") + (
                                 "\"totalKRW\",") + (
                                 "\"finalTotalKRW\",") + (
                                 "\"finalQuantity\",") + (
                                 "\"quantity\",") + (
                                 "\"createdAt\"") + (
                                 " from order_products WHERE ") + (
                                 f"\"createdAt\" > '{self.time_from}' AND ") + (
                                 f"\"createdAt\" <= '{self.time_from_to}'"),
                      'columns': ['buyerId',
                                  'brand',
                                  'totalKR',
                                  'finalTotalKR',
                                  'finalQuantity',
                                  'quantity',
                                  'createdAt']}

        if demo:
            self.history = {'SQL': "SELECT \"target_id\"," + (
                "\"key\",") + (
                                       "\"before\",") + (
                                       "\"after\",") + (
                                       "\"updated_at\" FROM tb_update_history ") + (
                                       "where \"key\"='membership'"),
                            'columns': ['brandId', 'key', 'before', 'after', 'historyUpdatedAt']}

        else:

            self.history = {'SQL': "SELECT \"target_id\"," + (
                "\"key\",") + (
                                       "\"before\",") + (
                                       "\"after\",") + (
                                       "\"updated_at\" FROM tb_update_history ") + (
                                       "where \"key\"='membership' AND ") + (
                                       f"\"created_at\" > '{self.time_from}' AND ") + (
                                       f"\"created_at\" <= '{self.time_from_to}'"),
                            'columns': ['brandId', 'key', 'before', 'after', 'historyUpdatedAt']}

        super().load_table()

        if demo:
            self.dataframe_history['historyUpdatedAt'] = self.time_from
            self.dataframe_history = pd.concat(
                [self.dataframe_history,
                 pd.DataFrame({'brandId': self.dataframe_history['brandId'],
                               'key': self.dataframe_history['key'],
                               'historyUpdatedAt': (self.dataframe_history['historyUpdatedAt'] + (
                                   pd.Timedelta(180, unit='day'))),
                               'before': self.dataframe_history['after'],
                               'after': self.dataframe_history['before']})
                 ]).reset_index(drop=True)
            self.dataframe_history['historyUpdatedAt'] = self.dataframe_history[
                'historyUpdatedAt'].astype('datetime64')

    def run(self, threshold_membership=0):

        def type_extractor(x, types, recursive=None):
            try:
                if recursive is None:
                    return x[0][types]
                else:
                    return type_extractor([x[0][types]],
                                          types=recursive)
            except:
                return 'NaN'

        def making_membership_dict(x):
            x = x.set_index(['before_after'])
            x = x.unstack().unstack()
            x = x.loc['subCount']
            # x = x.add_prefix('membership_')
            x = x.to_dict()
            return x

        def generating_group_num(init=None):
            if init is None:
                num = 0
            else:
                num = init
            while True:
                num += 1
                yield num

        def groupby_bounce_row_replacer(x):
            x = x.reset_index(drop=True)
            where = np.where(np.isnan(x['historyUpdatedAtDeriv']))[0]
            if len(where) == x.shape[0]:
                return x
            if len(where) > 0:
                x.loc[np.max(where) + 1, 'getthisindex'] = True
                return x[~x['date'].isna()]

        def history_date_shifter(x):
            col_where = np.where(x.columns == 'historyUpdatedAt')[0]
            x = x.reset_index(drop=True)
            x = x.sort_values('historyUpdatedAt')
            if x.shape[0] > 1:
                x['historyUpdatedAtShift'] = x.iloc[1:, col_where[0]].reset_index(drop=True)
            else:
                x['historyUpdatedAtShift'] = np.nan
            return x

        def making_membership_history_dictionary(x):
            dictionary = dict()
            keys = str(int(x['before'])) + ' -> ' + str(int(x['after']))
            history_dict = pd.concat([x[['historyUpdatedAt', 'historyUpdatedAtShift']].astype('str'),
                                      Series(x['historyUpdatedAtDeriv'].days,
                                             index=['historyUpdatedAtDeriv'])]).to_dict()
            dictionary[keys] = history_dict
            return dictionary

        def preprocessing_exception(avgsubperiod_row, date_id, seller_subscribe):
            membershipTerm = date_id.copy()
            membershipTerm['brandId'] = avgsubperiod_row['brandId']
            membershipTerm['group'] = 0
            membershipTerm['historyUpdatedAt'] = np.nan
            membershipTerm['historyUpdatedAtShift'] = np.nan
            membershipTerm['historyUpdatedAtDeriv'] = np.nan
            seller_subscribe = pd.concat([seller_subscribe, membershipTerm])
            return seller_subscribe

        if not hasattr(self, 'dataframe_history'):
            self.load_table()

        # -------DM_Series START---------- #

        start_time = time.time()

        self.dm_series = DataFrame({'date': pd.date_range(self.time_from,
                                                          self.time_from_to,
                                                          closed='left')}).astype('str')

        print(f'dm_series : {time.time() - start_time}')

        # ------ DM_Series END ----------- #

        # ------ SKU start ------------#

        start_time = time.time()

        dataframe_sku = self.dataframe_sku.copy()
        dataframe_sku['date'] = dataframe_sku['createdAt'].dt.date.astype('str')
        dataframe_sku = dataframe_sku.groupby(['date'])['brand'].count().reset_index()
        dataframe_sku = dataframe_sku.rename({'brand': 'cumSKU'}, axis=1)
        self.dm_series = pd.merge(self.dm_series, dataframe_sku, on='date', how='left')
        print(f'SKU : {time.time() - start_time}')

        # ------ SKU END ------------#

        # ------ order, transaction START ------ #

        start_time = time.time()
        dataframe_order = self.dataframe_order.copy()
        dataframe_order['date'] = dataframe_order['createdAt'].dt.date.astype('str')
        dataframe_order[['totalKR', 'finalTotalKR']] = dataframe_order[
            ['totalKR', 'finalTotalKR']].astype('float')
        date_sum = dataframe_order.groupby('date')[['totalKR',
                                                    'finalTotalKR',
                                                    'quantity',
                                                    'finalQuantity']].sum().reset_index()
        date_sum = date_sum.rename({'totalKR': 'totalOrder',
                                    'finalTotalKR': 'totalTransaction',
                                    'quantity': 'totalOrderQuantity',
                                    'finalQuantity': 'totalTranscationQuantity'},
                                   axis=1)
        dataframe_order['monthly'] = dataframe_order['createdAt'].dt.year.astype('str') + (
                '-' + dataframe_order['createdAt'].dt.month.astype('str'))
        monthly_cumsum = dataframe_order.groupby(['monthly', 'date'])[[
            'totalKR',
            'finalTotalKR',
            'quantity',
            'finalQuantity']].sum().groupby(level=0).cumsum().reset_index()
        monthly_cumsum = monthly_cumsum[['date', 'finalTotalKR', 'totalKR', 'quantity', 'finalQuantity']].rename(
            {'totalKR': 'cumOrderMonthly',
             'finalTotalKR': 'cumTransactionMonthly',
             'quantity': 'cumOrderQuantityMonthly',
             'finalQuantity': 'cumTranscationQuantityMonthly'}, axis=1)
        self.dm_series = pd.merge(self.dm_series,
                                  pd.merge(date_sum, monthly_cumsum, on='date'),
                                  on='date',
                                  how='left')

        print(f'order, transaction : {time.time() - start_time}')

        # ----- order, transaction END ------- #

        # ----- MEMBERSHIP START -------- #

        start_time = time.time()
        dataframe_history = self.dataframe_history
        if dataframe_history.shape[0] > 0:
            dataframe_history['date'] = dataframe_history['historyUpdatedAt'].dt.date.astype('str')
            date_membership = dataframe_history.groupby('date')[['before', 'after']].value_counts()
            date_membership.name = 'subCount'
            date_membership = date_membership.reset_index()
            date_membership['before_after'] = date_membership['before'].astype('str') + (
                '->') + (
                                                  date_membership['after'].astype('str'))
            date_membership = date_membership.groupby('date')[
                ['before_after', 'subCount']].apply(
                lambda x: making_membership_dict(x))
            date_membership = date_membership.reset_index(name='membershipCount')
            self.dm_series = pd.merge(self.dm_series, date_membership, on='date', how='left')
        else:
            self.dm_series['membershipCount'] = np.nan
        history_for_membership = dataframe_history.groupby('brandId').apply(
            lambda x: history_date_shifter(x)).reset_index(drop=True)
        history_for_membership['historyUpdatedAtShift'] = history_for_membership['historyUpdatedAtShift'].fillna(
            pd._libs.NaT)
        history_for_membership['historyUpdatedAt'] = history_for_membership['historyUpdatedAt'].fillna(pd._libs.NaT)
        history_for_membership['historyUpdatedAtDeriv'] = history_for_membership['historyUpdatedAtShift'] - (
            history_for_membership['historyUpdatedAt'])
        temp = history_for_membership.groupby('brandId').apply(
            lambda x: [making_membership_history_dictionary(i[1]) for i in x.iterrows()])
        avgsubperiod = temp.reset_index(name='membershipHistory')
        subscribe = ['0 -> 1', '1 -> 2', '0 -> 2']
        subscribe_tape = avgsubperiod['membershipHistory'].apply(
            lambda x: [list(i.keys())[0] not in subscribe for i in x])
        pd.set_option('mode.chained_assignment', None)
        seller_subscribe = DataFrame()
        date_id = self.dm_series[['date']]
        date_id['date'] = date_id['date'].astype('datetime64')
        for num, avgsubperiod_row in avgsubperiod.iterrows():
            date_frame = DataFrame([list(i.values())[0] for i in avgsubperiod_row['membershipHistory']])
            if date_frame.shape[0] > 0:
                date_frame = pd.concat([date_frame, Series(subscribe_tape[num], name='isBounce')], axis=1)
                date_frame = date_frame.sort_values('historyUpdatedAtShift')
                date_frame['historyUpdatedAt'] = date_frame['historyUpdatedAt'].astype('datetime64')
                date_frame['historyUpdatedAtShift'] = date_frame['historyUpdatedAtShift'].astype('datetime64')
                date_frame = date_frame[date_frame['isBounce'] == False].reset_index(drop=True)
                if date_frame.shape[0] > 1:
                    startDate_shift = Series(
                        date_frame.loc[1: date_frame.shape[0] - 1, 'historyUpdatedAt'].reset_index(drop=True),
                        name='startDate_shift')
                elif date_frame.shape[0] == 1:
                    startDate_shift = Series(
                        date_frame.reset_index().loc[0, 'historyUpdatedAtShift'],
                        name='startDate_shift')
                else:
                    seller_subscribe = preprocessing_exception(avgsubperiod_row, date_id, seller_subscribe)
                    continue
                date_frame = pd.concat([date_frame, startDate_shift], axis=1)
                if date_frame.loc[date_frame.shape[0] - 1, 'isBounce'] == False:
                    date_frame.loc[date_frame.shape[0] - 1, 'startDate_shift'] = (
                        date_frame.loc[date_frame.shape[0] - 1, 'historyUpdatedAtShift'])
                date_frame = date_frame[~date_frame['startDate_shift'].isna()]
                if date_frame.shape[0] == 0:
                    seller_subscribe = preprocessing_exception(avgsubperiod_row, date_id, seller_subscribe)
                    continue
                TF_frame = DataFrame({'isSuccessive': (
                                                              date_frame['startDate_shift'] - date_frame[
                                                          'historyUpdatedAtShift']) < (
                                                          pd.Timedelta(threshold_membership, unit='D')),
                                      'isNegative': (
                                                            date_frame['startDate_shift'] - date_frame[
                                                        'historyUpdatedAtShift']) < (
                                                        pd.Timedelta(0, unit='D'))})
                date_frame = pd.concat([date_frame, TF_frame], axis=1)
                gen_group_num = generating_group_num()
                tape = list()
                group_num = 0
                for i in TF_frame.iterrows():
                    tape.append(group_num)
                    if (i[1]['isSuccessive'] == False) | (i[1]['isNegative'] == True):
                        group_num = next(gen_group_num)
                date_frame['group'] = tape
                temp = date_frame['historyUpdatedAtShift'].apply(lambda x: x < date_id['date'])
                temp.columns = date_id['date']
                temp.index = date_frame['historyUpdatedAtShift']
                date_frame = pd.merge(date_frame,
                                      temp.stack().reset_index(name='isoverdate'),
                                      on=['historyUpdatedAtShift'])
                date_frame['isBounce'] = (date_frame['isBounce'] == False)
                date_frame = date_frame.sort_values('historyUpdatedAtShift')

                # historyUpdatedAtShift 값으로  sorting을 했기 때문에, -1은 historyUpdatedAtShift가 가장 마지막인 값을 의미한다.
                group_tf = date_frame.groupby(['group', 'date'])[['isBounce', 'isoverdate']].apply(
                    lambda x: np.all(x.iloc[-1])).reset_index(name='getthisindex')
                membershipTerm = date_frame.groupby(['group', 'date'])['historyUpdatedAtDeriv'].apply(
                    lambda x: np.sum(x)).reset_index(
                    name='historyUpdatedAtDeriv')
                membershipTerm = pd.merge(group_tf, membershipTerm)
                membershipTerm.loc[membershipTerm['getthisindex'] == False, 'historyUpdatedAtDeriv'] = np.nan
                membershipTerm[['brandId']] = avgsubperiod_row[['brandId']]
                temp = date_frame.groupby('group')[['historyUpdatedAt', 'historyUpdatedAtShift']].apply(
                    lambda x: DataFrame([{'historyUpdatedAt': x.reset_index().loc[0, 'historyUpdatedAt'],
                                          'historyUpdatedAtShift': x.reset_index().loc[
                                              x.shape[0] - 1, 'historyUpdatedAtShift']}]))
                temp = temp.reset_index().drop('level_1', axis=1)
                membershipTerm = pd.merge(membershipTerm, temp, on=['group'], how='left')[
                    ['brandId',
                     'date',
                     'group',
                     'historyUpdatedAt',
                     'historyUpdatedAtShift',
                     'historyUpdatedAtDeriv']]
                seller_subscribe = pd.concat([seller_subscribe, membershipTerm])
            else:
                seller_subscribe = preprocessing_exception(avgsubperiod_row, date_id, seller_subscribe)
                continue
        pd.set_option('mode.chained_assignment', 'warn')
        avgsubperiod = seller_subscribe.groupby('date').apply(
            lambda x: np.nanmean(x['historyUpdatedAtDeriv'])
        ).reset_index(name='avgsubperiod')
        avgsubperiod['date'] = avgsubperiod['date'].dt.date.astype('str')
        self.dm_series = pd.merge(self.dm_series, avgsubperiod, on='date')
        seller_subscribe['getthisindex'] = ((seller_subscribe['historyUpdatedAtDeriv'].isna()) & (
                seller_subscribe['date'] > seller_subscribe['historyUpdatedAt'])) | (
                                               seller_subscribe['historyUpdatedAt'].isna())
        seller_subscribe.groupby(['brandId', 'group']).apply(
            lambda x: groupby_bounce_row_replacer(x)
        ).reset_index(drop=True)
        seller_subscribe_replace_row = seller_subscribe.groupby(
            ['brandId', 'group']).apply(
            lambda x: groupby_bounce_row_replacer(x)).reset_index(drop=True)
        total_count = seller_subscribe_replace_row.groupby('date')[
            ['getthisindex']].apply(
            lambda x: x[x['getthisindex']].count())
        bounce_count = seller_subscribe_replace_row[~seller_subscribe_replace_row['historyUpdatedAtDeriv'].isna() & (
            seller_subscribe_replace_row['getthisindex'])].groupby('date')['brandId'].apply(
            lambda x: x.count())
        count_table = pd.merge(total_count,
                               bounce_count,
                               left_index=True,
                               right_index=True, how='left')
        count_table['bounce_rate'] = (
                count_table['brandId'] / count_table['getthisindex'])
        count_table = count_table.reset_index()
        count_table.columns = ['date', 'currentActive', 'bounce', 'bounce_rate']
        subdate = list()
        for i in seller_subscribe_replace_row['brandId'].unique():
            subdate.extend(seller_subscribe_replace_row[(seller_subscribe_replace_row['brandId'] == i) & (
                seller_subscribe_replace_row['historyUpdatedAtDeriv'].isna()) & (
                                                            seller_subscribe_replace_row['getthisindex']) & (
                                                            ~seller_subscribe_replace_row[
                                                                'historyUpdatedAt'].isna())].iloc[:1]['date'] - (
                               pd.Timedelta(1, unit='D')))
        subdate = Series(subdate, name='date')
        subdate = subdate.value_counts().reset_index()
        subdate.columns = ['date', 'subscribe']
        count_table = pd.merge(count_table,
                               subdate, on='date',
                               how='outer')
        count_table['date'] = count_table['date'].astype('str')
        count_table = count_table.fillna(0)
        self.dm_series = pd.merge(self.dm_series,
                                  count_table,
                                  on='date', how='left')
        print(f'membership : {time.time() - start_time}')

        # ----- MEMBERSHIP END -------- #

        # --------- priorProcessing START ---------#
        self.dm_series[['cumSKU',
                        'totalOrder',
                        'totalTransaction',
                        'totalOrderQuantity',
                        'totalTranscationQuantity',
                        'cumTransactionMonthly',
                        'cumOrderMonthly',
                        'cumOrderQuantityMonthly',
                        'cumTranscationQuantityMonthly',
                        'avgsubperiod',
                        'currentActive',
                        'bounce',
                        'bounce_rate',
                        'subscribe']] = self.dm_series[['cumSKU',
                                                        'totalOrder',
                                                        'totalTransaction',
                                                        'totalOrderQuantity',
                                                        'totalTranscationQuantity',
                                                        'cumTransactionMonthly',
                                                        'cumOrderMonthly',
                                                        'cumOrderQuantityMonthly',
                                                        'cumTranscationQuantityMonthly',
                                                        'avgsubperiod',
                                                        'currentActive',
                                                        'bounce',
                                                        'bounce_rate',
                                                        'subscribe']].astype('float')