from pandas import DataFrame, Series
import pandas as pd
import psycopg2

from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.text import MIMEText
from smtplib import SMTP_SSL
from pathlib import Path

class DatamartMaker():

    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, client):
        self._phase = set()
        self._has_nosql = False
        self.client = client
        self.connect(host_ip, DBname, port, username, password)
        self.connect_email(email_id, email_pw)
        self.email_id = email_id

    def connect_email(self, email_id, email_pw):
        self.smtp = SMTP_SSL('smtp.gmail.com', 465)
        self.smtp.login(email_id, email_pw)

    def connect(self, host_ip, DBname, port, username, password):

        conn = psycopg2.connect(f"host={host_ip} " + (
                                f"port={port} ") + (
                                f"user={username} ") + (
                                f"password={password} ") + (
                                f"dbname={DBname}"))
        self.curs = conn.cursor()

        self.db_datamart = self.client['datamart']

    def __setattr__(self, name, value):
        if isinstance(value, dict):
            self._phase.add(name)
        if name == "NOSQL":
            self._has_nosql = True
        super().__setattr__(name, value)

    def load_table(self):
        for name in self._phase:
            SQL = self.__dict__[name]['SQL']
            columns = self.__dict__[name]['columns']
            self.curs.execute(SQL)
            temp = DataFrame(self.curs)
            if temp.shape[0] >= 1:
                temp.columns = columns
            else:
                temp = DataFrame(columns=columns)
            self.__dict__[f'dataframe_{name}'] = temp
            print(f'Table : {name} Load Complete')

        if self._has_nosql:
            for name in self.__dict__['NOSQL']:
                collection = self.db_datamart[name]
                temp = collection.find()
                self.__dict__[f'dataframe_{name}'] = DataFrame(temp)
                print(f'Table : {name} Load Complete')

    def run(self):
        raise NotImplementedError()

    def send_email(self, FROM, contents_file, patch=None):
        subject = pd.read_csv(contents_file)
        for _, i in subject.iterrows():
            msg = MIMEMultipart()
            msg["FROM"] = FROM
            msg["to"] = i['address']
            msg['subject'] = i['subject']
            message = i['contents']
            self.msg = msg
            if patch is not None:
                if isinstance(patch, str):
                    with open(patch, 'rb') as f:
                        filename = patch
                        attachment = MIMEApplication(f.read())
                        attachment["Content-Disposition"] = 'attachment; filename=" {}"'.format(
                            f"{Path(filename).name}")
                if isinstance(patch, (DataFrame, Series)):
                    filename = f'{patch=}'.split('=')[0]
                    attachment = MIMEApplication(patch.to_csv())
                    attachment["Content-Disposition"] = 'attachment; filename=" {}"'.format(f"{filename}.csv")
                msg.attach(attachment)
                msg.attach(MIMEText(message, "html"))
                self.smtp.sendmail(msg["FROM"], msg["to"], msg.as_string())

        if patch is None:
            raise Exception('Please attach file on e-mail')

    def reset_smtp(self, email_id, email_pw):
        self.smtp.close()
        self.connect_email(email_id, email_pw)