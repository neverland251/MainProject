from engine import DatamartMaker
import pandas as pd
from pandas import DataFrame, Series
import numpy as np
import datetime
import time


class DM_SELLERMaker(DatamartMaker):

    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, from_date, to_date, client):
        super().__init__(host_ip, DBname, port, username, password, email_id, email_pw, client)
        self.from_date = from_date
        self.to_date = to_date

    def load_table(self, demo_test=False):

        # ---- SQL Query Start ----- #

        self.users = {'SQL': "SELECT \"id\"," + (
                                 "\"status\",") + (
                                 "\"roles\",") + (
                                 "\"createdAt\",") + (
                                 "\"updatedAt\",") + (
                                 "\"type\",") + (
                                 "\"isActive\",") + (
                                 "\"lastLoginAt\" FROM users"),
                      'columns': ['sellerId',
                                  'status',
                                  'roles',
                                  'createdAt',
                                  'updatedAt',
                                  'type',
                                  'isActive',
                                  'lastLoginAt']}

        self.history = {'SQL': "SELECT \"target_id\"," + (
                                    "\"key\",") + (
                                   "\"before\",") + (
                                   "\"after\",") + (
                                   "\"updated_at\" FROM tb_update_history ") + (
                                   "where \"key\"='membership'"),
                        'columns': ['brandId',
                                    'key',
                                    'before',
                                    'after',
                                    'historyUpdatedAt']}

        self.brand = {'SQL': "SELECT \"id\"," + (
                                    "\"sellerId\",") + (
                                    "\"name\",") + (
                                    "\"status\",") + (
                                    "\"membership\",") + (
                                    "\"membershipStatus\",") + (
                                    "\"beforeMembership\",") + (
                                    "\"updatedAt\",") + (
                                    "\"data\"") + (
                                    "FROM brands"),
                      'columns': ['brandId',
                                  'sellerId',
                                  'name',
                                  'status_brand',
                                  'membership',
                                  'membershipStatus',
                                  'beforeMembership',
                                  'brandUpdatedAt',
                                  'data_brand']}

        self.shipment_all = {'SQL': "select \"buyerId\"," + (
            "\"brandId\", ") + (
                                        "\"orderProductId\",") + (
                                        "\"quantity\",") + (
                                        "\"finalQuantity\",") + (
                                        "\"createdAt\",") + (
                                        "\"updatedAt\",") + (
                                        "\"isLatest\"") + (
                                        " from wait_shipment_logs where ") + (
                                        # "\"isLatest\" = 'Y' AND ") + (
                                        f"\"createdAt\" > '{self.from_date}' AND ") + (
                                        f"\"createdAt\" < '{self.to_date}'"),
                             'columns': ['buyerId',
                                         'brandId',
                                         'orderProductId',
                                         'quantity',
                                         'finalQuantity',
                                         'createdAt',
                                         'updatedAt',
                                         'isLatest']}

        self.sku = {'SQL': "select  " + (
                                    "\"brand\"") + (
                               " from products WHERE ") + (
                               f"\"createdAt\" > '{self.from_date}' AND ") + (
                               f"\"createdAt\" < '{self.to_date}'"),
                    'columns': ['brand']}

        self.order = {'SQL': "select \"id\"," + (
            "\"buyerId\",") + (
                                 "\"brand\", ") + (
                                 "\"totalKRW\",") + (
                                 "\"finalTotalKRW\",") + (
                                 "\"finalQuantity\",") + (
                                 "\"quantity\",") + (
                                 "\"createdAt\"") + (
                                 " from order_products WHERE ") + (
                                 f"\"createdAt\" > '{self.from_date}' AND ") + (
                                 f"\"createdAt\" < '{self.to_date}'"),
                      'columns': ['orderProductId',
                                  'buyerId',
                                  'brand',
                                  'cusumOrderAmount',
                                  'cusumPurchaseAmount',
                                  'cusumPurchaseQuantity',
                                  'cusumOrderQuantity',
                                  'createdAt']}

        # ---- SQL Query END ----- #

        super().load_table()

        if demo_test:
            self.dataframe_history = pd.concat(
                [self.dataframe_history,
                 pd.DataFrame({'brandId': self.dataframe_history['brandId'],
                               'key': self.dataframe_history['key'],
                               'historyUpdatedAt': self.dataframe_history['historyUpdatedAt'] + (
                                   pd.Timedelta(180, unit='day')),
                               'before': self.dataframe_history['after'],
                               'after': self.dataframe_history['before']})
                 ]).reset_index(drop=True)

    def run(self, threshold_active=365, threshold_shipment=10):

        def type_extractor(x, types, recursive=None):
            try:
                if recursive is None:
                    return x[0][types]
                else:
                    return type_extractor([x[0][types]],
                                          types=recursive)
            except:
                return 'NaN'

        def history_date_shifter(x):
            x = x.reset_index(drop=True)
            x = x.sort_values('historyUpdatedAt')
            if x.shape[0] > 1:
                x['historyUpdatedAtShift'] = x.iloc[1:, col_where[0]].reset_index(drop=True)
            else:
                x['historyUpdatedAtShift'] = pd._libs.tslibs.nattype.NaTType()
            return x

        def making_membership_history_dictionary(x):
            dictionary = dict()
            keys = str(int(x['before'])) + ' -> ' + str(int(x['after']))
            history_dict = pd.concat([x[['historyUpdatedAt', 'historyUpdatedAtShift']].astype('str'),
                                      Series(x['historyUpdatedAtDeriv'].days,
                                             index=['historyUpdatedAtDeriv'])]).to_dict()
            if (isinstance(history_dict, float) != True):
                if not isinstance(x['historyUpdatedAtDeriv'],
                                  (type(pd._libs.NaT), type(np.nan))):
                    dictionary[keys] = history_dict
                    return dictionary

        def making_overshipped_history_dictionary(x):
            dictionary = dict()
            keys = str(x['orderProductId'])
            history_dict = x[['quantity', 'finalQuantity', 'derivQuantity']].to_dict()
            if isinstance(history_dict, float) != True:
                dictionary[keys] = history_dict
                return dictionary

        def wait_term(x):
            x = x.sort_values(by='createdAt')
            init_date = x.iloc[0, createdAt_where]
            last_date = x.iloc[-1, createdAt_where]
            term = last_date - init_date
            # 한시간 이내에 추가 사입이 발생한 경우는 데이터 오류로 취급하여 제외한다.
            if term.components.hours > 1:
                return {'wait_term': str(term),
                        'shipment_try': len(x),
                        'is_long_term': str(term.days > threshold_shipment)}

        def making_waitshipment_history_dictionary(x):
            dictionary = dict()
            keys = str(x['orderProductId'].unique()[0])
            history_dict = x['shipment_term'].iloc[0]
            if isinstance(history_dict, dict):
                dictionary[keys] = history_dict
                return dictionary

        if not hasattr(self, 'dataframe_users'):
            self.load_table()

        dataframe_shipment = self.dataframe_shipment_all[
            self.dataframe_shipment_all['isLatest'] == 'Y'].drop(['createdAt', 'updatedAt'], axis=1)

        # -------- dm_seller start ---------#

        start_time = time.time()
        dataframe_brand = self.dataframe_brand.copy()
        self.dm_seller = self.dataframe_users[self.dataframe_users['roles'].apply(
            lambda x: type_extractor(x, 'type')) == 'owner']
        dataframe_brand['name'] = dataframe_brand['name'].apply(lambda x: type_extractor([x], 'ko'))
        self.dm_seller = pd.merge(self.dm_seller, dataframe_brand, on='sellerId')
        self.dm_seller['building'] = self.dm_seller['data_brand'].apply(lambda x: type_extractor(
                                                            [type_extractor([x], 'location', recursive='building')],
                                                            'name', recursive='ko'))
        print(f'dm_seller : {time.time() - start_time}')

        # ------- dm_seller END -----------#

        # sinceLastLogined
        start_time = time.time()
        last_login_seller = self.dm_seller[self.dm_seller['roles'].apply(
            lambda x: type_extractor(x, 'type')) == 'owner'][['lastLoginAt',
                                                              'isActive',
                                                              'status',
                                                              'status_brand']]
        user_isactive = last_login_seller['isActive']
        user_not_approval_member = last_login_seller['status']
        user_brand_closed = last_login_seller['status_brand']
        last_login_seller = last_login_seller['lastLoginAt'].apply(
            lambda x: x.tz_convert('Asia/Seoul'))
        last_login_seller = (pd.Timestamp(datetime.datetime.now(), tz='Asia/Seoul') - last_login_seller).apply(
            lambda x: x.days)
        # 최종 로그인 정보가 없어 NaN인 경우 -9999로 처리
        last_login_seller = last_login_seller.fillna(-9999)
        # is_active가 False인 경우 -9999로 처리
        last_login_seller.loc[user_isactive == False] = -9999
        # Status가 100(가입 승인)이 아닌 경우 -9999로 처리
        last_login_seller.loc[user_not_approval_member != 100] = -9999
        # brand Status가 100이 아닌경우 -9999로 처리
        last_login_seller.loc[user_brand_closed != 100] = -9999
        last_login_seller.name = 'sinceLastLogined'
        self.dm_seller = pd.concat([self.dm_seller, last_login_seller], axis=1)
        print(f'sinceLastLogined : {time.time() - start_time}')

        # -------- sinceLastLogined END ---------#

        # -------- Activeuser start ---------#

        start_time = time.time()
        activeYn = Series((last_login_seller == -9999) | (
                last_login_seller > threshold_active), name='activeYn')
        self.dm_seller = pd.concat([self.dm_seller, activeYn], axis=1)
        print(f'Activeuser : {time.time() - start_time}')

        # -------- Activeuser end ---------#

        # ------- membership start --------#

        start_time = time.time()
        dataframe_brand_history_seller = pd.merge(self.dm_seller, self.dataframe_history,
                                                  on=['brandId'])
        value_replace = dataframe_brand_history_seller['roles'].apply(lambda x: type_extractor(x,
                                                                                               types='brand',
                                                                                               recursive='id'))
        dataframe_brand_history_seller.loc[
            dataframe_brand_history_seller['brandId'].isna(), 'brandId'] = value_replace
        dm_seller_for_membership = dataframe_brand_history_seller.drop([
            'roles',
            'type',
            'isActive',
            'brandUpdatedAt'],
            axis=1)
        dm_seller_for_membership = dm_seller_for_membership[~dm_seller_for_membership[
            'key'].isna()].sort_values('historyUpdatedAt').reset_index()
        col_where = np.where(dm_seller_for_membership.columns == 'historyUpdatedAt')[0]
        dm_seller_for_membership = dm_seller_for_membership.groupby('brandId').apply(
            lambda x: history_date_shifter(x)).reset_index(drop=True)
        dm_seller_for_membership['historyUpdatedAtShift'] = dm_seller_for_membership['historyUpdatedAtShift'].fillna(
            pd._libs.NaT)
        dm_seller_for_membership['historyUpdatedAt'] = dm_seller_for_membership['historyUpdatedAt'].fillna(pd._libs.NaT)

        dm_seller_for_membership['historyUpdatedAtDeriv'] = dm_seller_for_membership.apply(
            lambda x: x['historyUpdatedAtShift'] - x['historyUpdatedAt'], axis=1)
        dm_seller_for_membership['activeYn'] = 'Y'
        dm_seller_for_membership.set_index('index', inplace=True)
        dm_seller_for_membership.index.name = ''
        brandId = dm_seller_for_membership['brandId'].unique()
        history_frame = DataFrame()
        for i in brandId:
            temp = dm_seller_for_membership[dm_seller_for_membership['brandId'] == i]
            temp = temp[~temp['historyUpdatedAtShift'].isna()]
            if temp.shape[0] > 0:
                membership_history = list(temp.apply(
                    lambda x: making_membership_history_dictionary(x), axis=1))

                membership_history = [i for i in membership_history if i is not None]
                before_membership_date = [list(i.values())[0]['historyUpdatedAt'] for i in membership_history]
                if len(before_membership_date) > 1:
                    before_membership_date = before_membership_date[len(before_membership_date) - 2]
                elif len(before_membership_date) == 1:
                    before_membership_date = before_membership_date
                else:
                    before_membership_date = np.nan
                before_membership_due = [list(i.values())[0]['historyUpdatedAtShift'] for i in membership_history]
                if len(before_membership_due) > 1:
                    before_membership_due = before_membership_due[len(before_membership_due) - 2]
                elif len(before_membership_due) == 1:
                    before_membership_due = before_membership_due
                else:
                    before_membership_due = np.nan
                membership_term = [list(i.values())[0]['historyUpdatedAtDeriv'] for i in membership_history]
                if len(membership_term) > 1:
                    membership_term = membership_term[len(membership_term) - 2]
                elif len(membership_term) == 1:
                    membership_term = membership_term
                else:
                    membership_term = np.nan
                if isinstance(membership_term, pd._libs.NaTType):
                    print(membership_term)
                temp = DataFrame({'brandId': i,
                                  'membershipHistory': [membership_history],
                                  'before_membership_date': before_membership_date,
                                  'before_membership_due': before_membership_due,
                                  'membership_term': membership_term
                                  })
                history_frame = pd.concat([history_frame, temp])
        self.dm_seller = pd.merge(self.dm_seller, history_frame, how='left')
        print(f'membership : {time.time() - start_time}')

        # --------- membership END ----------#

        # --------- overshipped START --------- #

        start_time = time.time()
        dataframe_order = self.dataframe_order.copy()
        dataframe_order['brandId'] = dataframe_order['brand'].apply(
            lambda x: type_extractor([x], 'id'))
        dataframe_order['derivQuantity'] = dataframe_order.apply(
            lambda x: x['cusumOrderQuantity'] - x['cusumPurchaseQuantity'], axis=1)
        dataframe_overshipped = dataframe_order.loc[
                                dataframe_order['derivQuantity'] < 0, :].reset_index(drop=True)
        dataframe_overshipped = dataframe_overshipped.rename(
            {'cusumOrderQuantity': 'quantity',
             'cusumPurchaseQuantity': 'finalQuantity'}, axis=1)
        brandId = dataframe_overshipped['brandId'].unique()
        history_frame = DataFrame()
        for i in brandId:
            temp = dataframe_overshipped[dataframe_overshipped['brandId'] == i]
            overshipped_history = list(temp.apply(
                lambda x: making_overshipped_history_dictionary(x), axis=1))
            overshipped_history = [i for i in overshipped_history if i is not None]
            temp = DataFrame({'brandId': i,
                              'overshippedHistory': [overshipped_history],
                              'cumsumOvershipped': len(overshipped_history)})
            history_frame = pd.concat([history_frame, temp])
        self.dm_seller = pd.merge(self.dm_seller, history_frame, on='brandId', how='left')

        print(f'overshipped : {time.time() - start_time}')
        # --------- overshipped END --------- #

        # --------- order,transaction START --------- #

        start_time = time.time()
        dataframe_order = self.dataframe_order.copy()
        dataframe_order['brandId'] = dataframe_order['brand'].apply(
            lambda x: type_extractor([x], 'id'))
        self.dm_seller = pd.merge(self.dm_seller,
                                  pd.concat([dataframe_order.groupby('brandId')['cusumOrderAmount'].sum(),
                                             dataframe_order.groupby('brandId')['cusumPurchaseAmount'].sum(),
                                             dataframe_order.groupby('brandId')['cusumOrderQuantity'].sum(),
                                             dataframe_order.groupby('brandId')['cusumPurchaseQuantity'].sum()],
                                            axis=1).reset_index(),
                                  on='brandId',
                                  how='left')
        print(f'order,transaction : {time.time() - start_time}')

        # --------- order,transaction END --------- #

        # --------- sku count START --------- #

        start_time = time.time()
        sku_count = self.dataframe_sku['brand'].apply(
            lambda x: type_extractor([x], 'id')).value_counts()
        sku_count.index.name = 'brandId'
        sku_count.name = 'uploadedSku'
        sku_count = sku_count.reset_index()
        self.dm_seller = pd.merge(self.dm_seller,
                                  sku_count,
                                  on='brandId',
                                  how='left')
        print(f'sku_count : {time.time() - start_time}')

        # --------- sku count END --------- #

        # ---------wait_shipment START --------- #

        start_time = time.time()
        dataframe_shipment_all = self.dataframe_shipment_all.copy()
        dataframe_shipment_all_reduced = pd.merge(Series(
            dataframe_shipment_all.groupby('orderProductId')['isLatest'].count() > 1),
            dataframe_shipment_all,
            on='orderProductId')
        createdAt_where = int(np.where(dataframe_shipment_all_reduced.columns == 'createdAt')[0])
        dataframe_shipment_all_reduced = dataframe_shipment_all_reduced[
            dataframe_shipment_all_reduced['isLatest_x'] == True]
        self.dataframe_shipment_all_reduced = dataframe_shipment_all_reduced.sort_values(
            by='createdAt').reset_index(drop=True)
        dataframe_shipment_all_reduced = self.dataframe_shipment_all_reduced
        shipment_wait_term = dataframe_shipment_all_reduced.groupby(['orderProductId']).apply(
            lambda x: wait_term(x))
        dataframe_shipment_all = pd.merge(dataframe_shipment_all,
                                          Series(shipment_wait_term, name='shipment_term'),
                                          on='orderProductId',
                                          how='left')
        brandId = dataframe_shipment_all_reduced['brandId'].unique()
        history_frame = DataFrame()
        for i in brandId:
            temp = dataframe_shipment_all[dataframe_shipment_all['brandId'] == i]
            history_dict = temp.groupby('orderProductId').apply(
                lambda x: making_waitshipment_history_dictionary(x))
            history_dict = [i for i in history_dict if i is not None]
            avgWaitShipment = [list(i.values())[0]['shipment_try'] for i in history_dict]
            avgWaitTerm = [list(i.values())[0]['wait_term'] for i in history_dict]
            if len(avgWaitShipment) > 0:
                avgWaitShipment = np.mean(avgWaitShipment)
            else:
                avgWaitShipment = None
            if len(avgWaitTerm) > 0:
                avgWaitTerm = list(map(lambda x: pd.Timedelta(x), avgWaitTerm))
                avgWaitTerm = np.mean(avgWaitTerm).days
            else:
                avgWaitTerm = None
            temp = DataFrame({'brandId': i,
                              'waitshipmentHistory': [history_dict],
                              'avgWaitShipment': avgWaitShipment,
                              'avgWaitTerm': avgWaitTerm})
            history_frame = pd.concat([history_frame, temp])
        self.dm_seller = pd.merge(self.dm_seller, history_frame,
                                  on='brandId',
                                  how='left')
        print(f'wait_shipment : {time.time() - start_time}')

        # --------- wait_shipment END --------- #

        # --------- posterior Processing START ---------#
        self.dm_seller['lastLoginAt'] = self.dm_seller['lastLoginAt'].astype('str')
        self.dm_seller['sinceLastLogined'] = self.dm_seller['sinceLastLogined'].astype('int')
        self.dm_seller[['cumsumOvershipped',
                        'cusumOrderAmount',
                        'cusumPurchaseAmount',
                        'cusumOrderQuantity',
                        'cusumPurchaseQuantity',
                        'uploadedSku',
                        'avgWaitShipment']] = self.dm_seller[['cumsumOvershipped',
                                                              'cusumOrderAmount',
                                                              'cusumPurchaseAmount',
                                                              'cusumOrderQuantity',
                                                              'cusumPurchaseQuantity',
                                                              'uploadedSku',
                                                              'avgWaitShipment']].astype('float')
        self.dm_seller = self.dm_seller.drop(['roles',
                                              'type',
                                              'isActive',
                                              'status',
                                              'brandUpdatedAt',
                                              'data_brand'], axis=1)