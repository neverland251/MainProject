from engine import DatamartMaker
import pandas as pd
import numpy as np
from pandas import DataFrame, Series
import time

class DmOrderSeries(DatamartMaker):

    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, from_date, to_date, client):
        super().__init__(host_ip, DBname, port, username, password, email_id, email_pw, client)
        self.from_date = from_date
        self.to_date_seoul = pd.Timestamp(to_date, tz='UTC').tz_convert('Asia/Seoul')
        self.to_date = to_date

    def load_table(self, demo_test=False):

        self.user = {'SQL': "SELECT \"id\"," + (
                                "o.name") + (
                                " FROM users o WHERE o.roles @> '[{\"type\":\"buyer\"}]'"),
                     'columns': ['buyerId',
                                 'buyerName']
                     }

        self.brand = {'SQL': "SELECT \"id\"," + (
                                 "\"name\",") + (
                                 "\"data\"") + (
                                 " FROM brands"),
                      'columns': ['brandId',
                                  'brandName',
                                  'data']}

        self.order = {'SQL': "select \"id\"," + (
                                 "\"processedDate\",") + (
                                 "\"address\",") + (
                                 "\"handlingFeeKRW\",") + (
                                 "\"taxKRW\",") + (
                                 "\"status\"") + (
                                 " from orders WHERE ") + (
                                 f"\"createdAt\" >= '{self.from_date}' AND ") + (
                                 f"\"createdAt\" < '{self.to_date_seoul}'"),
                      'columns': ['orderId',
                                  'processedDate',
                                  'address',
                                  'handlingFeeKRW',
                                  'taxKRW',
                                  'status_order']}

        self.fee = {'SQL': "SELECT \"order_id\"," + (
            "\"dc_order_shipping_cost_amount\",") + (
                               "\"dc_wait_shipment_shipping_cost_amount\",") + (
                               "\"order_shipping_cost_amount\",") + (
                               "\"wait_shipment_shipping_cost_amount\",") + (
                               "\"created_at\"") + (
                               "FROM tb_order_fee WHERE ") + (
                               f"\"created_at\" >= '{self.from_date}' AND ") + (
                               f"\"created_at\" < '{self.to_date_seoul}'"),
                    'columns': ['orderId',
                                'dcOrderShipping',
                                'dcWaitShipping',
                                'orderShipping',
                                'waitShipping',
                                'created_at']}

        self.order_prod = {'SQL': "select \"id\"," + (
                                      "\"orderId\",") + (
                                      "\"product\",") + (
                                      "\"buyerId\",") + (
                                      "\"brand\",") + (
                                      "\"quantity\",") + (
                                      "\"finalQuantity\",") + (
                                      "\"KRW\",") + (
                                      "\"finalKRW\",") + (
                                      "\"cmUnclePickupQuantity\",") + (
                                      "\"cmInspectionQuantity\",") + (
                                      "\"waitShipmentType\",") + (
                                      "\"waitShipmentStatus\",") + (
                                      "\"settledPrice\",") + (
                                      "\"settledQuantity\",") + (
                                      "\"status\",") + (
                                      "\"data\"->'memo',") + (
                                      "\"createdAt\"") + (
                                      " from order_products WHERE ") + (
                                      f"\"createdAt\" >= '{self.from_date}' AND ") + (
                                      f"\"createdAt\" < '{self.to_date_seoul}'"),
                           'columns': ['orderProductId',
                                       'orderId',
                                       'product',
                                       'buyerId',
                                       'brand',
                                       'quantity',
                                       'finalQuantity',
                                       'initKRW',
                                       'finalKRW',
                                       'unclepickup',
                                       'inspection_quantity',
                                       'waitShipmentType',
                                       'waitShipmentStatus',
                                       'settledPrice',
                                       'settledQuantity',
                                       'status_order_prod',
                                       'memo',
                                       'createdAt']}
        self.prod_fee = {'SQL': "select \"id\"," + (
                                    "\"order_id\",") + (
                                    "\"item_id\",") + (
                                    "\"unit_product_supply\",") + (
                                    "\"unit_final_product_supply\",") + (
                                    "\"unit_handling_fee_amount\",") + (
                                    "\"unit_quality_inspection_fee_amount\",") + (
                                    "\"unit_product_vat\",") + (
                                    "\"unit_final_product_vat\",") + (
                                    "\"dc_unit_product_supply\",") + (
                                    "\"dc_unit_handling_fee_amount\",") + (
                                    "\"dc_unit_quality_inspection_fee_amount\",") + (
                                    "\"dc_unit_product_vat\",") + (
                                    "\"created_at\"") + (
                                    " from tb_order_product_fee WHERE ") + (
                                    f"\"created_at\" >= '{self.from_date}' AND ") + (
                                    f"\"created_at\" < '{self.to_date_seoul}'"),
                         'columns': ['prodFeeId',
                                     'orderId',
                                     'orderProductId',
                                     'unit_product_supply',
                                     'unit_final_product_supply',
                                     'unit_handling_fee_amount',
                                     'unit_quality_inspection_fee_amount',
                                     'unit_product_vat',
                                     'unit_final_product_vat',
                                     'dc_unit_product_supply',
                                     'dc_unit_handling_fee_amount',
                                     'dc_unit_quality_inspection_fee_amount',
                                     'dc_unit_product_vat',
                                     'created_at']}

        self.exhibition = {'SQL': "select \"id\"," + (
                                      "\"name\",") + (
                                      "\"path\",") + (
                                      "\"description\",") + (
                                      "\"start_at\",") + (
                                      "\"end_at\",") + (
                                      "\"use_yn\",") + (
                                      "\"deleted\",") + (
                                      "\"created\",") + (
                                      "\"updated\"") + (
                                      " from tb_exhibition"),

                           'columns': ['exhibition',
                                       'name',
                                       'path',
                                       'description',
                                       'start_at',
                                       'end_at',
                                       'use_yn',
                                       'deleted',
                                       'created_exhibit',
                                       'terminated_date']}

        self.exhibition_product = {'SQL': "select " + (
                                              "\"id\",") + (
                                              "\"exhibition\",") + (
                                              "\"product\",") + (
                                              "\"created\"") + (
                                              " from tb_exhibition_product"),
                                   'columns': ['exhibition_prod_id',
                                               'exhibition',
                                               'productId',
                                               'created_exhibit_prod']}

        self.tbl_shipment = {'SQL': "select " + (
                                        "\"order_id\",") + (
                                        " shipping_cost,") + (
                                        " tracking_number ") + (
                                        "from tb_tpl_shipment where ") + (
                                        f"\"created_at\" >= '{self.from_date}' AND ") + (
                                        "\"use_yn\" = 'Y'"),
                             'columns': ['orderId',
                                         'finalShippingCost',
                                         'tracking_number']
                             }

        super().load_table()

    def run(self, threshold_active=365, start_point=400, end_point=1, offset=20):

        def type_extractor(x, types, recursive=None):
            try:
                if recursive is None:
                    return x[0][types]
                else:
                    return type_extractor([x[0][types]],
                                          types=recursive)
            except:
                return 'NaN'

        def list_merge_by_columns(x, columns):
            result = x[columns].apply(lambda x: [x.to_list()], axis=0)
            return result

        def list_merge_various_exhibit(x, columns=None):

            if columns is None:
                columns = ['name',
                           'path',
                           'description',
                           'exhibition',
                           'created_exhibit_prod',
                           'exhibition_prod_id',
                           'created_exhibit',
                           'terminated_date',
                           'due_terminated',
                           'isExhibitionIncluded']
            result_frame = x[x['orderProductId'].duplicated(keep=False)].groupby('orderProductId').apply(
                lambda x: list_merge_by_columns(x, columns))

            result_frame.index.name = 'orderProductId'
            result_frame.columns = columns
            result_frame = result_frame.reset_index()

            result_frame = pd.merge(x.drop(columns, axis=1).drop_duplicates('orderProductId', keep='first'),
                                    result_frame,
                                    how='right',
                                    on='orderProductId')
            x = x.drop_duplicates('orderProductId', keep=False).reset_index(drop=True)

            result_frame = pd.concat([result_frame, x], axis=0).reset_index(drop=True)
            return result_frame

        if not hasattr(self, 'dataframe_exhibition_product'):
            self.load_table()

        # -------DM_Merchandise START---------- #

        start_time = time.time()

        self.dm_orderseries = self.dataframe_order_prod.copy()

        dataframe_brand = self.dataframe_brand.copy()
        dataframe_user = self.dataframe_user.copy()
        dataframe_order = self.dataframe_order.copy()
        dataframe_order['countryCode'] = dataframe_order['address'].apply(lambda x: type_extractor([x], 'countryCode'))
        dataframe_brand['brandName'] = dataframe_brand['brandName'].apply(
            lambda x: type_extractor([x], 'ko'))
        dataframe_brand['building'] = dataframe_brand['data'].apply(
            lambda x: type_extractor(
                [type_extractor([x], 'location', recursive='building')],
                'name', recursive='ko'))
        self.dm_orderseries['product'] = self.dm_orderseries['product'].apply(lambda x: type_extractor([x], 'id'))
        self.dm_orderseries['brand'] = self.dm_orderseries['brand'].apply(lambda x: type_extractor([x], 'id'))
        self.dm_orderseries = self.dm_orderseries.rename({'product': 'productId',
                                                          'brand': 'brandId'}, axis=1)
        self.dm_orderseries = pd.merge(self.dm_orderseries,
                                       dataframe_brand.drop(['data'], axis=1),
                                       on=['brandId'])
        self.dm_orderseries = pd.merge(self.dm_orderseries,
                                       dataframe_user,
                                       on=['buyerId'],
                                       how='left')
        self.dm_orderseries = pd.merge(self.dm_orderseries,
                                       dataframe_order[['orderId',
                                                        'countryCode',
                                                        'status_order',
                                                        'processedDate']],
                                       on='orderId',
                                       how='left')
        print(f'dm_orderseries : {time.time() - start_time}')

        start_time = time.time()
        dataframe_exhibit = self.dataframe_exhibition.rename({'id': 'exhibition',
                                                              'updated': 'terminated_date'}, axis=1)
        dataframe_exhibit_prod = self.dataframe_exhibition_product.rename({'id': 'exhibition_prod_id',
                                                                           'product': 'productId'}, axis=1)
        exhibit_prod_merge = pd.merge(dataframe_exhibit,
                                      dataframe_exhibit_prod,
                                      on='exhibition',
                                      suffixes=('_exhibit', '_exhibit_prod'))
        exhibit_prod_merge.loc[exhibit_prod_merge['use_yn'] == 'Y', 'terminated_date'] = pd._libs.NaT
        exhibit_prod_merge = exhibit_prod_merge[['exhibition',
                                                 'name',
                                                 'path',
                                                 'description',
                                                 'use_yn',
                                                 'deleted',
                                                 'created_exhibit',
                                                 'terminated_date',
                                                 'exhibition_prod_id',
                                                 'productId',
                                                 'created_exhibit_prod']]
        temp_frame = pd.merge(self.dm_orderseries, exhibit_prod_merge, how='left', on='productId')
        temp_frame['due_terminated'] = (temp_frame['createdAt'] < temp_frame['terminated_date'])
        temp_frame.loc[temp_frame['use_yn'] == 'Y', 'due_terminated'] = True
        temp_frame['isExhibitionIncluded'] = (temp_frame['createdAt'] > temp_frame['created_exhibit_prod']) & (
            temp_frame['due_terminated'])
        temp_frame = list_merge_various_exhibit(temp_frame)
        temp_frame = temp_frame.rename({'name': 'exhibitionName',
                                        'path': 'exhibitionPath',
                                        'description': 'exhibitionDescription',
                                        'exhibition': 'exhibitionNum'},
                                       axis=1)
        self.dm_orderseries = pd.merge(self.dm_orderseries,
                                       temp_frame[['orderProductId',
                                                   'exhibitionName',
                                                   'exhibitionPath',
                                                   'exhibitionDescription',
                                                   'exhibitionNum',
                                                   'isExhibitionIncluded']],
                                       how='left',
                                       on='orderProductId')
        print(f'exhibition : {time.time() - start_time}')

        start_time = time.time()
        order_prod_fee = pd.merge(self.dataframe_order_prod,
                                  self.dataframe_prod_fee,
                                  on=['orderProductId', 'orderId'],
                                  how='left')
        order_prod_fee_bulk = order_prod_fee[order_prod_fee['created_at'].isna()].reset_index(drop=True)
        order_prod_fee_bulk['KRW'] = order_prod_fee_bulk['initKRW'].copy()
        order_prod_fee_bulk.loc[~order_prod_fee_bulk['finalKRW'].isna(), 'KRW'] = \
                order_prod_fee_bulk.loc[~order_prod_fee_bulk['finalKRW'].isna(), 'finalKRW']
        order_prod_fee = order_prod_fee[~order_prod_fee['created_at'].isna()].reset_index(drop=True)

        order_prod_fee_final = order_prod_fee.copy()
        order_prod_fee_final.loc[~order_prod_fee_final['unit_final_product_supply'].isna(), 'unit_product_supply'] = (
            order_prod_fee_final.loc[
                ~order_prod_fee_final['unit_final_product_supply'].isna(), 'unit_final_product_supply'])
        order_prod_fee_final.loc[~order_prod_fee_final['unit_final_product_supply'].isna(), 'unit_product_vat'] = (
            order_prod_fee_final.loc[
                ~order_prod_fee_final['unit_final_product_supply'].isna(), 'unit_final_product_vat'])
        order_prod_fee_final[['unit_quality_inspection_fee_amount',
                              'unit_handling_fee_amount',
                              'unit_product_supply',
                              'inspection_quantity',
                              'unit_product_vat']] = order_prod_fee_final[['unit_quality_inspection_fee_amount',
                                                                           'unit_handling_fee_amount',
                                                                           'unit_product_supply',
                                                                           'inspection_quantity',
                                                                           'unit_product_vat']].astype('float')

        order_prod_fee_final['finalQualityInspectionFee'] = order_prod_fee_final['inspection_quantity'] * (
            order_prod_fee_final['unit_quality_inspection_fee_amount'])
        order_prod_fee_final['finalHandlingFee'] = order_prod_fee_final['finalQuantity'] * (
            order_prod_fee_final['unit_handling_fee_amount'])
        order_prod_fee_final['finalSubtotal'] = order_prod_fee_final['finalQuantity'] * (
            order_prod_fee_final['unit_product_supply'])
        order_prod_fee_final['finalTax'] = order_prod_fee_final['finalQuantity'] * (
            order_prod_fee_final['unit_product_vat'])
        order_prod_fee_final['finalTotalKRW'] = order_prod_fee_final['finalQualityInspectionFee'].fillna(0) + (
                                                    order_prod_fee_final['finalHandlingFee']).fillna(0) + (
                                                    order_prod_fee_final['finalSubtotal']).fillna(0) + (
                                                    order_prod_fee_final['finalTax'].fillna(0))

        order_prod_fee_final = order_prod_fee_final[['orderProductId',
                                                     'orderId',
                                                     'buyerId',
                                                     'finalQualityInspectionFee',
                                                     'finalHandlingFee',
                                                     'finalSubtotal',
                                                     'finalTax',
                                                     'finalTotalKRW',
                                                     'createdAt']]
        order_prod_fee_bulk['finalTotalKRW'] = order_prod_fee_bulk['finalQuantity'] * (
            order_prod_fee_bulk['finalKRW'].astype('float'))
        order_prod_fee_final = pd.concat([order_prod_fee_final,
                                          order_prod_fee_bulk[['orderProductId', 'orderId', 'buyerId',
                                                               'createdAt', 'finalTotalKRW']]]).reset_index(drop=True)

        self.dm_orderseries = pd.merge(self.dm_orderseries,
                                       order_prod_fee_final.drop(['createdAt', 'buyerId'], axis=1),
                                       on=['orderProductId', 'orderId'])
        print(f'final : {time.time() - start_time}')

        start_time = time.time()
        order_prod_fee_init = order_prod_fee.copy()
        order_prod_fee_init['product'] = order_prod_fee_init['product'].apply(lambda x: type_extractor([x], 'id'))
        order_prod_fee_init['brand'] = order_prod_fee_init['brand'].apply(lambda x: type_extractor([x], 'id'))
        order_prod_fee_init = order_prod_fee_init.rename({'product': 'productId',
                                                          'brand': 'brandId'}, axis=1)
        order_prod_fee_init['initHandlingFee'] = order_prod_fee_init['quantity'] * (
            order_prod_fee_init['unit_handling_fee_amount'])
        order_prod_fee_init['initQualityInspectionFee'] = order_prod_fee_init['quantity'] * (
            order_prod_fee_init['unit_quality_inspection_fee_amount'])
        order_prod_fee_init['initSubtotal'] = order_prod_fee_init['quantity'] * (
            order_prod_fee_init['unit_product_supply'])
        order_prod_fee_init['initTax'] = order_prod_fee_init['quantity'] * (
            order_prod_fee_init['unit_product_vat'])
        order_prod_fee_init['initTotalKRW'] = order_prod_fee_init['initQualityInspectionFee'] + (
            order_prod_fee_init['initHandlingFee']) + (
                                                  order_prod_fee_init['initSubtotal']) + (
                                                  order_prod_fee_init['initTax'])
        order_prod_fee_init = order_prod_fee_init[['orderProductId',
                                                   'orderId',
                                                   'productId',
                                                   'buyerId',
                                                   'brandId',
                                                   'initHandlingFee',
                                                   'initQualityInspectionFee',
                                                   'initSubtotal',
                                                   'initTax',
                                                   'initTotalKRW']]
        order_prod_fee_bulk['initTotalKRW'] = order_prod_fee_bulk['quantity'] * (
            order_prod_fee_bulk['initKRW'].astype('float'))
        order_prod_fee_init = pd.concat([order_prod_fee_init,
                                         order_prod_fee_bulk[['orderProductId', 'orderId',
                                                              'buyerId', 'initTotalKRW']]]).reset_index(drop=True)
        self.dm_orderseries = pd.merge(self.dm_orderseries,
                                       order_prod_fee_init.drop(['productId', 'buyerId', 'brandId'], axis=1),
                                       on=['orderProductId', 'orderId'])
        print(f'init : {time.time() - start_time}')

        start_time = time.time()
        order_prod_fee_dc = order_prod_fee.copy()
        order_prod_fee_dc['product'] = order_prod_fee_dc['product'].apply(lambda x: type_extractor([x], 'id'))
        order_prod_fee_dc['brand'] = order_prod_fee_dc['brand'].apply(lambda x: type_extractor([x], 'id'))
        order_prod_fee_dc = order_prod_fee_dc.rename({'product': 'productId',
                                                      'brand': 'brandId'}, axis=1)
        order_prod_fee_dc['dcHandlingFee'] = order_prod_fee_dc['dc_unit_handling_fee_amount'] * (
            order_prod_fee_dc['quantity'])
        order_prod_fee_dc['dcQualityInspectionFee'] = order_prod_fee_dc['dc_unit_quality_inspection_fee_amount'] * (
            order_prod_fee_dc['quantity'])
        order_prod_fee_dc['dcSubtotal'] = order_prod_fee_dc['dc_unit_product_supply'] * (
            order_prod_fee_dc['quantity'])
        order_prod_fee_dc = order_prod_fee_dc[['orderProductId',
                                               'orderId',
                                               'productId',
                                               'buyerId',
                                               'brandId',
                                               'dcHandlingFee',
                                               'dcQualityInspectionFee',
                                               'dcSubtotal']]
        self.dm_orderseries = pd.merge(self.dm_orderseries,
                                       order_prod_fee_dc.drop(['productId', 'buyerId', 'brandId'], axis=1),
                                       on=['orderProductId',
                                           'orderId'],
                                       how='left')
        print(f'dc : {time.time() - start_time}')

        start_time = time.time()

        dataframe_tbl_shipment = pd.concat(
            [self.dataframe_tbl_shipment.groupby('orderId')['finalShippingCost'].sum(),
             self.dataframe_tbl_shipment.groupby('orderId')['tracking_number'].apply(
                 lambda x: list(x))],
            axis=1).reset_index()

        dataframe_fee = self.dataframe_fee.copy()
        shipping_cost = dataframe_fee['orderShipping'] + dataframe_fee['waitShipping']
        shipping_cost = pd.concat([dataframe_fee['orderId'],
                                   Series(shipping_cost, name='shippingCost')],
                                  axis=1)
        dcshipping_cost = dataframe_fee['dcOrderShipping'] + dataframe_fee['dcWaitShipping']
        dcshipping_cost = pd.concat([dataframe_fee['orderId'],
                                     Series(dcshipping_cost, name='dcshippingCost')],
                                    axis=1)
        self.dm_orderseries = pd.merge(self.dm_orderseries,
                                       pd.merge(shipping_cost, dcshipping_cost, on='orderId'),
                                       how='left',
                                       on='orderId')
        self.dm_orderseries[['initTotalKRW', 'finalTotalKRW', 'initSubtotal', 'finalSubtotal']] = self.dm_orderseries[
            ['initTotalKRW', 'finalTotalKRW', 'initSubtotal', 'finalSubtotal']].astype('float')
        self.dm_orderseries.loc[self.dm_orderseries['countryCode'] != 'KR', 'initTotalKRW'] += (
                self.dm_orderseries.loc[self.dm_orderseries['countryCode'] != 'KR', 'initSubtotal'] * 0.1)
        self.dm_orderseries = pd.merge(self.dm_orderseries,
                                       dataframe_tbl_shipment,
                                       on='orderId',
                                       how='left')
        print(f'shipping cost: {time.time() - start_time}')

        start_time = time.time()

        dm_orderseries = self.dm_orderseries.copy()
        dm_orderseries_bulk = dm_orderseries.loc[dm_orderseries['initSubtotal'].isna(),
                                                 'orderId'].drop_duplicates()
        first_ind = dm_orderseries.groupby(['orderId']).apply(lambda x: x.iloc[0].name)
        tax_handlingfee_value = pd.merge(dm_orderseries_bulk,
                                         dataframe_order[['orderId', 'taxKRW', 'handlingFeeKRW']])
        col_ind = [int(np.where(dm_orderseries.columns == i)[0]) for i in ['initTax', 'initHandlingFee']]
        for _, thv_row in tax_handlingfee_value.iterrows():
            ind = first_ind[thv_row['orderId']]
            dm_orderseries.iloc[ind, col_ind] = thv_row[['taxKRW', 'handlingFeeKRW']]

        self.dm_orderseries = dm_orderseries

        print(f'bulk order processing : {time.time() - start_time}')

        self.dm_orderseries = self.dm_orderseries.rename({'quantity': 'initQuantity',
                                                          'finalQuantity': 'finalQuantity'},
                                                         axis=1)
        self.dm_orderseries = self.dm_orderseries.drop(['unclepickup',
                                                        'inspection_quantity'],
                                                       axis=1)
        self.dm_orderseries['processedDate'] = self.dm_orderseries['processedDate'].astype('datetime64')
        self.dm_orderseries['processedDate'] = self.dm_orderseries['processedDate'].astype(object).where(
                                                self.dm_orderseries['processedDate'].notnull(), None)
        self.dm_orderseries[['initQuantity',
                             'finalQuantity',
                             'finalQualityInspectionFee',
                             'finalHandlingFee',
                             'finalSubtotal',
                             'finalTax',
                             'finalTotalKRW',
                             'initHandlingFee',
                             'initQualityInspectionFee',
                             'initSubtotal',
                             'initTax',
                             'initTotalKRW',
                             'dcHandlingFee',
                             'dcQualityInspectionFee',
                             'dcSubtotal',
                             'shippingCost',
                             'dcshippingCost',
                             'finalShippingCost',
                             'finalKRW',
                             'waitShipmentType',
                             'waitShipmentStatus',
                             'settledPrice',
                             'settledQuantity',
                             'initKRW']] = self.dm_orderseries[['initQuantity',
                                                                'finalQuantity',
                                                                'finalQualityInspectionFee',
                                                                'finalHandlingFee',
                                                                'finalSubtotal',
                                                                'finalTax',
                                                                'finalTotalKRW',
                                                                'initHandlingFee',
                                                                'initQualityInspectionFee',
                                                                'initSubtotal',
                                                                'initTax',
                                                                'initTotalKRW',
                                                                'dcHandlingFee',
                                                                'dcQualityInspectionFee',
                                                                'dcSubtotal',
                                                                'shippingCost',
                                                                'dcshippingCost',
                                                                'finalShippingCost',
                                                                'finalKRW',
                                                                'waitShipmentType',
                                                                'waitShipmentStatus',
                                                                'settledPrice',
                                                                'settledQuantity',
                                                                'initKRW']].astype('float')