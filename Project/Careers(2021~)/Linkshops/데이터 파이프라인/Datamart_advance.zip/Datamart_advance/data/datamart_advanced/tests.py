import os

current_dir = os.path.dirname(os.path.abspath(__file__))

print(current_dir)

print(current_dir + '/datamart_result.txt')

with open(current_dir + '\datamart_result.txt', mode='w') as f:
    f.write('True')