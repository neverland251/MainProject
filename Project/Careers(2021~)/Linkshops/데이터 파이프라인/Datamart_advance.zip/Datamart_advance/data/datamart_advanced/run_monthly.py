import dm_series
from pymongo import MongoClient
import time
import pandas as pd
import datetime
from dateutil.relativedelta import relativedelta

password = '$dpdlvmflf4'
id_mongo = 'vida'
password_mongo = 'qwer123$'
email_id = 'ji.kwon@linkshops.com'
email_pw = 'cjswp25*'

client = MongoClient(host='10.10.224.28',
                     port=27017,
                     username = id_mongo,
                     password = password_mongo)

db_datamart = client['datamart']

# ----- running start ------ #
if __name__ == '__main__':
    try:
        time_now = pd.Timestamp(datetime.datetime.now(), tz='UTC')
        time_from = str(datetime.datetime.strptime(str(time_now.date()), '%Y-%m-%d') - relativedelta(months=1)).split('-')
        time_from = time_from[0] + '-' + time_from[1] + '-' + '01 00:00:00.000000 +0900'
        time_from_to = str(time_now.date()).split('-')
        time_from_to = time_from_to[0] + '-' + time_from_to[1] + '-' + '01 00:00:00.000000 +0900'

        # ---- dm_series ---- #

        start_time = time.time()
        dm_maker = dm_series.DM_SeriesMaker('restore.cy1gcw3mvrbf.ap-northeast-2.rds.amazonaws.com',
                                          'linkshops',
                                          '5432',
                                          'linkshops',
                                          password,
                                          email_id, email_pw,
                                          time_from, time_from_to,
                                          client)

        dm_maker.load_table()
        dm_maker.run()
        col_dm = db_datamart['dm_series']
        db_datamart.drop_collection('dm_series')
        for num, i in enumerate(dm_maker.dm_series.T.to_dict().values()):
            col_dm.insert_one(i)
            if num % 1000 == 0:
                print(f'{round(num / dm_maker.dm_series.shape[0], 2) * 100} % complete')
        with open("datamart_result.txt", mode='w') as f:
            f.write('True')
        print(f'dm_series END : {time.time() - start_time}')
    except Exception as e:
        with open("datamart_result.txt", mode='w') as f:
            f.write('False')
        print(e)
