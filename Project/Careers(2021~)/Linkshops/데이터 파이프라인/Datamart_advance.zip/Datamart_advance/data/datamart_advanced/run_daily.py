import dm_seller,dm_buyer,dm_merchandise,dm_orderseries
from pymongo import MongoClient
import time
import pandas as pd
import datetime
from dateutil.relativedelta import relativedelta
import gc
import os

password = '$dpdlvmflf4'
id_mongo = 'vida'
password_mongo = 'qwer123$'
email_id = 'ji.kwon@linkshops.com'
email_pw = 'cjswp25*'

client = MongoClient(host='10.10.224.28',
                     port=27017,
                     username = id_mongo,
                     password = password_mongo)

db_datamart = client['datamart']

# ----- running start ------ #
if __name__ == '__main__':
    try:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        # UTC기준인 서버 시간을 Asia/Seoul로 변경한다.
        time_now = pd.Timestamp(datetime.datetime.now(), tz='UTC').tz_convert('Asia/Seoul')

        time_from = str(datetime.datetime.strptime(str(time_now.date()), '%Y-%m-%d') - relativedelta(months=5)).split('-')
        # 해당 시간이 Asia/Seoul임을 명시한다.
        time_from = time_from[0] + '-' + time_from[1] + '-' + time_from[2] + '.000000 +0900'
        time_from_to = str(time_now.date())


        # ---- dm_orderseries_recommend ---- #

        start_time = time.time()
        dm_maker = dm_orderseries.DmOrderSeries('restore.cy1gcw3mvrbf.ap-northeast-2.rds.amazonaws.com',
                                          'linkshops',
                                          '5432',
                                          'linkshops',
                                          password,
                                          email_id,email_pw,
                                          time_from, time_from_to,
                                          client)
        dm_maker.load_table()
        dm_maker.run()
        col_dm = db_datamart['dm_orderseries_recommend']
        db_datamart.drop_collection('dm_orderseries_recommend')
        col_dm.insert_many(dm_maker.dm_orderseries.T.to_dict().values())
        print(f'dm_orderseries_recommend END : {time.time() - start_time}')

        time_from = str(datetime.datetime.strptime(str(time_now.date()), '%Y-%m-%d') - relativedelta(months=2)).split('-')
        # 해당 시간이 Asia/Seoul임을 명시한다.
        time_from = time_from[0] + '-' + time_from[1] + '-' + '01 00:00:00.000000 +0900'
        time_from_to = str(time_now.date())

        # ---- dm_seller ----#
        start_time = time.time()
        dm_maker = dm_seller.DM_SELLERMaker('restore.cy1gcw3mvrbf.ap-northeast-2.rds.amazonaws.com',
                                              'linkshops',
                                              '5432',
                                              'linkshops',
                                              password,
                                              email_id, email_pw,
                                              time_from, time_from_to,
                                              client)
        dm_maker.load_table()
        dm_maker.run()
        col_dm = db_datamart['dm_seller']
        print(f'dm_seller END : {time.time() - start_time}')
        db_datamart.drop_collection('dm_seller')
        '''
        for num, i in enumerate(dm_maker.dm_seller.T.to_dict().values()):
            col_dm.insert_one(i)
            if num % 1000 == 0:
                print(f'{round(num / dm_maker.dm_seller.shape[0], 2) * 100} % complete')
        '''
        col_dm.insert_many(dm_maker.dm_seller.T.to_dict().values())
        # ---- dm_buyer ---- #

        start_time = time.time()
        dm_maker = dm_buyer.DM_BUYERMaker('restore.cy1gcw3mvrbf.ap-northeast-2.rds.amazonaws.com',
                                              'linkshops',
                                              '5432',
                                              'linkshops',
                                              password,
                                              email_id, email_pw,
                                              time_from, time_from_to,
                                              client)

        gc.collect()

        dm_maker.run()
        col_dm = db_datamart['dm_buyer']
        db_datamart.drop_collection('dm_buyer')
        '''
        for num, i in enumerate(dm_maker.dm_buyer.T.to_dict().values()):
            col_dm.insert_one(i)
            if num % 1000 == 0:
                print(f'{round(num / dm_maker.dm_buyer.shape[0], 2) * 100} % complete')
        '''
        col_dm.insert_many(dm_maker.dm_buyer.T.to_dict().values())
        print(f'dm_buyer END : {time.time() - start_time}')

        # ---- dm_merchandise ---- #
        start_time = time.time()
        dm_maker = dm_merchandise.DM_MerchandiseMaker('restore.cy1gcw3mvrbf.ap-northeast-2.rds.amazonaws.com',
                                                      'linkshops',
                                                      '5432',
                                                      'linkshops',
                                                      password,
                                                      email_id, email_pw,
                                                      time_from, time_from_to,
                                                      time_from, time_from_to,
                                                      client)
        gc.collect()

        dm_maker.run()
        col_dm = db_datamart['dm_merchandise']
        db_datamart.drop_collection('dm_merchandise')
        '''
        for num, i in enumerate(dm_maker.dm_merchandise.T.to_dict().values()):
            col_dm.insert_one(i)
            if num % 1000 == 0:
                print(f'{round(num / dm_maker.dm_merchandise.shape[0], 2) * 100} % complete')
        '''
        col_dm.insert_many(dm_maker.dm_merchandise.T.to_dict().values())
        print(f'dm_merchandise END : {time.time() - start_time}')

        # ---- dm_orderseries ---- #

        start_time = time.time()
        dm_maker = dm_orderseries.DmOrderSeries('restore.cy1gcw3mvrbf.ap-northeast-2.rds.amazonaws.com',
                                          'linkshops',
                                          '5432',
                                          'linkshops',
                                          password,
                                          email_id,email_pw,
                                          time_from, time_from_to,
                                          client)

        gc.collect()
        dm_maker.load_table()
        dm_maker.run()
        col_dm = db_datamart['dm_orderseries']
        db_datamart.drop_collection('dm_orderseries')
        '''
        for num, i in enumerate(dm_maker.dm_orderseries.T.to_dict().values()):
            col_dm.insert_one(i)
            if num % 1000 == 0:
                print(f'{round(num / dm_maker.dm_orderseries.shape[0], 2) * 100} % complete')
        '''
        col_dm.insert_many(dm_maker.dm_orderseries.T.to_dict().values())
        print(f'dm_orderseries END : {time.time() - start_time}')

        with open(current_dir + '/datamart_result.txt', mode='w') as f:
            f.write('True')
    except Exception as e:
        print(e)
        with open(current_dir + '/datamart_result.txt', mode='w') as f:
            f.write('False')
