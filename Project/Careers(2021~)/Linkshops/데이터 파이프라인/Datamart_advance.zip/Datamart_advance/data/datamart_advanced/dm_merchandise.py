from engine import DatamartMaker
import pandas as pd
import numpy as np
from pandas import Series
import time


class DM_MerchandiseMaker(DatamartMaker):

    def __init__(self,
                 host_ip,
                 DBname,
                 port,
                 username,
                 password,
                 email_id,
                 email_pw,
                 from_date,
                 to_date,
                 prod_from_date,
                 prod_to_date,
                 client):
        super().__init__(host_ip, DBname, port, username, password, email_id, email_pw, client)
        self.from_date = from_date
        self.to_date_seoul = pd.Timestamp(to_date, tz='UTC').tz_convert('Asia/Seoul')
        self.to_date = to_date
        self.prod_from_date = prod_from_date
        self.prod_to_date = prod_to_date
        self.prod_to_date_seoul = pd.Timestamp(to_date, tz='UTC').tz_convert('Asia/Seoul')

    def load_table(self, demo_test=False):

        self.order_prod = {'SQL': "select \"buyerId\"," + (
            "\"brand\", ") + (
                                      "\"totalKRW\",") + (
                                      "\"finalTotalKRW\",") + (
                                      "\"finalQuantity\",") + (
                                      "\"quantity\",") + (
                                      "\"product\",") + (
                                      "\"productVariant\",") + (
                                      "\"orderId\",") + (
                                      "\"createdAt\",") + (
                                      "\"updatedAt\"") + (
                                      " from order_products WHERE ") + (
                                      f"\"createdAt\" >= '{self.from_date}' AND ") + (
                                      f"\"createdAt\" < '{self.to_date_seoul}'"),
                           'columns': ['buyerId',
                                       'brand',
                                       'totalKRW',
                                       'finalTotalKRW',
                                       'finalQuantity',
                                       'quantity',
                                       'product',
                                       'productVariant',
                                       'orderId',
                                       'createdAt',
                                       'updatedAt']}

        self.prod = {'SQL': "select \"id\"," + (
            "\"CNY\",") + (
                                "\"KRW\",") + (
                                "\"TWD\",") + (
                                "\"USD\",") + (
                                "\"brand\", ") + (
                                "\"categories\",") + (
                                "\"appImages\",") + (
                                "\"name\",") + (
                                "\"data\",") + (
                                "\"createdAt\",") + (
                                "\"updatedAt\",") + (
                                "\"status\"") + (
                                " from products WHERE ") + (
                                f"(\"createdAt\" >= '{self.prod_from_date}' AND ") + (
                                f"\"createdAt\" < '{self.prod_to_date_seoul}') OR ") + (
                                f"(\"updatedAt\" >= '{self.prod_from_date}' AND ") + (
                                f"\"updatedAt\" < '{self.prod_to_date_seoul}')"),
                     'columns': ['productId',
                                 'CNY',
                                 'KRW',
                                 'TWD',
                                 'USD',
                                 'brand',
                                 'categories',
                                 'appImages',
                                 'name',
                                 'data',
                                 'createdAt',
                                 'updatedAt',
                                 'status']}

        self.variant = {'SQL': "select  " + (
            "\"id\",") + (
                                   "\"CNY\",") + (
                                   "\"KRW\",") + (
                                   "\"TWD\",") + (
                                   "\"USD\",") + (
                                   "\"sku\",") + (
                                   "\"data\",") + (
                                   "\"version\",") + (
                                   "\"productId\",") + (
                                   "\"appImages\",") + (
                                   "\"createdAt\",") + (
                                   "\"updatedAt\",") + (
                                   "\"status\"") + (
                                   " from product_variants WHERE ") + (
                                   f"(\"createdAt\" >= '{self.prod_from_date}' AND ") + (
                                   f"\"createdAt\" < '{self.prod_to_date_seoul}' AND ") + (
                                   "\"status\" = 100) OR ") + (
                                   f"(\"updatedAt\" >= '{self.prod_from_date}' AND ") + (
                                   f"\"updatedAt\" < '{self.prod_to_date_seoul}' AND ") + (
                                   "\"status\" = 100)"),
                        'columns': ['variantId',
                                    'CNY',
                                    'KRW',
                                    'TWD',
                                    'USD',
                                    'sku',
                                    'data',
                                    'version',
                                    'productId',
                                    'image_variant',
                                    'createdAt',
                                    'updatedAt',
                                    'status']}

        super().load_table()

    def run(self, threshold_active=365, start_point=400, end_point=1, offset=20):

        def type_extractor(x, types, recursive=None):
            try:
                if recursive is None:
                    return x[0][types]
                else:
                    return type_extractor([x[0][types]],
                                          types=recursive)
            except:
                return 'NaN'

        if not hasattr(self, 'dataframe_variant'):
            self.load_table()

        # -------DM_Merchandise START---------- #

        prod_variant = pd.merge(self.dataframe_prod,
                                self.dataframe_variant,
                                on='productId',
                                how='left',
                                suffixes=['_prod', '_variant'])

        start_time = time.time()
        dataframe_order_prod = self.dataframe_order_prod.copy()
        dataframe_order_prod['productId'] = dataframe_order_prod['product'].apply(
            lambda x: type_extractor([x], 'id'))
        dataframe_order_prod['variantId'] = dataframe_order_prod['productVariant'].apply(
            lambda x: type_extractor([x], 'id'))
        dataframe_order_prod['date'] = dataframe_order_prod['createdAt'].dt.date.apply(lambda x: str(x))
        dataframe_order_prod[['totalKRW', 'finalTotalKRW', 'finalQuantity', 'quantity']] = (
            dataframe_order_prod[['totalKRW', 'finalTotalKRW', 'finalQuantity', 'quantity']].astype('float'))
        self.dm_merchandise = dataframe_order_prod.groupby(
            ['productId', 'variantId', 'date'])[
            ['totalKRW', 'finalTotalKRW', 'finalQuantity', 'quantity']
        ].sum().reset_index()
        order_prod = dataframe_order_prod[['productId', 'variantId', 'product', 'productVariant', 'brand']].rename(
            {'product': 'SKUdata', 'productVariant': 'variantData'}, axis=1)
        order_prod = order_prod.drop_duplicates('variantId')
        self.dm_merchandise = pd.merge(self.dm_merchandise,
                                       order_prod,
                                       on=['productId', 'variantId'],
                                       how='left')
        # createdAt은 SKUdata에서 가져온 값을 그대로 사용한다.(불변이기 때문에)
        self.dm_merchandise['createdAt_prod'] = self.dm_merchandise['SKUdata'].apply(
            lambda x: x['createdAt'] if np.any(np.array(list(x.keys())) == 'createdAt') else np.nan)
        # updatedAt은 SKUdata에서 가져온 값을 베이스로, 만약 prod_variant에 해당 값이 있는경우 최신값이 해당 값으로 대체한다.
        self.dm_merchandise['updatedAt_SKU'] = self.dm_merchandise['SKUdata'].apply(
            lambda x: x['updatedAt'] if np.any(np.array(list(x.keys())) == 'updatedAt') else np.nan)
        # Variant의 createdAt은 varData에서 가져온 값을 그대로 사용한다.
        self.dm_merchandise['createdAt_variant'] = self.dm_merchandise['variantData'].apply(
            lambda x: x['createdAt'] if np.any(np.array(list(x.keys())) == 'createdAt') else np.nan)
        # updatedAt은 varData에서 가져온 값을 베이스로, 만약 prod_variant에 해당 값이 있는경우 최신값이 해당 값으로 대체한다.
        self.dm_merchandise['updatedAt_varData'] = self.dm_merchandise['variantData'].apply(
            lambda x: x['updatedAt'] if np.any(np.array(list(x.keys())) == 'updatedAt') else np.nan)
        self.dm_merchandise = pd.concat([self.dm_merchandise,
                                         Series(self.dm_merchandise.apply(
                                             lambda x: np.any(np.array(list(x['SKUdata'].keys())) == 'bulkProductId'),
                                             axis=1),
                                             name='isBulkOrder')],
                                        axis=1)
        self.dm_merchandise = pd.merge(self.dm_merchandise,
                                       prod_variant[['productId',
                                                     'updatedAt_prod']],
                                       on=['productId'],
                                       how='left')
        self.dm_merchandise = pd.merge(self.dm_merchandise,
                                       prod_variant[['variantId',
                                                     'updatedAt_variant']],
                                       on=['variantId'],
                                       how='left')
        self.dm_merchandise.loc[~self.dm_merchandise['updatedAt_prod'].isna(), 'updatedAt_SKU'] = (
            self.dm_merchandise.loc[~self.dm_merchandise['updatedAt_prod'].isna(), 'updatedAt_prod'])
        self.dm_merchandise.loc[~self.dm_merchandise['updatedAt_variant'].isna(), 'updatedAt_varData'] = (
            self.dm_merchandise.loc[~self.dm_merchandise['updatedAt_variant'].isna(), 'updatedAt_variant'])
        self.dm_merchandise = self.dm_merchandise.drop(['updatedAt_prod', 'updatedAt_variant'], axis=1).rename(
            {'updatedAt_SKU': 'updatedAt_prod',
             'updatedAt_varData': 'updatedAt_variant'},
            axis=1)

        prod_variant[['CNY_prod',
                      'KRW_prod',
                      'TWD_prod',
                      'USD_prod',
                      'CNY_variant',
                      'KRW_variant',
                      'TWD_variant',
                      'USD_variant']] = prod_variant[['CNY_prod',
                                                      'KRW_prod',
                                                      'TWD_prod',
                                                      'USD_prod',
                                                      'CNY_variant',
                                                      'KRW_variant',
                                                      'TWD_variant',
                                                      'USD_variant']].astype('float')

        prod_variant[['createdAt_prod',
                      'createdAt_variant',
                      'updatedAt_prod',
                      'updatedAt_variant']] = prod_variant[['createdAt_prod',
                                                            'createdAt_variant',
                                                            'updatedAt_prod',
                                                            'updatedAt_variant']].astype('str')
        prod_variant['data_prod'] = prod_variant.rename(
            {'productId': 'id',
             'data_prod': 'data',
             'CNY_prod': 'CNY',
             'KRW_prod': 'KRW',
             'TWD_prod': 'TWD',
             'USD_prod': 'USD',
             'status_prod': 'status',
             'createdAt_prod': 'createdAt',
             'updatedAt_prod': 'updatedAt'}, axis=1)[['id',
                                                      'CNY',
                                                      'KRW',
                                                      'TWD',
                                                      'USD',
                                                      'data',
                                                      'appImages',
                                                      'name',
                                                      'createdAt',
                                                      'updatedAt',
                                                      'status']].to_dict(orient='records')

        prod_variant['data_variant'] = prod_variant.rename(
            {'variantId': 'id',
             'data_variant': 'data',
             'CNY_variant': 'CNY',
             'KRW_variant': 'KRW',
             'TWD_variant': 'TWD',
             'USD_variant': 'USD',
             'imageVariant': 'appImages',
             'status_variant': 'status',
             'createdAt_variant': 'createdAt',
             'updatedAt_variant': 'updatedAt'}, axis=1)[['id',
                                                         'CNY',
                                                         'KRW',
                                                         'TWD',
                                                         'USD',
                                                         'sku',
                                                         'data',
                                                         'appImages',
                                                         'createdAt',
                                                         'updatedAt',
                                                         'status']].to_dict(orient='records')
        prod_variant = prod_variant[[
            'productId',
            'variantId',
            'data_prod',
            'data_variant',
            'brand',
            'createdAt_prod',
            'createdAt_variant',
            'updatedAt_prod',
            'updatedAt_variant']]

        prod_variant.columns = ['productId',
                                'variantId',
                                'SKUdata',
                                'variantData',
                                'brand',
                                'createdAt_prod',
                                'createdAt_variant',
                                'updatedAt_prod',
                                'updatedAt_variant']

        diff_col = list(set(self.dm_merchandise.columns).difference(set(prod_variant.columns)))
        prod_variant = prod_variant[~prod_variant['createdAt_prod'].isna()]
        self.dm_merchandise = pd.merge(
            self.dm_merchandise,
            prod_variant[['productId', 'SKUdata']].drop_duplicates(['productId']).reset_index(drop=True),
            on='productId',
            how='left',
            suffixes=['_order', '_prod']
        )
        self.dm_merchandise = pd.merge(
            self.dm_merchandise,
            prod_variant[['variantId', 'variantData']].drop_duplicates(['variantId']).reset_index(drop=True),
            on='variantId',
            how='left',
            suffixes=['_order', '_prod']
        )
        self.dm_merchandise.loc[~self.dm_merchandise['SKUdata_prod'].isna(), 'SKUdata_order'] = (
            self.dm_merchandise.loc[~self.dm_merchandise['SKUdata_prod'].isna(), 'SKUdata_prod'])
        self.dm_merchandise.loc[~self.dm_merchandise['variantData_prod'].isna(), 'variantData_order'] = (
            self.dm_merchandise.loc[~self.dm_merchandise['variantData_prod'].isna(), 'variantData_prod'])
        self.dm_merchandise = pd.concat([self.dm_merchandise.drop(['SKUdata_prod',
                                                                   'variantData_prod'], axis=1).rename(
                                                                    {'SKUdata_order': 'SKUdata',
                                                                     'variantData_order': 'variantData'},
                                                                    axis=1),
                                         prod_variant]).drop_duplicates(subset=['productId', 'variantId'],
                                                                        keep='first').reset_index(drop=True)
        print(f'dm_merchandise : {time.time() - start_time}')

        # ===== preprocessing Start ========#
        #self.dm_merchandise = self.dm_merchandise[self.dm_merchandise['isBulkOrder'] != 1].reset_index(drop=True)
        self.dm_merchandise[['totalKRW',
                             'finalTotalKRW',
                             'finalQuantity',
                             'quantity',
                             'isBulkOrder']] = self.dm_merchandise[['totalKRW',
                                                                    'finalTotalKRW',
                                                                    'finalQuantity',
                                                                    'quantity',
                                                                    'isBulkOrder']].astype('float')

        self.dm_merchandise['createdAt_prod'] = self.dm_merchandise['createdAt_prod'].apply(lambda x: pd.Timestamp(x))
        self.dm_merchandise['createdAt_variant'] = self.dm_merchandise['createdAt_variant'].apply(
            lambda x: pd.Timestamp(x))
        self.dm_merchandise['updatedAt_prod'] = self.dm_merchandise['updatedAt_prod'].apply(lambda x: pd.Timestamp(x))
        self.dm_merchandise['updatedAt_variant'] = self.dm_merchandise['updatedAt_variant'].apply(
            lambda x: pd.Timestamp(x))

        self.dm_merchandise[['createdAt_variant',
                             'updatedAt_variant']] = self.dm_merchandise[['createdAt_variant',
                                                                          'updatedAt_variant']].astype(object).where(
            self.dm_merchandise[['createdAt_variant',
                                 'updatedAt_variant']].notnull(), None)
        self.dm_merchandise[['createdAt_prod',
                             'updatedAt_prod']] = self.dm_merchandise[['createdAt_prod',
                                                                          'updatedAt_prod']].astype(object).where(
        self.dm_merchandise[['createdAt_prod',
                                 'updatedAt_prod']].notnull(), None)
