from pandas import DataFrame, Series
import pandas as pd
import psycopg2

from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.text import MIMEText
from smtplib import SMTP_SSL
from pathlib import Path

from dateutil.relativedelta import relativedelta

from io import BytesIO

class DataExtractor():

    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, client):
        self._phase = set()
        self._has_nosql = False
        self.client = client
        self.connect(host_ip, DBname, port, username, password)
        self.connect_email(email_id, email_pw)
        self.email_id = email_id

    def connect_email(self, email_id, email_pw):
        self.smtp = SMTP_SSL('smtp.gmail.com', 465)
        self.smtp.login(email_id, email_pw)

    def connect(self, host_ip, DBname, port, username, password):

        conn = psycopg2.connect(f"host={host_ip} " + (
                                f"port={port} ") + (
                                f"user={username} ") + (
                                f"password={password} ") + (
                                f"dbname={DBname}"))
        self.curs = conn.cursor()

        self.db_datamart = self.client['datamart']

    def __setattr__(self, name, value):
        if name == "NOSQL":
            self._has_nosql = True
        elif isinstance(value, dict):
            self._phase.add(name)
        super().__setattr__(name, value)

    def load_table(self):
        for name in self._phase:
            SQL = self.__dict__[name]['SQL']
            columns = self.__dict__[name]['columns']
            try:
                self.curs.execute(SQL)
            except Exception as e:
                print(e)
                print('connection retry...')
                self.connect(self.host_ip,
                             self.DBname,
                             self.port,
                             self.username,
                             self.password)
                self.curs.execute(SQL)
            temp = DataFrame(self.curs)
            if temp.shape[0] >= 1:
                temp.columns = columns
            else:
                temp = DataFrame(columns=columns)
            self.__dict__[f'dataframe_{name}'] = temp
            print(f'Table : {name} Load Complete')

        if self._has_nosql:
            for name, value in self.__dict__['NOSQL'].items():
                collection = self.db_datamart[name]
                if isinstance(value['SQL'], list):
                    temp = DataFrame(collection.find(*value['SQL']))
                if isinstance(value['SQL'], dict):
                    temp = DataFrame(collection.find(value['SQL']))
                if any([True if i == 'columns' else False for i in value]):
                    if temp.shape[0] >= 1:
                        temp.columns = columns
                    else:
                        temp = DataFrame(columns=columns)
                self.__dict__[f'dataframe_{name}'] = temp
                print(f'NoSQLTable : {name} Load Complete')
        self.curs.close()
    def run(self):
        raise NotImplementedError()

    def send_email(self, FROM, contents_file, patch=None, filename = None):
        subject = pd.read_csv(contents_file)
        for _, i in subject.iterrows():
            msg = MIMEMultipart()
            msg["FROM"] = FROM
            msg["to"] = i['address']
            msg['subject'] = i['subject']
            message = i['contents']
            self.msg = msg
            if patch is not None:
                if isinstance(patch, str):
                    with open(patch, 'rb') as f:
                        filename = patch
                        attachment = MIMEApplication(f.read())
                        attachment["Content-Disposition"] = 'attachment; filename=" {}"'.format(
                            f"{Path(filename).name}")
                if isinstance(patch, (DataFrame, Series)):
                    output = BytesIO()
                    writer = pd.ExcelWriter(output, engine='xlsxwriter')
                    patch.to_excel(writer, sheet_name='Sheet1', index = False)
                    writer.save()
                    output.seek(0)
                    attachment = MIMEApplication(output.read(), name = f'{filename}.xlsx', _subtype = 'xlsx')
                    attachment["Content-Disposition"] = 'attachment; filename=" {}"'.format(f"{filename}.xlsx")
                msg.attach(attachment)
                msg.attach(MIMEText(message))
                self.smtp.sendmail(msg["FROM"], msg["to"], msg.as_string())

        if patch is None:
            raise Exception('Please attach file on e-mail')

    def reset_smtp(self, email_id, email_pw):
        self.smtp.close()
        self.connect_email(email_id, email_pw)

    def businessday_counter(time_now, day_num, holidays):
        next_month = time_now + relativedelta(months=1)
        time_from = str(time_now.year) + '-' + str(time_now.month) + '-01'
        time_from_to = str((pd.Timestamp(str(next_month.year) + '-' + str(next_month.month) + '-01') - \
                            relativedelta(days=1)).date())
        holidays.columns = ['date', 'dotw', 'holiday']
        holidays['date'] = holidays['date'].astype('datetime64')
        date_range = pd.date_range(time_from,
                                   time_from_to,
                                   freq='D')
        date_table = DataFrame({'date': date_range,
                                'weekday': [i.weekday() for i in date_range]})
        date_table = pd.merge(date_table,
                              holidays[['date', 'holiday']],
                              on='date',
                              how='left')
        date_table.loc[date_table['weekday'] == 5, 'holiday'] = '토요일'
        date_table.loc[date_table['weekday'] == 6, 'holiday'] = '일요일'
        date_table.loc[date_table['holiday'].isna(), 'countable'] = True
        date_table.loc[~date_table['holiday'].isna(), 'countable'] = False
        date_table_workday = date_table[date_table['date'] >= time_from].reset_index(drop=True)
        date_table_workday['cumsum'] = date_table_workday['countable'].astype('int').cumsum()
        business_day = date_table_workday[date_table_workday['cumsum'] == day_num]['date'].iloc[0]
        TF = (business_day == pd.Timestamp(time_now))

        return TF, str(business_day.date())