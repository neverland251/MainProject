import Buyer, Seller
from pymongo import MongoClient
import time
import pandas as pd
import numpy as np
import datetime
from dateutil.relativedelta import relativedelta
import gc
import os

# type4 : 매주 금 실행

password = '$dpdlvmflf4'
id_mongo = 'vida'
password_mongo = 'qwer123$'
email_id = 'ji.kwon@linkshops.com'
email_pw = 'cjswp25*'

client = MongoClient(host='10.10.224.28',
                     port=27017,
                     username = id_mongo,
                     password = password_mongo)

db_datamart = client['datamart']

# ----- running start ------ #
if __name__ == '__main__':
    current_dir = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.dirname(current_dir) + '/datamart_advanced/datamart_result.txt', mode='r') as f:
        result = f.read()
    if result == 'True':
        time_now = pd.Timestamp(datetime.datetime.now(), tz='UTC')

        # ---- 신상 / 낱장 기획전 ----#
        start_time = time.time()
        dm_extractor = Seller.ETLMinimumAndNewer('restore.cy1gcw3mvrbf.ap-northeast-2.rds.amazonaws.com',
                                                    'linkshops',
                                                    '5432',
                                                    'linkshops',
                                                    password,
                                                    email_id, email_pw,
                                                    time_now, [14,7],
                                                    client)
        dm_extractor.load_table()
        dm_extractor.run()
        dm_extractor.send_email('linkshops_bigdata',
                                f'{current_dir}/email_address/email_MinimumAndNewer.csv',
                                dm_extractor.marketing_dm,
                                f'마케팅_신상낱장_{time_now.date()}')

        # ---- 주간상품등록수 ---- #
        dm_extractor = Seller.ETLWeeklyCreatedSKU('restore.cy1gcw3mvrbf.ap-northeast-2.rds.amazonaws.com',
                                                    'linkshops',
                                                    '5432',
                                                    'linkshops',
                                                    password,
                                                    email_id, email_pw,
                                                    4,
                                                    client)
        dm_extractor.load_table()
        dm_extractor.run()

        period_list = dm_extractor.marketing_dm['기간'].unique()
        period_list = period_list[np.argsort([pd.Timestamp(i.split('~')[0]) for i in period_list])]

        dm_extractor.send_email('linkshops_bigdata',
                                f'{current_dir}/email_address/email_WeeklyCreatedSKU.csv',
                                dm_extractor.marketing_dm[dm_extractor.marketing_dm['기간'] == period_list[-2]],
                                f'마케팅_주간상품등록수_{period_list[-2]}')

    else :
        print("Datamart batch code has occured Error before. Please check logs before run ETL codes.")