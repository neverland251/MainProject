import Buyer, Seller
from engine import DataExtractor
from pymongo import MongoClient
import time
import pandas as pd
import datetime
from dateutil.relativedelta import relativedelta
import gc
import os

# type 9 : 매 영업일 3일마다 실행

password = '$dpdlvmflf4'
id_mongo = 'vida'
password_mongo = 'qwer123$'
email_id = 'ji.kwon@linkshops.com'
email_pw = 'cjswp25*'

client = MongoClient(host='10.10.224.28',
                     port=27017,
                     username=id_mongo,
                     password=password_mongo)

db_datamart = client['datamart']

businessday_num = 3

# ----- running start ------ #
if __name__ == '__main__':
    current_dir = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.dirname(current_dir) + '/datamart_advanced/datamart_result.txt', mode='r') as f:
        result = f.read()
    if result == 'True':
        current_dir = os.path.dirname(os.path.abspath(__file__))
        holidays = pd.read_csv(f'{current_dir}./init_data/holiday.csv')
        time_now = pd.Timestamp(datetime.datetime.now(), tz='UTC')
        time_now_seoul = time_now.tz_convert('Asia/Seoul')
        if DataExtractor.businessday_counter(time_now_seoul.date(), businessday_num, holidays)[0]:
            time_from = str(datetime.datetime.strptime(
                            str(time_now.date()), '%Y-%m-%d') - relativedelta(months=1)).split('-')
            time_from = time_from[0] + '-' + time_from[1] + '-' + '01 00:00:00'
            time_from_to = str(time_now.date()).split('-')
            time_from_to = time_from_to[0] + '-' + time_from_to[1] + '-' + '01 00:00:00'

            prev_time_from = str(datetime.datetime.strptime(
                str(time_now.date()), '%Y-%m-%d') - relativedelta(months=2)).split('-')
            prev_time_from = prev_time_from[0] + '-' + prev_time_from[1] + '-' + '01 00:00:00'

            current_date = [time_from, time_from_to]
            prev_date = [prev_time_from, time_from]

            # ---- 사입수수료0%이벤트 ----#
            #start_time = time.time()
            dm_extractor = Buyer.ETLCZeroRatingEvent('restore.cy1gcw3mvrbf.ap-northeast-2.rds.amazonaws.com',
                                            'linkshops',
                                            '5432',
                                            'linkshops',
                                             password,
                                             email_id, email_pw,
                                             time_from, time_from_to,
                                             client)
            dm_extractor.load_table()
            dm_extractor.run()
            dm_extractor.send_email('linkshops_bigdata',
                                    f'{current_dir}/email_address/email_CZeroRatingEvent.csv',
                                    dm_extractor.dm_account,
                                    f'회계_사입수수료0%_{time_from}_{time_from_to}')

            gc.collect()

        else:
            print(f"Today is {time_now.date()}, {businessday_num}'th of the business day is")
            print(f"{DataExtractor.businessday_counter(time_now.date(), businessday_num, holidays)[1]}")

    else:
        print("Datamart batch code has occured Error before. Please check logs before run ETL codes.")