import Buyer, Seller
from pymongo import MongoClient
import time
import pandas as pd
import datetime
from dateutil.relativedelta import relativedelta
import gc
import os

# type6 : 월말 실행

password = '$dpdlvmflf4'
id_mongo = 'vida'
password_mongo = 'qwer123$'
email_id = 'ji.kwon@linkshops.com'
email_pw = 'cjswp25*'

client = MongoClient(host='10.10.224.28',
                     port=27017,
                     username = id_mongo,
                     password = password_mongo)

db_datamart = client['datamart']

# ----- running start ------ #
if __name__ == '__main__':
    date = pd.Timestamp(datetime.datetime.now())
    lastday_date = date + relativedelta(months = 1)
    lastday = (pd.Timestamp(str(lastday_date.year) + '-' + str(lastday_date.month) + '-01') -\
               pd.Timedelta(days = 1)).day
    if pd.Timestamp(datetime.datetime.now(), tz='UTC').tz_convert('Asia/Seoul').day in [lastday]:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        with open(os.path.dirname(current_dir) + '/datamart_advanced/datamart_result.txt', mode='r') as f:
            result = f.read()
        if result == 'True':
            time_now = pd.Timestamp(datetime.datetime.now(), tz='UTC').tz_convert('Asia/Seoul')
            '''
            # ---- 주글로벌매출 ----#
            start_time = time.time()
            dm_extractor = Seller.ETLGlobalMembership('restore.cy1gcw3mvrbf.ap-northeast-2.rds.amazonaws.com',
                                                        'linkshops',
                                                        '5432',
                                                        'linkshops',
                                                        password,
                                                        email_id, email_pw,
                                                        str(time_now.date()), '',
                                                        client)
            dm_extractor.load_table()
            dm_extractor.run()
            dm_extractor.send_email('linkshops_bigdata',
                                    f'{current_dir}/email_address/email_globalmembership.csv',
                                    dm_extractor.dm_account[dm_extractor.dm_account['날짜'] == str(time_now.date())],
                                    f'회계_월말글로벌멤버십현황_{str(time_now.date())}')
        else:
            print("Datamart batch code has occured Error before. Please check logs before run ETL codes.")
        '''
    else :
        print(f"Today is not day {lastday}.")