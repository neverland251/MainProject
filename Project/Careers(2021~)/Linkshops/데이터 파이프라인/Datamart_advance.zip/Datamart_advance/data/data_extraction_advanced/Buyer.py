from engine import DataExtractor
import pandas as pd
from pandas import DataFrame, Series
import time
import numpy as np

class ETLBuyerDC(DataExtractor):

    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, from_date, to_date, client):
        super().__init__(host_ip, DBname, port, username, password, email_id, email_pw, client)
        self.from_date = from_date
        self.to_date = to_date

    def load_table(self):
        self.NOSQL = {'dm_buyer' : {'SQL' : {}},
                      'dm_orderseries' : {'SQL' : {}}}

        super().load_table()

    def run(self):
        if not hasattr(self, 'dataframe_dm_orderseries'):
            self.load_table()

        marketing_dm = self.dataframe_dm_orderseries[['orderId',
                                                       'buyerId',
                                                       'createdAt',
                                                       'initTotalKRW',
                                                       'initHandlingFee',
                                                       'initQualityInspectionFee',
                                                       'initKRW',
                                                       'shippingCost',
                                                       'dcshippingCost',
                                                       'dcHandlingFee',
                                                       'dcQualityInspectionFee',
                                                       'productId',
                                                       'initSubtotal',
                                                       'initQuantity',
                                                       'brandId',
                                                       'building',
                                                      'countryCode',
                                                      'status_order']]

        buyers = self.dataframe_dm_buyer.copy()
        marketing_dm_kr = marketing_dm[(marketing_dm['countryCode'] == 'KR')]
        marketing_dm_kr = pd.merge(marketing_dm_kr,
                                   Series([100, 200, 201, 202, 300, 400], name='status_order'),
                                   on='status_order')
        marketing_dm_kr = marketing_dm_kr.drop(['status_order'], axis=1)
        marketing_dm_kr = marketing_dm_kr[marketing_dm_kr['productId'].apply(lambda x: len(str(x).split('_')) <= 1)]
        marketing_dm_kr.columns = ['orderId',
                                   '사업자ID',
                                   '구매날짜',
                                   '총 결제금액',
                                   '사입 수수료',
                                   '검수검품비',
                                   '상품 금액',
                                   '배송비',
                                   '배송비할인',
                                   '사입수수료할인',
                                   '검수검품비할인',
                                   '상품번호',
                                   '총금액',
                                   '수량',
                                   '브랜드ID',
                                   '상가',
                                   '국가코드']
        marketing_dm_kr['구매날짜'] = marketing_dm_kr['구매날짜'].dt.tz_localize('UTC').dt.tz_convert('Asia/Seoul')
        temp = marketing_dm_kr.groupby('orderId')[['총 결제금액', '총금액', '사입 수수료', '사입수수료할인']].sum()
        marketing_dm_buyer = pd.merge(marketing_dm_kr.drop(['총 결제금액', '사입 수수료', '사입수수료할인', '총금액'], axis=1),
                                      temp.reset_index(),
                                      on='orderId')
        marketing_dm_buyer['구매날짜'] = marketing_dm_buyer['구매날짜'].apply(lambda x: pd.to_datetime(x).date())
        marketing_dm_buyer = pd.merge(buyers[['buyerId', 'bizName']].rename({'buyerId': '사업자ID',
                                                                             'bizName': '사업자명'}, axis=1),
                                      marketing_dm_buyer,
                                      on='사업자ID',
                                      how='right')
        marketing_dm_buyer = marketing_dm_buyer[['orderId',
                                                 '사업자ID',
                                                 '사업자명',
                                                 '구매날짜',
                                                 '총 결제금액',
                                                 '총금액',
                                                 '사입 수수료',
                                                 '배송비',
                                                 '검수검품비',
                                                 '사입수수료할인',
                                                 '배송비할인',
                                                 '검수검품비할인',
                                                 '상품번호',
                                                 '상품 금액',
                                                 '수량',
                                                 '브랜드ID',
                                                 '상가']]
        marketing_dm_buyer['총 결제금액'] += marketing_dm_buyer['배송비']
        marketing_dm_buyer = marketing_dm_buyer[(marketing_dm_buyer['구매날짜'].astype('str') >= self.from_date) & (
                marketing_dm_buyer['구매날짜'].astype('str') < self.to_date)]
        marketing_dm_buyer = marketing_dm_buyer.reset_index(drop=True)
        self.marketing_dm = marketing_dm_buyer.copy()


class ETLBuyingReport(DataExtractor):

    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, from_date, to_date, client):
        super().__init__(host_ip, DBname, port, username, password, email_id, email_pw, client)
        self.from_date = from_date
        self.to_date = to_date

    def load_table(self):
        self.NOSQL = {'dm_orderseries': {'SQL': {}},
                      'dm_buyer': {'SQL': {}}}

        super().load_table()

    def run(self):
        if not hasattr(self, 'dm_orderseries'):
            self.load_table()
        dataframe_orderseries = self.dataframe_dm_orderseries.copy()
        dataframe_tel = self.dataframe_dm_buyer.copy()
        marketing_dm = dataframe_orderseries[['buyerId',
                                              'orderId',
                                              'createdAt',
                                              'productId',
                                              'initTotalKRW',
                                              'initSubtotal',
                                              'initHandlingFee',
                                              'initQualityInspectionFee',
                                              'shippingCost',
                                              'dcHandlingFee',
                                              'dcQualityInspectionFee',
                                              'dcshippingCost',
                                              'countryCode',
                                              'status_order']]
        marketing_dm_kr = marketing_dm[(marketing_dm['countryCode'] == 'KR')]
        marketing_dm_kr = pd.merge(marketing_dm_kr,
                                   Series([100, 200, 201, 202, 300, 400], name='status_order'),
                                   on='status_order')
        marketing_dm_kr = marketing_dm_kr.drop(['status_order'], axis=1)
        marketing_dm_kr = marketing_dm_kr[marketing_dm_kr['productId'].apply(lambda x: len(str(x).split('_')) <= 1)]
        marketing_dm_kr = marketing_dm_kr.drop(['productId'], axis=1)
        marketing_dm_kr.columns = ['바이어 아이디',
                                   '오더 아이디',
                                   '결제일',
                                   '총 결제금액',
                                   '상품금액',
                                   '사입비',
                                   '검수비',
                                   '배송비',
                                   '사입비할인',
                                   '검수비할인',
                                   '배송비할인',
                                   '국가코드']
        marketing_dm_kr['결제일'] = marketing_dm_kr['결제일'].dt.tz_localize('Asia/Seoul')
        marketing_dm_kr = marketing_dm_kr[(marketing_dm_kr['결제일'] >= self.from_date) & (
                marketing_dm_kr['결제일'] < self.to_date)]
        marketing_dm_kr['결제일'] = marketing_dm_kr['결제일'].apply(lambda x: pd.to_datetime(x).date())
        marketing_dm_kr = pd.merge(marketing_dm_kr.groupby(['바이어 아이디',
                                                            '오더 아이디',
                                                            '결제일'])[['총 결제금액',
                                                                     '상품금액',
                                                                     '사입비',
                                                                     '검수비',
                                                                     '사입비할인',
                                                                     '검수비할인']].sum().reset_index(),
                                   marketing_dm_kr[['바이어 아이디',
                                                    '오더 아이디',
                                                    '국가코드',
                                                    '배송비',
                                                    '배송비할인']].drop_duplicates().reset_index(drop=True),
                                   on=['바이어 아이디', '오더 아이디'],
                                   how='right')
        marketing_dm_kr['총 결제금액'] += marketing_dm_kr['배송비'].fillna(0)
        marketing_dm_kr = pd.merge(dataframe_tel[['buyerId', 'phoneNum', 'bizName']].rename({'buyerId': '바이어 아이디',
                                                                                             'phoneNum': '전화번호',
                                                                                             'bizName': '주문자명'},
                                                                                            axis=1),
                                   marketing_dm_kr,
                                   on='바이어 아이디',
                                   how='right')
        self.marketing_dm = marketing_dm_kr.sort_values('결제일').copy()

class ETLCouplingPassBuyer(DataExtractor):
    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, from_date, to_date, client):
        super().__init__(host_ip, DBname, port, username, password, email_id, email_pw, client)
        self.from_date = from_date
        self.from_date_seoul = from_date + ' +0900'
        self.to_date = to_date
        self.to_date_seoul = to_date + ' +0900'

    def load_table(self, demo_test=False):
        self.NOSQL = {'dm_orderseries': {'SQL': {}},
                      'dm_buyer': {'SQL': {}}}

        self.coupling = {
            'SQL': "select \"id\" as discount_promotion_id " + (
                "from tb_discount_promotion ") + (
                       "where ") + (
                       "\"title\" like '%커플링%' AND ") + (
                       f"\"end_at\" >= '{self.from_date_seoul}' AND ") + (
                       f"\"start_at\" < '{self.to_date_seoul}'"),
            'columns': ['discount_promotion_id', ]
        }
        super().load_table()

    def run(self):
        def type_extractor(x, types, recursive=None):
            try:
                if recursive is None:
                    return x[0][types]
                else:
                    return type_extractor([x[0][types]],
                                          types=recursive)
            except:
                return 'NaN'

        if not hasattr(self, 'dataframe_dm_buyer'):
            self.load_table()

        dataframe_orderseries = self.dataframe_dm_orderseries.copy()
        dataframe_buyer = self.dataframe_dm_buyer.copy()

        dataframe_orderseries['createdAt'] = dataframe_orderseries[
            'createdAt'].dt.tz_localize('UTC').dt.tz_convert('Asia/Seoul')
        dataframe_orderseries = dataframe_orderseries[
            (dataframe_orderseries['createdAt'] >= self.from_date) & (
                    dataframe_orderseries['createdAt'] < self.to_date)]
        dataframe_orderseries = dataframe_orderseries[
            dataframe_orderseries['status_order'].apply(
                lambda x: x in [100, 200, 201, 202, 400])].reset_index(drop=True)
        dataframe_orderseries = dataframe_orderseries[
            dataframe_orderseries['productId'].apply(
                lambda x: len(str(x).split('_')) < 2)].reset_index(drop=True)
        discount_id = self.dataframe_coupling['discount_promotion_id'].values.tolist()
        coupling_ind = dataframe_buyer['discount_promotion_id'].dropna().apply(
            lambda x: np.any(list(map(lambda y: y in discount_id, x))))
        coupling_ind = coupling_ind[coupling_ind].index.values
        dm_account = pd.merge(dataframe_orderseries,
                              dataframe_buyer.loc[coupling_ind, 'buyerId'],
                              on='buyerId',
                              how='inner')
        dm_account = dm_account[(dm_account['initQualityInspectionFee'] == 0) & (
                dm_account['shippingCost'] == 0)]
        shipping_cost = dm_account[['orderId',
                                    'shippingCost',
                                    'dcshippingCost',
                                    'tracking_number']].drop_duplicates(['orderId',
                                                                         'shippingCost',
                                                                         'dcshippingCost']).reset_index(drop=True)
        dm_account = dm_account.groupby(['orderId',
                                         'buyerId',
                                         'createdAt'])[['initTotalKRW',
                                                        'initSubtotal',
                                                        'initTax',
                                                        'finalSubtotal',
                                                        'finalTax',
                                                        'finalTotalKRW',
                                                        'initHandlingFee',
                                                        'dcHandlingFee',
                                                        'initQualityInspectionFee',
                                                        'dcQualityInspectionFee',
                                                        'initQuantity',
                                                        'finalQuantity']].sum().reset_index()

        dm_account = pd.merge(dm_account,
                              shipping_cost,
                              on='orderId',
                              how='left')
        dm_account['shipment_num_total'] = dm_account['tracking_number'].apply(
            lambda x: len(x) if not isinstance(x, float) else 0)
        dm_account['shipment_num_unique'] = dm_account['tracking_number'].apply(
            lambda x: len(set(x)) if not isinstance(x, float) else 0)
        dm_account = dm_account.drop('tracking_number', axis=1)
        dm_account = pd.merge(dm_account,
                              dataframe_buyer[['buyerId', 'bizName', 'orderName']],
                              on='buyerId',
                              how='left')
        dm_account.columns = ['order_id',
                              'buyer_id',
                              '주문일',
                              '최초 결제금액',
                              '상품금액',
                              'VAT',
                              '상품금액(최종)',
                              'VAT(최종)',
                              '최종 결제금액',
                              '사입 수수료',
                              '사입 수수료 할인',
                              '검수비',
                              '검수비 할인금액',
                              '주문수량',
                              '최종입고 수량',
                              '배송비',
                              '배송비 할인금액',
                              '오더별 택배발송 개수',
                              '오더별 택배발송 개수(오더별중복제거)',
                              '상호명',
                              '오더명']
        dm_account = dm_account[['order_id',
                                 '주문일',
                                 'buyer_id',
                                 '상호명',
                                 '오더명',
                                 '최초 결제금액',
                                 '상품금액',
                                 'VAT',
                                 '상품금액(최종)',
                                 'VAT(최종)',
                                 '최종 결제금액',
                                 '사입 수수료',
                                 '사입 수수료 할인',
                                 '배송비',
                                 '배송비 할인금액',
                                 '검수비',
                                 '검수비 할인금액',
                                 '주문수량',
                                 '최종입고 수량',
                                 '오더별 택배발송 개수(오더별중복제거)',
                                 '오더별 택배발송 개수']]

        dm_account['주문일'] = dm_account['주문일'].astype('str')
        self.dm_account = dm_account.copy()

class ETLCZeroRatingEvent(DataExtractor):
    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, from_date, to_date, client):
        super().__init__(host_ip, DBname, port, username, password, email_id, email_pw, client)
        self.from_date = from_date
        self.to_date = to_date

    def load_table(self):
        self.NOSQL = {'dm_orderseries': {'SQL': {}}}

        super().load_table()

    def run(self, threshold_membership=1):
        def type_extractor(x, types, recursive=None):
            try:
                if recursive is None:
                    return x[0][types]
                else:
                    return type_extractor([x[0][types]],
                                          types=recursive)
            except:
                return 'NaN'

        if not hasattr(self, 'dataframe_dm_orderseries'):
            self.load_table()

        dataframe_orderseries = self.dataframe_dm_orderseries.copy()

        dataframe_orderseries['createdAt'] = \
            dataframe_orderseries['createdAt'].dt.tz_localize('UTC').dt.tz_convert('Asia/Seoul')

        dm_account = dataframe_orderseries[(
                                                   dataframe_orderseries['createdAt'] >= self.from_date) & (
                                                   dataframe_orderseries['createdAt'] < self.to_date)]
        dm_account = dm_account.reset_index(drop=True)
        dm_account['month'] = \
            dm_account['createdAt'].dt.year.astype('str') + \
            '-' + \
            dm_account['createdAt'].dt.month.astype('str')
        dm_account = dm_account[['buyerId',
                                 'orderId',
                                 'month',
                                 'productId',
                                 'countryCode',
                                 'status_order',
                                 'initTotalKRW',
                                 'initSubtotal',
                                 'initHandlingFee',
                                 'dcHandlingFee',
                                 'initQualityInspectionFee',
                                 'shippingCost',
                                 'finalShippingCost'
                                 ]]
        dm_account = pd.merge(dm_account,
                              Series([100, 200, 201, 202], name='status_order'),
                              on='status_order')
        not_sero = dm_account['productId'].apply(lambda x: len(str(x).split('_')) < 2)
        dm_account = dm_account[not_sero].reset_index(drop=True)
        ids = dm_account[dm_account['dcHandlingFee'] > 0]['buyerId'].unique()
        dm_account = pd.merge(dm_account,
                              Series(ids, name='buyerId'),
                              on='buyerId')
        shipping_cost = dm_account[['buyerId',
                                    'orderId',
                                    'shippingCost',
                                    'finalShippingCost']].drop_duplicates()
        dm_account = dm_account.groupby(['buyerId', 'orderId', 'countryCode', 'month'])[
            ['initTotalKRW',
             'initSubtotal',
             'initHandlingFee',
             'dcHandlingFee',
             'initQualityInspectionFee'
             ]].sum().reset_index()
        dm_account = pd.merge(dm_account, shipping_cost, on=['buyerId', 'orderId'])
        dm_account = dm_account[dm_account['dcHandlingFee'] > 0].reset_index(drop=True)
        dm_account = dm_account.drop('finalShippingCost', axis=1)
        dm_account.columns = ['buyerid',
                              '주문번호',
                              '국가코드',
                              '년-월',
                              '결제금액',
                              '상품금액',
                              '판매수수료',
                              '판매수수료 할인금액',
                              '검수검품비',
                              '배송비']
        dm_account = dm_account[['년-월',
                                 'buyerid',
                                 '주문번호',
                                 '결제금액',
                                 '상품금액',
                                 '판매수수료',
                                 '판매수수료 할인금액',
                                 '검수검품비',
                                 '배송비',
                                 '국가코드']]
        dm_account['결제금액'] += dm_account['배송비']
        dm_account.loc[dm_account['국가코드'] != 'KR', '상품금액'] += \
            dm_account.loc[dm_account['국가코드'] != 'KR', '상품금액'] * 0.1

        self.dm_account = dm_account.copy()

class ETLCouplingPassList(DataExtractor):
    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, from_date, to_date, client):
        super().__init__(host_ip, DBname, port, username, password, email_id, email_pw, client)
        self.from_date = from_date
        self.to_date = to_date

    def load_table(self, demo_test=False):
        self.coupling_pass = {'SQL': "select distinct(value.buyerId)," + (
            "ids.description, ") + (
                                         "ids.discount_promotion_id, ") + (
                                         "value.created_at, ") + (
                                         "ids.start_at, ") + (
                                         "ids.end_at ") + (
                                         "from(") + (
                                         "select \"id\" as discount_promotion_id, ") + (
                                         "\"description\",") + (
                                         "\"start_at\",") + (
                                         "\"end_at\" ") + (
                                         "from tb_discount_promotion ") + (
                                         "where ") + (
                                         # "\"end_at\" > '2022-06-01' and ") + (
                                         "\"title\" like '%커플링%') ids ") + (
                                         "join(") + (
                                         "select \"buyer_id\" as buyerId") + (
                                         ", \"discount_promotion_id\"") + (
                                         ", \"use_yn\"") + (
                                         ", \"created_at\"") + (
                                         "from tb_discount_promotion_target_buyer ") + (
                                         "where \"use_yn\" = 'Y') value ") + (
                                         "on ids.\"discount_promotion_id\"=value.\"discount_promotion_id\""),
                              'columns': ['buyerId',
                                          'description',
                                          'discount_promotion_id',
                                          'createdAt',
                                          'startAt',
                                          'endAt']}
        self.NOSQL = {'dm_buyer': {'SQL': {}}}

        super().load_table()

    def run(self, threshold_membership=1):
        def type_extractor(x, types, recursive=None):
            try:
                if recursive is None:
                    return x[0][types]
                else:
                    return type_extractor([x[0][types]],
                                          types=recursive)
            except:
                return 'NaN'

        if not hasattr(self, 'dataframe_dm_buyer'):
            self.load_table()
        dataframe_coupling = self.dataframe_coupling_pass.copy()
        dataframe_buyer = self.dataframe_dm_buyer.copy()

        dataframe_coupling['createdAt'] = dataframe_coupling['createdAt'].dt.tz_convert('Asia/Seoul')
        dataframe_coupling['startAt'] = dataframe_coupling['startAt'].dt.tz_convert('Asia/Seoul')
        dataframe_coupling['endAt'] = dataframe_coupling['endAt'].dt.tz_convert('Asia/Seoul')

        coupling_list = dataframe_coupling[(dataframe_coupling['endAt'] >= self.from_date) & (
                dataframe_coupling['startAt'] < self.to_date)].drop_duplicates(
            'buyerId').reset_index(drop=True)
        coupling_list = pd.merge(coupling_list[['buyerId', 'description']],
                                 dataframe_buyer[['buyerId', 'name', 'bizName', 'roles']],
                                 on='buyerId',
                                 how='left')
        self.dm_account = coupling_list.copy()


class ETLActiveBuyerList(DataExtractor):
    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, from_date, to_date, client):
        super().__init__(host_ip, DBname, port, username, password, email_id, email_pw, client)
        self.from_date = from_date
        self.to_date = to_date

    def load_table(self, demo_test=False):
        self.NOSQL = {'dm_buyer': {'SQL': {}}}

        super().load_table()

    def run(self, threshold_membership=1):
        def type_extractor(x, types, recursive=None):
            try:
                if recursive is None:
                    return x[0][types]
                else:
                    return type_extractor([x[0][types]],
                                          types=recursive)
            except:
                return 'NaN'

        if not hasattr(self, 'dataframe_dm_buyer'):
            self.load_table()
        dataframe_buyer = self.dataframe_dm_buyer.copy()
        dataframe_buyer_kr = dataframe_buyer[dataframe_buyer['countryCodePlace'] == 'KR'].reset_index(drop=True)
        dataframe_buyer_kr = dataframe_buyer_kr[dataframe_buyer_kr['roles'] == 'buyer']
        dataframe_buyer_kr = dataframe_buyer_kr[dataframe_buyer_kr['isActive']]
        dataframe_buyer_kr = \
            dataframe_buyer_kr[dataframe_buyer_kr['email'].apply(lambda x: x.split('@')[1] != 'linkshops.com')]
        dataframe_buyer_kr = dataframe_buyer_kr[['buyerId',
                                                 'name',
                                                 'orderName',
                                                 'email',
                                                 'bizName',
                                                 'bizNumber',
                                                 'phoneNum',
                                                 'lastLoginAt',
                                                 'createdAt',
                                                 'status']]
        dataframe_buyer_kr.loc[dataframe_buyer_kr['status'] == 100, 'status'] = '활성화'
        dataframe_buyer_kr.columns = ['아이디',
                                      '성명',
                                      '주문명',
                                      '이메일',
                                      '사업자명',
                                      '사업자번호',
                                      '핸드폰',
                                      '최근 접속일',
                                      '가입일자',
                                      '가입상태']

        self.dm_co = dataframe_buyer_kr.copy()