import Buyer, Seller
from pymongo import MongoClient
import time
import pandas as pd
import datetime
from dateutil.relativedelta import relativedelta
import gc
import os

# type1 : 매월 1일 실행

password = '$dpdlvmflf4'
id_mongo = 'vida'
password_mongo = 'qwer123$'
email_id = 'ji.kwon@linkshops.com'
email_pw = 'cjswp25*'

client = MongoClient(host='10.10.224.28',
                     port=27017,
                     username=id_mongo,
                     password=password_mongo)

db_datamart = client['datamart']

# ----- running start ------ #
if __name__ == '__main__':
    current_dir = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.dirname(current_dir) + '/datamart_advanced/datamart_result.txt', mode='r') as f:
        result = f.read()
    if result == 'True':
        time_now = pd.Timestamp(datetime.datetime.now(), tz='UTC')
        time_from = str(datetime.datetime.strptime(str(time_now.date()), '%Y-%m-%d') - relativedelta(months=1)).split('-')
        time_from = time_from[0] + '-' + time_from[1] + '-' + '01'
        time_from_to = str(time_now.date())

        # ---- 월간 바이어 데이터 ----#
        start_time = time.time()

        dm_extractor = Buyer.ETLBuyerDC('restore.cy1gcw3mvrbf.ap-northeast-2.rds.amazonaws.com',
                                        'linkshops',
                                        '5432',
                                        'linkshops',
                                        password,
                                        email_id, email_pw,
                                        time_from, time_from_to,
                                        client)
        dm_extractor.load_table()
        dm_extractor.run()
        dm_extractor.send_email('linkshops_bigdata',
                                f'{current_dir}/email_address/email_BuyerDC.csv',
                                dm_extractor.marketing_dm,
                                f'마케팅_바이어_{time_from}_{time_from_to}')

        # ---- 월간 셀러 데이터 ----#
        time_now = pd.Timestamp(datetime.datetime.now(), tz='UTC')
        time_from = str(datetime.datetime.strptime(str(time_now.date()), '%Y-%m-%d') - relativedelta(months=1)).split('-')
        time_from = time_from[0] + '-' + time_from[1] + '-' + '01'
        time_from_to = str(time_now.date())

        start_time = time.time()
        dm_extractor = Seller.ETLSeller('restore.cy1gcw3mvrbf.ap-northeast-2.rds.amazonaws.com',
                                        'linkshops',
                                        '5432',
                                        'linkshops',
                                        password,
                                        email_id, email_pw,
                                        time_from, time_from_to,
                                        client)
        dm_extractor.load_table()
        dm_extractor.run()
        dm_extractor.send_email('linkshops_bigdata',
                                f'{current_dir}/email_address/email_Seller.csv',
                                dm_extractor.marketing_dm,
                                f'마케팅_셀러_{time_from}_{time_from_to}')
        '''
        start_time = time.time()
        dm_extractor = Seller.ETLGlobalMembership('restore.cy1gcw3mvrbf.ap-northeast-2.rds.amazonaws.com',
                                                  'linkshops',
                                                  '5432',
                                                  'linkshops',
                                                  password,
                                                  email_id, email_pw,
                                                  str(time_now.tz_convert('Asia/Seoul').date()), '',
                                                  client,
                                                  ['0 -> 1', '1 -> 2', '0 -> 2', '2 -> 1']
                                                  )
        dm_extractor.load_table()
        dm_extractor.run()
        dm_extractor.send_email('linkshops_bigdata',
                                f'{current_dir}/email_address/email_globalmembership.csv',
                                dm_extractor.dm_account[dm_extractor.dm_account['날짜'] == time_now.date()],
                                f'회계_월말글로벌멤버십현황_{str(time_now.date())}')
        '''
    else:
        print("Datamart batch code has occured Error before. Please check logs before run ETL codes.")