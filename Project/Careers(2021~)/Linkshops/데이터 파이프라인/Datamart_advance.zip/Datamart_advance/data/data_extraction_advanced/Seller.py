from engine import DataExtractor
import pandas as pd
import numpy as np
from pandas import DataFrame, Series
import datetime
import dateutil
from dateutil.relativedelta import relativedelta
import time
import os

class ETLGlobalSKU(DataExtractor):
    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, from_date, to_date, client):
        super().__init__(host_ip, DBname, port, username, password, email_id, email_pw, client)
        self.from_date = from_date
        self.to_date = to_date

    def load_table(self, demo_test=False):
        self.NOSQL = {'dm_merchandise': {'SQL': {
            'updatedAt_prod': {
                "$gte": dateutil.parser.parse(self.from_date)}}},
            'dm_seller': {'SQL': {}}}
        super().load_table()

    def run(self):
        def type_extractor(x, types, recursive=None):
            try:
                if recursive is None:
                    return x[0][types]
                else:
                    return type_extractor([x[0][types]],
                                          types=recursive)
            except:
                return 'NaN'

        def hasattribute(x, key, second_depth=None):
            if np.any(np.array(list(x.keys())) == key):
                if second_depth is not None:
                    if x[key] is not None:
                        return np.any(np.array(list(x[key].keys())) == second_depth)
                    else:
                        return False
                return True
            return False

        def making_material_info(x, prodid, varid):
            if x is not None:
                if len(x) > 0:
                    current = x['materials']
                    spec_ko = {i['name']['ko']: i['rate'] for i in current}

                    return DataFrame({'productId': prodid,
                                      'variantId': varid,
                                      'material_ko': [spec_ko]})

            return DataFrame({'productId': prodid,
                              'variantId': varid,
                              'material_ko': [None]})

        def making_specific_size(x, prodid, varid):
            if x is not None:
                if len(x) > 0:
                    base = x['rows']
                    spec_ko = [i['name']['ko'] for i in x['columns']]

                    size_ko = [{i['size']: [{k: j} if j is not None else None for j, k in zip(i['values'], spec_ko)]}
                               for i in base]

                    return DataFrame({'productId': prodid,
                                      'variantId': varid,
                                      'size_ko': [size_ko]})

            return DataFrame({'productId': prodid,
                              'variantId': varid,
                              'size_ko': [None]})

        def making_washing_info(x, prodid, varid):
            if x is not None:
                if len(x) > 0:
                    current = x['washingInfos']
                    spec_ko = [i['name']['ko'] for i in current if i['checked']]

                    return DataFrame({'productId': prodid,
                                      'variantId': varid,
                                      'washinfo_ko': [spec_ko]})

            return DataFrame({'productId': prodid,
                              'variantId': varid,
                              'washinfo_ko': [None]})

        def making_fit_info(x, prodid, varid):
            if x is not None:
                if len(x) > 0:
                    current = x['fitInfos']
                    spec_ko = {i: j for i, j in zip([i['name']['ko'] for i in current],
                                                    [[j['name']['ko'] for j in i['items'] if j['checked']] for i in
                                                     current])}

                    return DataFrame({'productId': prodid,
                                      'variantId': varid,
                                      'fitinfo_ko': [spec_ko]})

            return DataFrame({'productId': prodid,
                              'variantId': varid,
                              'fitinfo_ko': [None]})

        if not hasattr(self, 'dataframe_dm_seller'):
            self.load_table()

        marketing_dm_merchandise = self.dataframe_dm_merchandise.copy()
        dataframe_seller = self.dataframe_dm_seller.copy()
        marketing_dm_merchandise['brandId'] = marketing_dm_merchandise['brand'].apply(
            lambda x: type_extractor([x], 'id'))
        marketing_dm_merchandise['brandName'] = marketing_dm_merchandise['brand'].apply(
            lambda x: type_extractor([x], 'name',
                                     recursive='ko'))

        marketing_dm_merchandise['building'] = marketing_dm_merchandise['brand'].apply(
            lambda x: type_extractor([type_extractor([type_extractor([x],
                                                                     'data',
                                                                     recursive='location')],
                                                     'building',
                                                     recursive='name')],
                                     'ko'))
        marketing_dm_merchandise = pd.merge(dataframe_seller.loc[(dataframe_seller['membership'] == 1) & (
                dataframe_seller['membershipStatus'] == 200) & (dataframe_seller['membershipGrade'] == 'black'),
                                                                 'brandId'],
                                            marketing_dm_merchandise,
                                            on='brandId')
        result_material_ko = marketing_dm_merchandise.apply(
            lambda x: making_material_info(x['SKUdata']['data']['specifications'],
                                           x['productId'],
                                           x['variantId'])
            if hasattribute(x['SKUdata']['data'],
                            'specifications',
                            'materials')
            else DataFrame({'productId': x['productId'],
                            'variantId': x['variantId'],
                            'material_ko': [None]}),
            axis=1)
        result_size_ko = marketing_dm_merchandise.apply(
            lambda x: making_specific_size(x['SKUdata']['data']['measurement'],
                                           x['productId'],
                                           x['variantId'])
            if hasattribute(x['SKUdata']['data'],
                            'measurement')
            else DataFrame({'productId': x['productId'],
                            'variantId': x['variantId'],
                            'size_ko': [None]}),
            axis=1)
        result_washing_ko = marketing_dm_merchandise.apply(
            lambda x: making_washing_info(x['SKUdata']['data']['specifications'],
                                          x['productId'],
                                          x['variantId'])
            if hasattribute(x['SKUdata']['data'],
                            'specifications',
                            'washingInfos')
            else DataFrame({'productId': x['productId'],
                            'variantId': x['variantId'],
                            'washinfo_ko': [None]}),
            axis=1)
        result_fit_ko = marketing_dm_merchandise.apply(
            lambda x: making_fit_info(x['SKUdata']['data']['specifications'],
                                      x['productId'],
                                      x['variantId'])
            if hasattribute(x['SKUdata']['data'],
                            'specifications',
                            'fitInfos')
            else DataFrame({'productId': x['productId'],
                            'variantId': x['variantId'],
                            'fitinfo_ko': [None]}),
            axis=1)
        result_size_ko = pd.concat(result_size_ko.values).reset_index(drop=True)
        result_washing_ko = pd.concat(result_washing_ko.values).reset_index(drop=True)
        result_fit_ko = pd.concat(result_fit_ko.values).reset_index(drop=True)
        result_material_ko = pd.concat(result_material_ko.values).reset_index(drop=True)
        result_material_ko[['productId', 'variantId']] = result_material_ko[['productId', 'variantId']].astype('str')
        result_size_ko[['productId', 'variantId']] = result_size_ko[['productId', 'variantId']].astype('str')
        result_washing_ko[['productId', 'variantId']] = result_washing_ko[['productId', 'variantId']].astype('str')
        result_fit_ko[['productId', 'variantId']] = result_fit_ko[['productId', 'variantId']].astype('str')
        result_material_ko.index = result_material_ko['productId'] + ' - ' + result_material_ko['variantId']
        result_size_ko.index = result_size_ko['productId'] + ' - ' + result_size_ko['variantId']
        result_fit_ko.index = result_fit_ko['productId'] + ' - ' + result_fit_ko['variantId']
        result_washing_ko.index = result_washing_ko['productId'] + ' - ' + result_washing_ko['variantId']
        result_material_ko = result_material_ko.drop(['productId', 'variantId'], axis=1)
        result_size_ko = result_size_ko.drop(['productId', 'variantId'], axis=1)
        result_fit_ko = result_fit_ko.drop(['productId', 'variantId'], axis=1)
        result_washing_ko = result_washing_ko.drop(['productId', 'variantId'], axis=1)
        marketing_dm_merchandise.index = marketing_dm_merchandise['productId'].astype('str') + ' - ' + (
            marketing_dm_merchandise['variantId'].astype('str'))
        marketing_dm_merchandise = pd.concat([marketing_dm_merchandise,
                                              result_material_ko,
                                              result_size_ko,
                                              result_fit_ko,
                                              result_washing_ko],
                                             axis=1).reset_index(drop=True)
        marketing_dm_merchandise.loc[~marketing_dm_merchandise['material_ko'].isna(), 'material_xo'] = 'O'
        marketing_dm_merchandise.loc[marketing_dm_merchandise['material_ko'].isna(), 'material_xo'] = 'X'
        marketing_dm_merchandise.loc[~marketing_dm_merchandise['washinfo_ko'].isna(), 'washinfo_xo'] = 'O'
        marketing_dm_merchandise.loc[marketing_dm_merchandise['washinfo_ko'].isna(), 'washinfo_xo'] = 'X'
        marketing_dm_merchandise.loc[~marketing_dm_merchandise['fitinfo_ko'].isna(), 'fitinfo_xo'] = 'O'
        marketing_dm_merchandise.loc[marketing_dm_merchandise['fitinfo_ko'].isna(), 'fitinfo_xo'] = 'X'
        marketing_dm_merchandise['size_xo_tf'] = marketing_dm_merchandise['size_ko'].apply(
            lambda x: [np.any(np.array([j for j in i.values()]) != None) for i in x][0]
            if x is not None
            else None)
        marketing_dm_merchandise.loc[marketing_dm_merchandise['size_xo_tf'].isna(), 'size_xo'] = 'X'
        marketing_dm_merchandise.loc[marketing_dm_merchandise['size_xo_tf'] == False, 'size_xo'] = 'X'
        marketing_dm_merchandise.loc[marketing_dm_merchandise['size_xo_tf'] == True, 'size_xo'] = 'O'
        marketing_dm_merchandise['updatedAt'] = marketing_dm_merchandise['SKUdata'].apply(lambda x: x['updatedAt'])
        marketing_dm_merchandise['createdAt'] = marketing_dm_merchandise['SKUdata'].apply(lambda x: x['createdAt'])
        marketing_dm_merchandise['names'] = marketing_dm_merchandise['SKUdata'].apply(lambda x: x['name']['ko'])
        marketing_dm_merchandise['categoryPath'] = marketing_dm_merchandise['SKUdata'].apply(
            lambda x: ' > '.join(type_extractor(type_extractor([x], 'data', recursive='categoryPath'), 'ko')))
        marketing_dm_merchandise = marketing_dm_merchandise[['productId',
                                                             'names',
                                                             'createdAt',
                                                             'updatedAt',
                                                             'brandId',
                                                             'brandName',
                                                             'building',
                                                             'categoryPath',
                                                             'size_xo',
                                                             'washinfo_xo',
                                                             'fitinfo_xo',
                                                             ]]
        marketing_dm_merchandise.columns = ['productId',
                                            '상품명',
                                            '등록날짜',
                                            '업데이트날짜',
                                            '브랜드 아이디',
                                            '브랜드명',
                                            '상가',
                                            '카테고리',
                                            '사이즈',
                                            '세탁정보',
                                            '피팅정보',
                                            ]
        marketing_dm_merchandise = marketing_dm_merchandise.drop_duplicates(
            subset=['productId']).reset_index(drop=True)
        marketing_dm_merchandise['등록날짜'] = marketing_dm_merchandise['등록날짜'].astype('datetime64').dt.tz_localize('UTC')
        marketing_dm_merchandise['등록날짜'] = marketing_dm_merchandise['등록날짜'].dt.tz_convert('Asia/Seoul')
        marketing_dm_merchandise['등록날짜'] = marketing_dm_merchandise['등록날짜'].apply(lambda x: pd.to_datetime(x).date())
        marketing_dm_merchandise['업데이트날짜'] = marketing_dm_merchandise['업데이트날짜'].astype('datetime64').dt.tz_localize(
            'UTC')
        marketing_dm_merchandise['업데이트날짜'] = marketing_dm_merchandise['업데이트날짜'].dt.tz_convert('Asia/Seoul')
        marketing_dm_merchandise['업데이트날짜'] = marketing_dm_merchandise['업데이트날짜'].apply(
            lambda x: pd.to_datetime(x).date())

        self.marketing_dm = marketing_dm_merchandise

class ETLWeeklyGlobalSeller(DataExtractor):
    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, from_date, to_date, client):
        super().__init__(host_ip, DBname, port, username, password, email_id, email_pw, client)
        self.from_date = from_date
        self.to_date = to_date

    def load_table(self, demo_test=False):
        self.NOSQL = {'dm_orderseries': {'SQL': {}},
                      'dm_seller': {'SQL': {}},
                      'dm_buyer': {'SQL': {}}}
        super().load_table()

    def run(self):
        def type_extractor(x, types, recursive=None):
            try:
                if recursive is None:
                    return x[0][types]
                else:
                    return type_extractor([x[0][types]],
                                          types=recursive)
            except:
                return 'NaN'

        if not hasattr(self, 'dataframe_dm_buyer'):
            self.load_table()

        marketing_dm_seller = self.dataframe_dm_orderseries.copy()
        dataframe_seller = self.dataframe_dm_seller.copy()
        dataframe_buyer = self.dataframe_dm_buyer.copy()

        marketing_dm_seller = pd.merge(marketing_dm_seller,
                                       dataframe_buyer[['buyerId', 'countryCodeShipment']],
                                       on='buyerId')

        tz_tftable = marketing_dm_seller['createdAt'].apply(
            lambda x: (x.tz_localize('UTC') < pd.Timestamp(
                self.to_date, tz='Asia/Seoul').tz_convert('UTC')) & (
                              x.tz_localize('UTC') >= pd.Timestamp(
                          self.from_date, tz='Asia/Seoul').tz_convert('UTC')))
        marketing_dm_seller = marketing_dm_seller[tz_tftable]
        marketing_dm_seller = pd.merge(dataframe_seller.loc[(dataframe_seller['membership'] == 1) & (
                dataframe_seller['membershipStatus'] == 200), 'brandId'],
                                       marketing_dm_seller,
                                       on='brandId')
        marketing_dm_seller = pd.merge(marketing_dm_seller,
                                       Series([100, 101, 102, 200, 201, 202, 203, 300, 400], name='status_order'),
                                       on='status_order')
        marketing_dm_seller = marketing_dm_seller.drop(['status_order'], axis=1)
        marketing_dm_seller = marketing_dm_seller[['orderId',
                                                   'buyerId',
                                                   'buyerName',
                                                   'createdAt',
                                                   'initSubtotal',
                                                   'initQuantity',
                                                   'initTotalKRW',
                                                   'finalSubtotal',
                                                   'finalQuantity',
                                                   'finalTotalKRW',
                                                   'brandId',
                                                   'building',
                                                   'countryCode',
                                                   'countryCodeShipment']]
        marketing_dm_seller.columns = ['orderId',
                                       '사업자ID',
                                       '사업자명',
                                       '구매날짜',
                                       '매출',
                                       '주문량',
                                       '최초',
                                       '최종매출',
                                       '거래량',
                                       '최종',
                                       '브랜드ID',
                                       '상가',
                                       '국가코드',
                                       '국가코드_배송지']
        marketing_dm_seller.loc[marketing_dm_seller['매출'].isna(), '매출'] = (
            marketing_dm_seller.loc[marketing_dm_seller['매출'].isna(), '최초'])
        marketing_dm_seller.loc[marketing_dm_seller['최종매출'].isna(), '최종매출'] = (
            marketing_dm_seller.loc[marketing_dm_seller['최종매출'].isna(), '최종'])

        marketing_dm_seller = pd.merge(marketing_dm_seller.groupby(['orderId',
                                                                    '브랜드ID'])[['매출', '최종매출']].sum().reset_index(),
                                       marketing_dm_seller[['orderId',
                                                            '브랜드ID',
                                                            '구매날짜',
                                                            '국가코드',
                                                            '국가코드_배송지']].drop_duplicates(),
                                       on=['orderId', '브랜드ID'])

        marketing_dm_seller = marketing_dm_seller[['브랜드ID',
                                                   'orderId',
                                                   '구매날짜',
                                                   '매출',
                                                   '최종매출',
                                                   '국가코드',
                                                   '국가코드_배송지']]
        marketing_dm_seller.columns = ['브랜드ID', 'orderId', '구매일자', '매출', '총매출', '국가코드', '국가코드_배송지']
        marketing_dm_seller['구매일자'] = marketing_dm_seller['구매일자'].dt.tz_localize('UTC').dt.tz_convert('Asia/Seoul')
        marketing_dm_seller['구매일자'] = marketing_dm_seller['구매일자'].apply(lambda x: pd.to_datetime(x).date())

        self.marketing_dm = marketing_dm_seller.copy()

class ETLSeller(DataExtractor):

    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, from_date, to_date, client):
        super().__init__(host_ip, DBname, port, username, password, email_id, email_pw, client)
        self.from_date = from_date
        self.to_date = to_date

    def load_table(self):
        self.NOSQL = {'dm_seller' : {'SQL' : {}},
                      'dm_buyer' : {'SQL' : {}},
                      'dm_orderseries' : {'SQL' : {}},
                      }
        super().load_table()

    def run(self):
        def type_extractor(x, types, recursive=None):
            try:
                if recursive is None:
                    return x[0][types]
                else:
                    return type_extractor([x[0][types]],
                                          types=recursive)
            except:
                return 'NaN'

        if not hasattr(self, 'dataframe_dm_orderseries'):
            self.load_table()

        marketing_dm_seller = self.dataframe_dm_orderseries.copy()
        dataframe_seller = self.dataframe_dm_seller.copy()
        dataframe_users = self.dataframe_dm_buyer.copy()
        dataframe_users = dataframe_users[['buyerId','roles']]
        marketing_dm_seller = marketing_dm_seller[['brandId',
                                                   'initTotalKRW',
                                                   'initSubtotal',
                                                   'initHandlingFee',
                                                   'initTax',
                                                   'shippingCost',
                                                   'initQualityInspectionFee',
                                                   'productId',
                                                   'initKRW',
                                                   'initQuantity',
                                                   'buyerId',
                                                   'createdAt',
                                                   'countryCode',
                                                   'orderId',
                                                   'status_order']]
        marketing_dm_seller = pd.merge(marketing_dm_seller,
                                       Series([100, 200, 201, 202, 300, 400], name='status_order'),
                                       on='status_order')
        marketing_dm_seller = marketing_dm_seller.drop(['status_order'], axis=1)
        ind = marketing_dm_seller['productId'].apply(lambda x : len(str(x).split('_')) > 1)
        marketing_dm_seller.loc[ind,'initSubtotal'] = \
        marketing_dm_seller.loc[ind,'initTotalKRW']
        marketing_dm_seller.loc[ind, 'initTotalKRW'] = \
        marketing_dm_seller.loc[ind]['initSubtotal'].fillna(0) + \
        marketing_dm_seller.loc[ind]['initTax'].fillna(0) + \
        marketing_dm_seller.loc[ind]['initHandlingFee'].fillna(0)
        marketing_dm_seller = marketing_dm_seller.drop(['initTax'], axis = 1)
        marketing_dm_seller = pd.merge(marketing_dm_seller,
                                       dataframe_seller[['brandId',
                                                         'membership',
                                                         'membershipGrade']],
                                       on='brandId',
                                       how = 'left')
        marketing_dm_seller = pd.merge(marketing_dm_seller,
                                       dataframe_users,
                                       on='buyerId')
        marketing_dm_seller.loc[marketing_dm_seller['roles'] == 'NaN', 'roles'] = '탈퇴'
        marketing_dm_seller.columns = ['브랜드ID',
                                       '총 결제금액',
                                       '총금액',
                                       '사입수수료',
                                       '배송비',
                                       '검수검품비',
                                       '상품번호',
                                       '상품금액',
                                       '수량',
                                       '사업자ID',
                                       '구매일자',
                                       '국가코드',
                                       '주문번호',
                                       '글로벌셀러/베이직셀러',
                                       '멤버십등급',
                                       '빅바이어/일반바이어/탈퇴',
                                       ]

        marketing_dm_seller = pd.merge(marketing_dm_seller.drop(['총 결제금액', '총금액', '사입수수료'], axis=1),
                                       marketing_dm_seller.groupby('주문번호')[
                                           ['총 결제금액', '총금액', '사입수수료']].sum().reset_index(),
                                       on='주문번호')
        marketing_dm_seller.loc[marketing_dm_seller['글로벌셀러/베이직셀러'] == 1, '글로벌셀러/베이직셀러'] = '글로벌셀러'
        marketing_dm_seller.loc[marketing_dm_seller['글로벌셀러/베이직셀러'] == 0, '글로벌셀러/베이직셀러'] = '베이직셀러'
        marketing_dm_seller.loc[marketing_dm_seller['멤버십등급'].apply(lambda x : len(str(x)) == 0),
                                '멤버십등급'] = '일반'
        # UTC 기준인 데이터마트의 시간을 Asia/Seoul로 변경한다
        marketing_dm_seller['구매일자'] = marketing_dm_seller['구매일자'].dt.tz_localize('UTC').dt.tz_convert('Asia/Seoul')
        marketing_dm_seller = marketing_dm_seller[(marketing_dm_seller['구매일자'] >= self.from_date) & (
                marketing_dm_seller['구매일자'] < self.to_date)]
        marketing_dm_seller['구매일자'] = marketing_dm_seller['구매일자'].apply(lambda x: pd.to_datetime(x).date())
        marketing_dm_seller['총 결제금액'] += marketing_dm_seller['배송비']
        self.marketing_dm = marketing_dm_seller.copy()

class ETLMinimumAndNewer(DataExtractor):
    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, from_date, unit_date, client):
        super().__init__(host_ip, DBname, port, username, password, email_id, email_pw, client)
        self.from_date = from_date
        self.unit_date = unit_date

    def load_table(self, demo_test=False):
        time_now = self.from_date
        time_from = str(datetime.datetime.strptime(str(time_now.date()), '%Y-%m-%d') - (
            relativedelta(days=self.unit_date[0] + 1)))
        self.NOSQL = {'dm_merchandise': {'SQL': {'updatedAt_prod': {
            "$gt": dateutil.parser.parse(time_from)}}},
            'dm_seller': {'SQL': {}}}
        super().load_table()

    def run(self):
        def type_extractor(x, types, recursive=None):
            try:
                if recursive is None:
                    return x[0][types]
                else:
                    return type_extractor([x[0][types]],
                                          types=recursive)
            except:
                return 'NaN'

        if not hasattr(self, 'dataframe_dm_seller'):
            self.load_table()

        dataframe_merchandise = self.dataframe_dm_merchandise.copy()
        dataframe_seller = self.dataframe_dm_seller.copy()
        ind = dataframe_seller['membershipGrade'].apply(lambda x: (len(str(x)) == 0) | (
                Series(x).isna() == True))
        dataframe_seller.loc[np.where(ind)[0], 'membershipGrade'] = '일반'
        dataframe_seller['isglobalmembership'] = (dataframe_seller['membership'] == 1) & (
                dataframe_seller['membershipStatus'] == 200)
        dataframe_seller['isglobalmembership'] = (dataframe_seller['membership'] == 1) & (
                dataframe_seller['membershipStatus'] == 200)
        dataframe_seller.loc[dataframe_seller['isglobalmembership'] == False, 'isglobalmembership'] = '베이직'
        dataframe_seller.loc[dataframe_seller['isglobalmembership'] != '베이직', 'isglobalmembership'] = '글로벌'
        dm_marketing = dataframe_merchandise[['productId',
                                              'SKUdata',
                                              'brand',
                                              'createdAt_prod',
                                              'updatedAt_prod']]
        dm_marketing['brandId'] = dm_marketing['brand'].apply(
            lambda x: type_extractor([x], 'id'))
        dm_marketing['Name'] = dm_marketing['SKUdata'].apply(
            lambda x: type_extractor([x], 'name', recursive='ko'))
        dm_marketing = pd.merge(dm_marketing,
                                dataframe_seller[['brandId',
                                                  'name',
                                                  'building',
                                                  'status_brand',
                                                  'isglobalmembership',
                                                  'membershipGrade']].rename({'status_brand': 'brandStatus',
                                                                              'isglobalmembership': 'basic/global'},
                                                                             axis=1),
                                on='brandId')
        dm_marketing['isminimumquantity'] = dm_marketing['SKUdata'].apply(
            lambda x: type_extractor([x], 'data', recursive='isMinimumQuantity'))

        dm_marketing['productStatus'] = dm_marketing['SKUdata'].apply(
            lambda x: type_extractor([x], 'status'))

        dm_marketing = dm_marketing[(dm_marketing['brandStatus'] != 0) & (dm_marketing['productStatus'] == 100)]
        dm_marketing_minimum = dm_marketing[dm_marketing['isminimumquantity'] == False]

        time_now = self.from_date
        time_from = str(datetime.datetime.strptime(str(time_now.date()), '%Y-%m-%d') - (
            relativedelta(days=self.unit_date[1] + 1)))
        dm_marketing_newseven = dm_marketing[dm_marketing['updatedAt_prod'] >= time_from].reset_index(drop=True)
        dm_marketing_minimum_newseven = pd.concat([dm_marketing_minimum,
                                                   dm_marketing_newseven],
                                                  axis=0)
        dm_marketing_minimum_newseven = dm_marketing_minimum_newseven.drop_duplicates(
            'productId', keep='first').reset_index(drop=True)
        dm_marketing_minimum_newseven.loc[dm_marketing_minimum_newseven['isminimumquantity'] == False,
                                          'isminimumquantity'] = 'O'
        dm_marketing_minimum_newseven.loc[dm_marketing_minimum_newseven['isminimumquantity'] != 'O',
                                          'isminimumquantity'] = 'X'
        dm_marketing_minimum_newseven = dm_marketing_minimum_newseven[['productId',
                                                                       'Name',
                                                                       'createdAt_prod',
                                                                       'updatedAt_prod',
                                                                       'brandId',
                                                                       'name',
                                                                       'basic/global',
                                                                       'membershipGrade',
                                                                       'building',
                                                                       'isminimumquantity']]
        dm_marketing_minimum_newseven.columns = ['productId', '상품명', '등록날짜', '업데이트날짜', '브랜드id', '브랜드명',
                                                 '글로벌셀러/베이직셀러', '멤버십그레이드', '상가', '낱장 가능']
        self.marketing_dm = dm_marketing_minimum_newseven.copy()

class ETLGlobalMembership(DataExtractor):
    def __init__(self,
                 host_ip,
                 DBname,
                 port,
                 username,
                 password,
                 email_id,
                 email_pw,
                 from_date,
                 to_date,
                 client,
                 subscribe):
        super().__init__(host_ip, DBname, port, username, password, email_id, email_pw, client)
        self.time_now = from_date
        self.to_date = to_date
        self.subscribe = subscribe

    def load_table(self, demo_test=False):
        self.NOSQL = {'dm_seller': {'SQL': {}}}
        super().load_table()

    def run(self, threshold_membership=1):
        def type_extractor(x, types, recursive=None):
            try:
                if recursive is None:
                    return x[0][types]
                else:
                    return type_extractor([x[0][types]],
                                          types=recursive)
            except:
                return 'NaN'

        def preprocessing_exception(avgsubperiod_row, date_id, seller_subscribe):
            membershipTerm = date_id.copy()
            membershipTerm['brandId'] = avgsubperiod_row['brandId']
            membershipTerm['group'] = 0
            membershipTerm['historyUpdatedAt'] = np.nan
            membershipTerm['historyUpdatedAtShift'] = np.nan
            membershipTerm['historyUpdatedAtDeriv'] = np.nan
            seller_subscribe = pd.concat([seller_subscribe, membershipTerm])
            return seller_subscribe

        def generating_group_num(init=None):
            if init is None:
                num = 0
            else:
                num = init
            while True:
                num += 1
                yield num

        def processing_for_subscribe_date(x, subscribe_tape, date_id):
            seller_subscribe = DataFrame()
            for num, avgsubperiod_row in x.iterrows():
                date_frame = DataFrame([list(i.values())[0] for i in avgsubperiod_row['membershipHistory']])
                if date_frame.shape[0] > 0:
                    date_frame = pd.concat([date_frame, Series(subscribe_tape[num], name='isBounce')], axis=1)
                    date_frame = pd.concat(
                        [date_frame, Series([list(i.keys())[0] for i in avgsubperiod_row['membershipHistory']],
                                            name='subscribe_type')], axis=1)
                    date_frame['currentMembership'] = avgsubperiod_row['membership']
                    date_frame = date_frame.sort_values('historyUpdatedAtShift')
                    date_frame['historyUpdatedAt'] = date_frame['historyUpdatedAt'].astype('datetime64')
                    date_frame.loc[date_frame['historyUpdatedAtShift'] == 'current', 'historyUpdatedAtShift'] = np.nan
                    date_frame['historyUpdatedAtShift'] = date_frame['historyUpdatedAtShift'].astype('datetime64[ns]')
                    # date_frame = date_frame[date_frame['isBounce'] == False].reset_index(drop=True)
                    date_frame['historyUpdatedAtShift'] = date_frame['historyUpdatedAtShift'].fillna(
                        datetime.datetime.now())
                    date_frame_for_deriv = date_frame[date_frame['isBounce'] == False]
                    date_frame_for_deriv = date_frame_for_deriv.reset_index()
                    if date_frame_for_deriv.shape[0] > 1:
                        startDate_shift = Series(
                            date_frame_for_deriv.loc[1: date_frame_for_deriv.shape[0] - 1,
                            'historyUpdatedAt'].reset_index(drop=True),
                            name='startDate_shift')
                    elif date_frame_for_deriv.shape[0] == 1:
                        startDate_shift = Series(
                            date_frame_for_deriv.reset_index().loc[0, 'historyUpdatedAtShift'],
                            name='startDate_shift')
                    else:
                        seller_subscribe = preprocessing_exception(avgsubperiod_row, date_id, seller_subscribe)
                        continue
                    date_frame_for_deriv = pd.concat([date_frame_for_deriv, startDate_shift], axis=1)
                    if date_frame_for_deriv.loc[date_frame_for_deriv.shape[0] - 1, 'isBounce'] == False:
                        date_frame_for_deriv.loc[date_frame_for_deriv.shape[0] - 1, 'startDate_shift'] = (
                            date_frame_for_deriv.loc[date_frame_for_deriv.shape[0] - 1, 'historyUpdatedAtShift'])
                    if date_frame_for_deriv.shape[0] == 0:
                        seller_subscribe = preprocessing_exception(avgsubperiod_row, date_id, seller_subscribe)

                    TF_frame = DataFrame(
                        {'isSuccessive': (date_frame_for_deriv['startDate_shift'] - date_frame_for_deriv[
                            'historyUpdatedAtShift']) < (
                                             pd.Timedelta(threshold_membership, unit='D')),
                         'isNegative': (date_frame_for_deriv['startDate_shift'] - date_frame_for_deriv[
                             'historyUpdatedAtShift']) < (
                                           pd.Timedelta(0, unit='D'))})
                    date_frame_for_deriv.index = date_frame_for_deriv['index']
                    TF_frame.index = date_frame_for_deriv['index']
                    date_frame_for_deriv = pd.concat([date_frame_for_deriv, TF_frame], axis=1)
                    date_frame_for_deriv['isCurrentAndBounce'] = date_frame_for_deriv['isBounce'].isna()
                    date_frame_isConfirmed = date_frame[
                        (date_frame['historyUpdatedAtDeriv'].isna()) & (date_frame['isBounce'])]
                    date_frame_isConfirmed = date_frame_isConfirmed.reset_index()
                    TF_frame = DataFrame({'isConfirmed': date_frame_isConfirmed['subscribe_type'].apply(
                        lambda x: str(float(x.split(' -> ')[-1])) == \
                                  str(date_frame_isConfirmed['currentMembership'].values[0]))})
                    if date_frame_isConfirmed.shape[0] >= 1:
                        date_frame_isConfirmed.index = date_frame_isConfirmed['index']
                        TF_frame.index = date_frame_isConfirmed['index']
                    date_frame_isConfirmed = pd.concat([date_frame_isConfirmed, TF_frame], axis=1).reset_index(
                        drop=True)
                    date_frame_temp = pd.concat([date_frame_for_deriv,
                                                 date_frame_isConfirmed], axis=0)
                    date_frame_temp['isCurrentAndBounce'] = date_frame_temp['isBounce'].isna()
                    date_frame_temp[['isSuccessive', 'isNegative']] = \
                        date_frame_temp[['isSuccessive', 'isNegative']].fillna(method='ffill')
                    date_frame_temp['isConfirmed'] = date_frame_temp['isConfirmed'].fillna(False)
                    gen_group_num = generating_group_num()
                    tape = list()
                    group_num = 0
                    for i in date_frame_temp.iterrows():
                        tape.append(group_num)
                        if (i[1]['isSuccessive'] == False) | (
                                i[1]['isNegative'] == True) | (
                                i[1]['isCurrentAndBounce']):
                            group_num = next(gen_group_num)
                    date_frame_temp['group'] = tape
                    date_frame_temp.index = date_frame_temp['index']
                    date_frame_temp = date_frame_temp.drop(['index'], axis=1)
                    date_frame = pd.concat([date_frame,
                                            date_frame_temp[['startDate_shift',
                                                             'isSuccessive',
                                                             'isNegative',
                                                             'isConfirmed',
                                                             'isCurrentAndBounce',
                                                             'group']]
                                            ],
                                           axis=1)
                    date_frame['group'] = date_frame['group'].fillna(method='ffill')
                    date_frame = date_frame.groupby('group').apply(
                        lambda x: pd.concat([x.reset_index().loc[0, ['historyUpdatedAt']],
                                             x.reset_index().loc[len(x) - 1, ['historyUpdatedAtShift',
                                                                              'isBounce',
                                                                              'isConfirmed']]], axis=0))
                    temp = date_frame[['historyUpdatedAt',
                                       'historyUpdatedAtShift']].astype('str').apply(
                        lambda x: (x[1] >= date_id['date']) & (
                                x[0] <= date_id['date']),
                        axis=1)
                    temp.columns = date_id['date']
                    temp.index = date_frame['historyUpdatedAtShift']
                    date_frame = pd.merge(date_frame,
                                          temp.stack().reset_index(name='isoverdate'),
                                          on=['historyUpdatedAtShift'])
                    date_frame = date_frame.sort_values(['date'])
                    date_frame['sellerId'] = avgsubperiod_row['sellerId']
                    date_frame['brandId'] = avgsubperiod_row['brandId']
                    date_frame.sort_values(['historyUpdatedAt',
                                            'historyUpdatedAtShift',
                                            'date'])
                    # historyUpdatedAtShift 값으로  sorting을 했기 때문에, -1은 historyUpdatedAtShift가 가장 마지막인 값을 의미한다
                    seller_subscribe = pd.concat([seller_subscribe, date_frame])
                else:
                    seller_subscribe = preprocessing_exception(avgsubperiod_row, date_id, seller_subscribe)
                    continue

            return seller_subscribe

        if not hasattr(self, 'dataframe_dm_seller'):
            self.load_table()

        dataframe_seller = self.dataframe_dm_seller.copy()
        dataframe_seller = dataframe_seller.dropna(subset=['membershipHistory'])
        dataframe_seller = dataframe_seller[dataframe_seller['membershipHistory'].apply(lambda x: len(x) != 0)]
        self.time_now = pd.Timestamp(str(self.time_now), tz = 'Asia/Seoul')
        date_id = DataFrame({'date': pd.date_range(
            pd.Timestamp('2022-05-01 00:00:00', tz='Asia/Seoul'),
            self.time_now
        ).values
                             })
        date_id['date'] = date_id['date'].dt.tz_localize('UTC').dt.tz_convert('Asia/Seoul')

        # ----- normal ------ #
        isNormal = dataframe_seller['membershipHistory'].apply(
            lambda x: [list(i.keys()) for i in x][0][0] in self.subscribe)
        dataframe_seller_normal = dataframe_seller[isNormal].reset_index(drop=True)
        subscribe_tape = dataframe_seller_normal['membershipHistory'].apply(
            lambda x: [list(i.keys())[0] not in self.subscribe for i in x]
            if not isinstance(x, float) else None)
        ind = pd.concat([dataframe_seller_normal['membershipHistory'].apply(lambda x: [
            list(i.values())[0]['historyUpdatedAtShift'] != 'current'
            for i in x][-1]
        if len(x) > 0 else [False]),
                         subscribe_tape.apply(lambda x: x[-1] == False if len(x) > 0 else False)],
                        axis=1).apply(lambda x: np.all(x), axis=1)
        dataframe_seller_normal.loc[ind, 'membershipHistory'].apply(
            lambda x: x.append({'1 -> 0': {'historyUpdatedAt': list(x[-1].values())[0]['historyUpdatedAtShift'],
                                           'historyUpdatedAtShift': 'current',
                                           'historyUpdatedAtDeriv': np.nan}}))
        subscribe_tape = dataframe_seller_normal['membershipHistory'].apply(
            lambda x: [list(i.keys())[0] not in self.subscribe for i in x]
            if not isinstance(x, float) else None)
        seller_subscribe_normal = processing_for_subscribe_date(dataframe_seller_normal,
                                                                subscribe_tape,
                                                                date_id)
        seller_subscribe_normal = pd.concat([  # 과거 가입자
            seller_subscribe_normal[(seller_subscribe_normal['isBounce'] == False) & (
                    seller_subscribe_normal['isoverdate'] == True)],
            # 이탈 신청 했으니 아직 미승인
            seller_subscribe_normal[(seller_subscribe_normal['isBounce'] == True) & (
                    seller_subscribe_normal['isoverdate'] == True) & (
                                            seller_subscribe_normal['isConfirmed'] == False)]],
            axis=0).reset_index(drop=True)
        # ------ type_2 ------- #
        isType2 = dataframe_seller['membershipHistory'].apply(
            lambda x: [list(i.keys()) for i in x][0][0] not in self.subscribe)
        dataframe_seller_type2 = dataframe_seller[isType2].reset_index(drop=True)
        subscribe_tape = dataframe_seller['membershipHistory'].apply(
            lambda x: [list(i.keys())[0] not in self.subscribe for i in x]
            if not isinstance(x, float) else None)
        ind = pd.concat([dataframe_seller_type2['membershipHistory'].apply(lambda x: [
            list(i.values())[0]['historyUpdatedAtShift'] != 'current'
            for i in x][-1]
        if len(x) > 0 else [False]),
                         subscribe_tape.apply(lambda x: x[-1] == False if len(x) > 0 else False)],
                        axis=1).apply(lambda x: np.all(x), axis=1)
        dataframe_seller_type2.loc[ind, 'membershipHistory'].apply(
            lambda x: x.append({'1 -> 0': {'historyUpdatedAt': list(x[-1].values())[0]['historyUpdatedAtShift'],
                                           'historyUpdatedAtShift': 'current',
                                           'historyUpdatedAtDeriv': np.nan}}))
        subscribe_tape = dataframe_seller_type2['membershipHistory'].apply(
            lambda x: [list(i.keys())[0] not in self.subscribe for i in x]
            if not isinstance(x, float) else None)
        seller_subscribe_type2 = processing_for_subscribe_date(dataframe_seller_type2,
                                                               subscribe_tape,
                                                               date_id)
        seller_subscribe_type2 = pd.concat([  # 과거 가입자
            seller_subscribe_type2[(seller_subscribe_type2['isBounce'] == False) & (
                    seller_subscribe_type2['isoverdate'] == True)],
            # 이탈 신청 했으니 아직 미승인
            seller_subscribe_type2[(seller_subscribe_type2['isBounce'] == True) & (
                    seller_subscribe_type2['isoverdate'] == True) & (
                                           seller_subscribe_type2['isConfirmed'] == False)]],
            axis=0).reset_index(drop=True)
        dataframe_seller_type4 = self.dataframe_dm_seller[(self.dataframe_dm_seller['membershipHistory'].isna()) & (
                self.dataframe_dm_seller['membership'] == 1) & (
                                                                  self.dataframe_dm_seller[
                                                                      'membershipStatus'] == 200) & (
                                                                  self.dataframe_dm_seller['status_brand'] != 0)]
        dataframe_seller_type4 = dataframe_seller_type4[['sellerId', 'brandId']]
        dataframe_seller_type4['historyUpdatedAt'] = np.nan
        dataframe_seller_type4['date'] = pd.Timestamp(self.time_now.date(), tz='Asia/Seoul')

        # -----preprocessing-------#

        dm_account_global = pd.concat([seller_subscribe_normal,
                                       seller_subscribe_type2,
                                       dataframe_seller_type4])
        dm_account_global = pd.merge(dm_account_global,
                                     self.dataframe_dm_seller[['brandId',
                                                               'name',
                                                               'building',
                                                               'floor',
                                                               'flatLine',
                                                               'flatNumber',
                                                               'status_brand']],
                                     on='brandId')
        dm_account_global = dm_account_global[['historyUpdatedAt',
                                               'date',
                                               'sellerId',
                                               'brandId',
                                               'name',
                                               'building',
                                               'floor',
                                               'flatLine',
                                               'flatNumber',
                                               'status_brand']]
        dm_account_global.columns = ['가입일자',
                                     '날짜',
                                     '셀러ID',
                                     '브랜드ID',
                                     '브랜드명',
                                     '상가명',
                                     '층',
                                     '열',
                                     '호',
                                     '브랜드상태']

        dm_account_global.loc[dm_account_global['브랜드상태'] == 100, '브랜드상태'] = '운영중'
        dm_account_global.loc[dm_account_global['브랜드상태'] == 0, '브랜드상태'] = '폐업'
        dm_account_global['날짜'] = dm_account_global['날짜'].dt.date
        self.dm_account = dm_account_global.copy()

class ETLBlackLabelReport(DataExtractor):
    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, prev_date, current_date, client):
        super().__init__(host_ip, DBname, port, username, password, email_id, email_pw, client)
        self.prev_from_date = prev_date[0]
        self.prev_to_date = prev_date[1]
        self.current_from_date = current_date[0]
        self.current_to_date = current_date[1]

    def load_table(self, demo_test=False):
        self.NOSQL = {'dm_orderseries': {'SQL': {}},
                      'dm_seller': {'SQL': {}},
                      'dm_merchandise': {'SQL': [{}, {'productId': 1, 'SKUdata.name': 1}]}}

        self.wishes = {"SQL": "select wis.\"brandId\"" + (
            ", to_char(wis.\"createdAt\" at time zone 'Asia/Seoul', 'YYYY-MM') as yearmon") + (
                                  ", count(*) from wishes wis where ") + (
                                  "wis.status = 100 ") + (
                                  f"and wis.\"createdAt\" between '{self.prev_from_date + ' +0900'}' and ") + (
                                  f"'{self.current_to_date + ' +0900'}'") + (
                                  " GROUP BY wis.\"brandId\", to_char(wis.\"createdAt\" at time zone 'Asia/Seoul', 'YYYY-MM')"),
                       "columns": ['brandId', 'yearmon', 'count']}

        self.wishes_total = {"SQL": "select wis.\"brandId\"" + (
            ", count(*) from wishes wis where ") + (
                                        "wis.status = 100 ") + (
                                        " GROUP BY wis.\"brandId\""),
                             "columns": ['brandId', '누적 위시리스트 추가 횟수']}

        self.brand_favorite = {"SQL": "select tfb.\"brand\"" + (
            ", to_char(tfb.\"created_at\" at time zone 'Asia/Seoul', 'YYYY-MM') as yearmon") + (
                                          ", count(*) from tb_favorite_brand tfb where ") + (
                                          f"tfb.\"created_at\" between '{self.prev_from_date + ' +0900'}' and ") + (
                                          f"'{self.current_to_date + ' +0900'}'") + (
                                          " GROUP BY tfb.\"brand\", to_char(tfb.\"created_at\" at time zone 'Asia/Seoul', 'YYYY-MM')"),
                               "columns": ['brandId', 'yearmon', 'count']}

        self.brand_total = brand_total = {"SQL": "select tfb.\"brand\"" + (
            ", count(*) from tb_favorite_brand tfb") + (
                                                     " GROUP BY tfb.\"brand\""),
                                          "columns": ['brandId', '누적 단골 바이어 등록 수']}

        super().load_table()

        current_dir = os.path.dirname(os.path.abspath(__file__))
        blackalbel_brand = pd.read_csv(f'{current_dir}/init_data/blacklabel_brand.csv')
        self.blackalbel_brand = tuple(blackalbel_brand['brandId'].values)

    def run(self, threshold_membership=1):
        def type_extractor(x, types, recursive=None):
            try:
                if recursive is None:
                    return x[0][types]
                else:
                    return type_extractor([x[0][types]],
                                          types=recursive)
            except:
                return 'NaN'

        def extract_best_country(x, top=3):
            finaltotal = x.groupby('countryCode')['finalSubtotal'].sum()
            ranking = finaltotal.sort_values(
                ascending=False).iloc[0:top].reset_index()
            table = DataFrame()
            for i, j in ranking.iterrows():
                j.index = [f'출고액 {i + 1}위 국가',
                           f'{i + 1}위 국가 출고액 비중']
                j = DataFrame(j).T
                j.index = [0]
                table = pd.concat([table, j], axis=1)
            return table

        def extract_best_product(x, top=3, how='cnt'):
            if how == 'cnt':
                finaltotal = x.groupby(['productName'])['productName'].count()
            if how == 'quantity':
                finaltotal = x.groupby(['productName'])['initQuantity'].sum()
            finaltotal.name = 'count'
            ranking = finaltotal.sort_values(
                ascending=False).iloc[0:top].reset_index()
            table = DataFrame()
            for i, j in ranking.iterrows():
                j.index = [f'판매량 {i + 1}위 상품명',
                           f'판매량 {i + 1}위 상품 판매 수량']
                j = DataFrame(j).T
                j.index = [0]
                table = pd.concat([table, j], axis=1)
            return table

        if not hasattr(self, 'dataframe_brand_favorite'):
            self.load_table()

        start_time = time.time()

        dataframe_merchandise = self.dataframe_dm_merchandise.copy()
        dataframe_orderseries = self.dataframe_dm_orderseries.copy()
        dataframe_seller = self.dataframe_dm_seller.copy()
        dataframe_wishes = self.dataframe_wishes.copy()
        dataframe_wishes_total = self.dataframe_wishes_total.copy()
        dataframe_brand_favor = self.dataframe_brand_favorite.copy()
        dataframe_brand_total = self.dataframe_brand_total.copy()
        blacklabel_brand = self.blackalbel_brand

        dataframe_merchandise = dataframe_merchandise[['productId', 'SKUdata']].drop_duplicates(['productId'])
        dataframe_orderseries['createdAt'] = dataframe_orderseries[
            'createdAt'].dt.tz_localize('UTC').dt.tz_convert('Asia/Seoul')
        dataframe_orderseries = pd.merge(dataframe_seller[['brandId', 'sellerId']],
                                         dataframe_orderseries,
                                         on='brandId',
                                         how='right')
        dm_account = pd.merge(dataframe_orderseries,
                              Series(list(set(dataframe_orderseries['status_order_prod'].unique()).difference([0, -1])),
                                     name='status_order_prod'),
                              on='status_order_prod')
        dm_account = dm_account[dm_account['initKRW'] > 0]
        dm_account.loc[dm_account['initSubtotal'].isna(), 'initSubtotal'] = \
            dm_account.loc[dm_account['initSubtotal'].isna(), 'initTotalKRW']
        dm_account.loc[dm_account['finalSubtotal'].isna(), 'finalSubtotal'] = \
            dm_account.loc[dm_account['finalSubtotal'].isna(), 'finalTotalKRW']
        dataframe_merchandise['productName'] = dataframe_merchandise['SKUdata'].apply(
            lambda x: type_extractor([x], 'name', recursive='ko'))
        dm_account = pd.merge(dm_account,
                              dataframe_merchandise[['productId', 'productName']],
                              on='productId',
                              how='left')
        dm_account = pd.merge(dm_account,
                              Series(blacklabel_brand, name='brandId'),
                              on='brandId')
        prev_month = dm_account[(dm_account['createdAt'] >= self.prev_from_date) & (
                dm_account['createdAt'] < self.prev_to_date)]
        current_month = dm_account[(dm_account['createdAt'] >= self.current_from_date) & (
                dm_account['createdAt'] < self.current_to_date)]
        prev_month_groupby = prev_month.groupby('sellerId')[['initQuantity',
                                                             'finalQuantity',
                                                             'initSubtotal',
                                                             'finalSubtotal']].sum().reset_index()
        prev_month_groupby.columns = ['sellerId',
                                      '전월 주문 수량',
                                      '전월 출고수량',
                                      '전월 주문액',
                                      '전월 출고액']
        current_month_groupby = current_month.groupby('sellerId')[['initQuantity',
                                                                   'finalQuantity',
                                                                   'initSubtotal',
                                                                   'finalSubtotal']].sum().reset_index()
        current_month_groupby.columns = ['sellerId',
                                         '당월 주문 수량',
                                         '당월 출고수량',
                                         '당월 주문액',
                                         '당월 출고액']
        dm_account = pd.merge(prev_month_groupby,
                              current_month_groupby,
                              on='sellerId',
                              how='outer').fillna(0)
        dm_account = pd.merge(dm_account,
                              dataframe_seller[['sellerId', 'name']].drop_duplicates(subset = 'sellerId',
                                                                                     keep = 'last'),
                              on='sellerId',
                              how='left')
        country_ranking = current_month.groupby('sellerId').apply(
            lambda x: extract_best_country(x))
        dm_account = pd.merge(dm_account,
                              country_ranking.reset_index().drop('level_1', axis=1),
                              on='sellerId',
                              how='left')
        product_ranking = current_month.groupby('sellerId').apply(lambda x: extract_best_product(x))
        product_ranking = product_ranking.reset_index().drop('level_1', axis=1)
        dm_account = pd.merge(dm_account,
                              product_ranking,
                              on='sellerId',
                              how='left')

        dataframe_wishes = pd.merge(dataframe_wishes, Series(blacklabel_brand, name='brandId'),
                                    on='brandId')
        dataframe_wishes_total = pd.merge(dataframe_wishes_total, Series(blacklabel_brand, name='brandId'),
                                          on='brandId')
        dataframe_brand_favor = pd.merge(dataframe_brand_favor, Series(blacklabel_brand, name='brandId'),
                                         on='brandId')
        dataframe_brand_total = pd.merge(dataframe_brand_total, Series(blacklabel_brand, name='brandId'),
                                         on='brandId')

        dataframe_wishes = pd.merge(dataframe_seller[['sellerId', 'brandId']], dataframe_wishes,
                                    on='brandId',
                                    how='right')
        dataframe_wishes_total = pd.merge(dataframe_seller[['sellerId', 'brandId']], dataframe_wishes_total,
                                          on='brandId',
                                          how='right')
        dataframe_brand_favor = pd.merge(dataframe_seller[['sellerId', 'brandId']], dataframe_brand_favor,
                                         on='brandId',
                                         how='right')
        dataframe_brand_total = pd.merge(dataframe_seller[['sellerId', 'brandId']], dataframe_brand_total,
                                         on='brandId',
                                         how='right')

        dataframe_wishes = dataframe_wishes.groupby(['sellerId', 'yearmon'])['count'].sum().reset_index()
        dataframe_brand_favor = dataframe_brand_favor.groupby(['sellerId', 'yearmon'])['count'].sum().reset_index()
        dataframe_wishes_total = dataframe_wishes_total.groupby('sellerId')['누적 위시리스트 추가 횟수'].sum().reset_index()

        dataframe_brand_total = dataframe_brand_total.groupby('sellerId')['누적 단골 바이어 등록 수'].sum().reset_index()

        result = dataframe_wishes.pivot(columns=['yearmon'], values=['count'], index=['sellerId'])
        result = result.reset_index()
        result.columns = ['sellerId', '전월 위시리스트 추가 횟수', '당월 위시리스트 추가 횟수']
        result_wishes = result.fillna(0)
        result = dataframe_brand_favor.pivot(columns=['yearmon'], values=['count'], index=['sellerId'])
        result = result.reset_index()
        result.columns = ['sellerId', '전월 단골 바이어 등록 수', '당월 단골 바이어 등록 수']
        result_brand = result.fillna(0)
        temp = pd.merge(result_wishes, result_brand, on='sellerId', how='outer').fillna(0)
        result = pd.merge(dataframe_wishes_total, temp, on='sellerId', how='outer').fillna(0)
        result = pd.merge(dataframe_brand_total, result, on='sellerId', how='outer').fillna(0)
        dm_account = pd.merge(dm_account, result, on='sellerId', how='left')
        dm_account = dm_account.rename({'name': '브랜드명'}, axis=1)
        dm_account['집계기간'] = self.current_from_date.split('-')[0] + '년 ' + \
                             self.current_from_date.split('-')[1] + '월'
        dm_account[['번역처리값',
                    '당월 총 큐레이션 제공 횟수',
                    '전월 대비 당월 주문 금액',
                    '전월 대비 당월 주문액 변화(%)',
                    '전월 대비 당원 주문 수량 변화(건)',
                    '전월',
                    '당월',
                    '전월 대비 당월 출고액 변화(%)',
                    '전월 대비 당월 출고 수량 변화']] = np.nan
        dm_account = dm_account[["브랜드명",
                                 "sellerId",
                                 "집계기간",
                                 "번역처리값",
                                 "당월 총 큐레이션 제공 횟수",
                                 "전월 대비 당월 주문 금액",
                                 "전월 대비 당월 주문액 변화(%)",
                                 "전월 대비 당원 주문 수량 변화(건)",
                                 "전월 주문액",
                                 "전월 주문 수량",
                                 "전월 출고액",
                                 "전월 출고수량",
                                 "당월 주문액",
                                 "당월 주문 수량",
                                 "당월 출고액",
                                 "당월 출고수량",
                                 "전월",
                                 "당월",
                                 "전월 대비 당월 출고액 변화(%)",
                                 "전월 대비 당월 출고 수량 변화",
                                 "전월 위시리스트 추가 횟수",
                                 "당월 위시리스트 추가 횟수",
                                 "누적 위시리스트 추가 횟수",
                                 "전월 단골 바이어 등록 수",
                                 "당월 단골 바이어 등록 수",
                                 "누적 단골 바이어 등록 수",
                                 "출고액 1위 국가",
                                 "1위 국가 출고액 비중",
                                 "출고액 2위 국가",
                                 "2위 국가 출고액 비중",
                                 "출고액 3위 국가",
                                 "3위 국가 출고액 비중",
                                 "판매량 1위 상품명",
                                 "판매량 1위 상품 판매 수량",
                                 "판매량 2위 상품명",
                                 "판매량 2위 상품 판매 수량",
                                 "판매량 3위 상품명",
                                 "판매량 3위 상품 판매 수량"]]
        self.dm_account = dm_account.copy()

class ETLOmittedRefund(DataExtractor):
    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, from_date, to_date, client):
        super().__init__(host_ip, DBname, port, username, password, email_id, email_pw, client)
        self.from_date = from_date
        self.to_date = to_date

    def load_table(self, demo_test=False):
        self.deposit = {'SQL': "select " + (
            "sop.\"orderId\",") + (
                                   "sop.\"orderProductId\",") + (
                                   "sop.\"buyerId\",") + (
                                   "sop.\"brandId\",") + (
                                   "td.\"status\",") + (
                                   "td.\"created_at\"") + (
                                   "from tb_deposit td ") + (
                                   "join settlement_bank_transfers sbt on td.additional_deposit_id = sbt.id ") + (
                                   "join settlement_order_products sop on sop.\"settlementBankTransferId\" = td.additional_deposit_id ") + (
                                   "where td.additional_deposit_type = 200 AND ") + (
                                   f"td.\"created_at\" >= '{self.from_date}'"),
                        'columns': ['orderId',
                                    'orderProductId',
                                    'buyerId',
                                    'brandId',
                                    'status',
                                    'createdAt']}
        self.NOSQL = {'dm_orderseries': {'SQL': {}},
                      'dm_seller': {'SQL': {}}}

        super().load_table()

    def run(self):
        def type_extractor(x, types, recursive=None):
            try:
                if recursive is None:
                    return x[0][types]
                else:
                    return type_extractor([x[0][types]],
                                          types=recursive)
            except:
                return 'NaN'

        if not hasattr(self, 'dataframe_dm_orderseries'):
            self.load_table()

        dataframe_orderseries = self.dataframe_dm_orderseries.copy()
        dataframe_seller = self.dataframe_dm_seller.copy()
        dataframe_deposit = self.dataframe_deposit.copy()

        dataframe_orderseries = \
            dataframe_orderseries[
                (dataframe_orderseries['createdAt'] >= self.from_date) & (
                        dataframe_orderseries['createdAt'] < self.to_date)]

        orderseries = dataframe_orderseries.copy()

        ind = orderseries['productId'].apply(lambda x: len(str(x).split('_')) > 1)
        orderseries.loc[ind, 'initSubtotal'] = \
            orderseries.loc[ind, 'initTotalKRW']
        orderseries.loc[ind, 'initTotalKRW'] = \
            orderseries.loc[ind]['initSubtotal'].fillna(0) + \
            orderseries.loc[ind]['initTax'].fillna(0) + \
            orderseries.loc[ind]['initHandlingFee'].fillna(0)
        orderseries = orderseries.drop(['initTax'], axis=1)

        orderseries['isBulkOrder'] = \
            orderseries['productId'].apply(lambda x: len(str(x).split('_')) > 1)

        orderseries.loc[orderseries['isBulkOrder'], 'finalSubtotal'] = \
            orderseries.loc[orderseries['isBulkOrder'], 'finalTotalKRW']

        orderseries = orderseries[orderseries['initTotalKRW'] != 0].reset_index(drop=True)

        orderseries_refund = \
            orderseries[(orderseries['settledPrice'] > 0) & (
                    orderseries['status_order_prod'] == 400) & (
                                orderseries['settledQuantity'] > 0) & (
                            orderseries['status_order'].apply(lambda x: x not in [0, -1])) & (
                                orderseries['waitShipmentType'] == 100)]

        orderseries_refund = orderseries_refund.reset_index(drop=True)
        orderseries_refund = orderseries_refund[
            orderseries_refund['initQuantity'] != orderseries_refund['finalQuantity']]
        orderseries_refund = orderseries_refund[
            orderseries_refund['finalSubtotal'] != orderseries_refund['settledPrice']]

        dm_account = \
            pd.merge(orderseries_refund,
                     Series(list(set(orderseries_refund['orderProductId']).difference(
                         dataframe_deposit['orderProductId'].unique())),
                         name='orderProductId'),
                     on='orderProductId')
        dm_account['refundNeeded'] = dm_account['settledPrice'] - dm_account['finalSubtotal']
        dm_account = pd.merge(dm_account,
                              dataframe_seller[['sellerId', 'brandId']],
                              on='brandId',
                              how='left')
        dm_account = dm_account[['orderId',
                                 'buyerId',
                                 'sellerId',
                                 'brandId',
                                 'processedDate',
                                 'orderProductId',
                                 'initQuantity',
                                 'finalQuantity',
                                 'settledQuantity',
                                 'finalKRW',
                                 'finalSubtotal',
                                 'settledPrice',
                                 'memo',
                                 'refundNeeded']]
        dm_account.columns = ['주문번호',
                              '바이어 ID',
                              '셀러 ID',
                              '브랜드 ID',
                              'processedDate',
                              '주문상품번호',
                              '주문수량',
                              '최종수량',
                              '정산수량',
                              '단가',
                              '정산되어야할 금액',
                              '실 정산금액',
                              'memo',
                              '미생성 환불 내역']
        self.dm_account = dm_account.copy()

class ETLFireSales(DataExtractor):
    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, from_date, client):
        super().__init__(host_ip, DBname, port, username, password, email_id, email_pw, client)
        self.from_date = from_date

    def load_table(self, demo_test=False):
        # 땡처리 대상 상품 추출
        self.product_sale = {'SQL': "SELECT \"id\"," + (
            "\"name\"->'ko',") + (
                                        "\"status\",") + (
                                        "\"data\",") + (
                                        "\"brand\",") + (
                                        "\"createdAt\",") + (
                                        "\"updatedAt\"") + (
                                        " FROM products WHERE ") + (
                                        "(name->>'ko') like '%sale%' and ") + (
                                        f"\"updatedAt\" >= '{self.from_date}'"),
                             'columns': ['productId',
                                         'Name',
                                         'productStatus',
                                         'SKUdata',
                                         'brand',
                                         'createdAt_prod',
                                         'updatedAt_prod']}
        self.NOSQL = {'dm_seller': {'SQL': {}}}
        super().load_table()

    def run(self):
        def type_extractor(x, types, recursive=None):
            try:
                if recursive is None:
                    return x[0][types]
                else:
                    return type_extractor([x[0][types]],
                                          types=recursive)
            except:
                return 'NaN'

        if not hasattr(self, 'dataframe_dm_seller'):
            self.load_table()

        dataframe_product_sale = self.dataframe_product_sale.copy()
        dataframe_seller = self.dataframe_dm_seller.copy()

        ind = dataframe_seller['membershipGrade'].apply(lambda x: (len(str(x)) == 0) | (
                Series(x).isna() == True))
        dataframe_seller.loc[np.where(ind)[0], 'membershipGrade'] = '일반'
        dataframe_seller['isglobalmembership'] = (dataframe_seller['membership'] == 1) & (
                dataframe_seller['membershipStatus'] == 200)
        dataframe_seller.loc[dataframe_seller['isglobalmembership'] == False, 'isglobalmembership'] = '베이직'
        dataframe_seller.loc[dataframe_seller['isglobalmembership'] != '베이직', 'isglobalmembership'] = '글로벌'
        dm_marketing = dataframe_product_sale[['productId',
                                               'Name',
                                               'SKUdata',
                                               'brand',
                                               'productStatus',
                                               'createdAt_prod',
                                               'updatedAt_prod']]
        dm_marketing['createdAt_prod'] = dm_marketing['createdAt_prod'].dt.tz_convert('Asia/Seoul')
        dm_marketing['updatedAt_prod'] = dm_marketing['updatedAt_prod'].dt.tz_convert('Asia/Seoul')
        dm_marketing['brandId'] = dm_marketing['brand'].apply(
            lambda x: type_extractor([x], 'id'))
        dm_marketing = pd.merge(dm_marketing,
                                dataframe_seller[['brandId',
                                                  'name',
                                                  'building',
                                                  'status_brand',
                                                  'isglobalmembership',
                                                  'membershipGrade']].rename({'status_brand': 'brandStatus',
                                                                              'isglobalmembership': 'basic/global'},
                                                                             axis=1),
                                on='brandId')
        dm_marketing['isminimumquantity'] = dm_marketing['SKUdata'].apply(
            lambda x: type_extractor([x], 'isMinimumQuantity'))
        dm_marketing = dm_marketing[(dm_marketing['brandStatus'] != 0) & (dm_marketing['productStatus'] == 100)]

        dm_marketing_minimum_newseven = dm_marketing.drop_duplicates(
            'productId', keep='first').reset_index(drop=True)
        dm_marketing_minimum_newseven.loc[dm_marketing_minimum_newseven['isminimumquantity'] == False,
                                          'isminimumquantity'] = 'O'
        dm_marketing_minimum_newseven.loc[dm_marketing_minimum_newseven['isminimumquantity'] != 'O',
                                          'isminimumquantity'] = 'X'
        dm_marketing_minimum_newseven = dm_marketing_minimum_newseven[['productId',
                                                                       'Name',
                                                                       'createdAt_prod',
                                                                       'updatedAt_prod',
                                                                       'brandId',
                                                                       'name',
                                                                       'membershipGrade',
                                                                       'building',
                                                                       'isminimumquantity']]
        dm_marketing_minimum_newseven.columns = ['productId', '상품명', '등록날짜', '업데이트날짜', '브랜드id', '브랜드명',
                                                 '멤버십그레이드', '상가', '낱장 가능']
        dm_marketing_minimum_newseven['등록날짜'] = dm_marketing_minimum_newseven['등록날짜'].dt.date
        dm_marketing_minimum_newseven['업데이트날짜'] = dm_marketing_minimum_newseven['업데이트날짜'].dt.date
        self.dm_marketing = dm_marketing_minimum_newseven.copy()

class ETLBlaciLabelBrandList(DataExtractor):
    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, from_date, to_date, client):
        super().__init__(host_ip, DBname, port, username, password, email_id, email_pw, client)
        self.from_date = from_date
        self.to_date = to_date

    def load_table(self, demo_test=False):
        self.NOSQL = {'dm_seller': {'SQL': {}}}

        super().load_table()

    def run(self, threshold_membership=1):
        def type_extractor(x, types, recursive=None):
            try:
                if recursive is None:
                    return x[0][types]
                else:
                    return type_extractor([x[0][types]],
                                          types=recursive)
            except:
                return 'NaN'

        if not hasattr(self, 'dataframe_dm_seller'):
            self.load_table()

        dataframe_seller = self.dataframe_dm_seller.copy()

        blacklabel_brand = \
            dataframe_seller[(dataframe_seller['status_brand'] != 0) & (
                    dataframe_seller['membershipGrade'] == 'black')]
        a = blacklabel_brand['membership_grade_history'].apply(lambda x: x[-1]['일반 -> 블랙라벨'])
        blacklabel_brand['when'] = [pd.Timestamp(i['historyUpdatedAt']) for i in a]

        blacklabel_brand['층열호수'] = blacklabel_brand[['floor', 'flatLine', 'flatNumber']].apply(
            lambda x: '/'.join(x.dropna()), axis=1)
        blacklabel_brand = blacklabel_brand[['sellerId',
                                             'brandId',
                                             'name',
                                             'status_brand',
                                             'mobile',
                                             'phoneNum',
                                             'building',
                                             '층열호수',
                                             'when']]

        blacklabel_brand.columns = ['셀러ID',
                                    '브랜드ID',
                                    '브랜드명',
                                    '브랜드상태',
                                    '핸드폰번호',
                                    '전화번호',
                                    '상가',
                                    '층열호수',
                                    '블랙라벨변경일']

        blacklabel_brand.loc[blacklabel_brand['브랜드상태'] == 100, '브랜드상태'] = '활성화'
        blacklabel_brand.loc[blacklabel_brand['브랜드상태'] == 200, '브랜드상태'] = '판매불가'
        blacklabel_brand.loc[blacklabel_brand['브랜드상태'] == 0, '브랜드상태'] = '폐점'
        blacklabel_brand.loc[:,'블랙라벨변경일'] = blacklabel_brand.loc[:,'블랙라벨변경일'].dt.date.astype('str')
        self.dm_co = blacklabel_brand.copy()

class ETLWeeklyCreatedSKU(DataExtractor):
    def __init__(self, host_ip, DBname, port, username, password, email_id, email_pw, weekly_start_day, client):
        super().__init__(host_ip, DBname, port, username, password, email_id, email_pw, client)
        self.weekly_start_day = weekly_start_day

    def load_table(self, demo_test=False):
        # 땡처리 대상 상품 추출
        self.NOSQL = {'dm_merchandise': {'SQL': [{}, {'productId': 1,
                                                      'SKUdata.name': 1,
                                                      'SKUdata.data.categoryPath': 1,
                                                      'createdAt_prod': 1,
                                                      'updatedAt_prod': 1,
                                                      'brand': 1}]},
                      'dm_seller': {'SQL': {}}}
        super().load_table()

    def run(self):
        def type_extractor(x, types, recursive=None):
            try:
                if recursive is None:
                    return x[0][types]
                else:
                    return type_extractor([x[0][types]],
                                          types=recursive)
            except:
                return 'NaN'

        if not hasattr(self, 'dataframe_dm_seller'):
            self.load_table()

        dataframe_merchandise = self.dataframe_dm_merchandise.copy()
        dataframe_seller = self.dataframe_dm_seller.copy()

        dataframe_merchandise['brandId'] = dataframe_merchandise['brand'].apply(lambda x: type_extractor([x], 'id'))

        dataframe_merchandise['createdAt_prod'] = \
            dataframe_merchandise['createdAt_prod'].dt.tz_localize('UTC').dt.tz_convert('Asia/Seoul')
        dataframe_merchandise['updatedAt_prod'] = \
            dataframe_merchandise['updatedAt_prod'].dt.tz_localize('UTC').dt.tz_convert('Asia/Seoul')
        merchandise_drop_dup = dataframe_merchandise.drop_duplicates('productId').reset_index(drop=True)
        merchandise_drop_dup['createdAt_date'] = merchandise_drop_dup['createdAt_prod'].dt.date
        merchandise_drop_dup['updatedAt_date'] = merchandise_drop_dup['updatedAt_prod'].dt.date
        merchandise_drop_dup['category'] = \
            merchandise_drop_dup['SKUdata'].apply(lambda x: type_extractor(
                type_extractor(
                    [type_extractor([x], 'data')],
                    'categoryPath'),
                'en'))
        merchandise_drop_dup['cat_0'] = merchandise_drop_dup['category'].apply(lambda x: x[0])

        merchandise_drop_dup_createdAt = \
            merchandise_drop_dup.groupby(['brandId', 'createdAt_date'])['productId'].count().reset_index(
                name='SKUCreated')
        merchandise_drop_dup_createdAt['createdAt_date'] = merchandise_drop_dup_createdAt['createdAt_date'].astype(
            'str')
        merchandise_drop_dup_categories = \
            merchandise_drop_dup.groupby(['brandId', 'createdAt_date'])['cat_0'].value_counts().reset_index(
                name='count')
        merchandise_drop_dup_categories = \
            merchandise_drop_dup_categories.pivot_table(index=['brandId', 'createdAt_date'],
                                                        columns='cat_0',
                                                        values='count').reset_index().fillna(0)

        merchandise_drop_dup_categories['createdAt_date'] = merchandise_drop_dup_categories['createdAt_date'].astype(
            'str')
        merchandise_drop_dup_createdAt = \
            pd.merge(merchandise_drop_dup_createdAt,
                     merchandise_drop_dup_categories,
                     on=['brandId', 'createdAt_date'])

        del merchandise_drop_dup_categories
        date_ind = \
            pd.date_range(np.min(merchandise_drop_dup_createdAt['createdAt_date']),
                          np.max(merchandise_drop_dup_createdAt['createdAt_date']))
        temp = DataFrame({'createdAt_date': date_ind})
        temp['createdAt_wd'] = temp['createdAt_date'].apply(lambda x: x.weekday())
        temp['createdAt_date'] = temp['createdAt_date'].astype('str')
        temp.loc[temp['createdAt_wd'] == self.weekly_start_day, 'date_group'] = 1
        temp['date_group'] = temp['date_group'].cumsum().fillna(method='ffill').fillna(0)

        date_group_period = \
            temp.groupby('date_group').apply(
                lambda x: ' ~ '.join([x['createdAt_date'].iloc[0], x['createdAt_date'].iloc[-1]])).reset_index(
                name='period')

        merchandise_drop_dup_createdAt = \
            pd.merge(merchandise_drop_dup_createdAt,
                     temp,
                     on='createdAt_date',
                     how='left')

        value_col = list(set(merchandise_drop_dup_createdAt.columns).difference(['brandId',
                                                                                 'createdAt_wd',
                                                                                 'date_group',
                                                                                 'createdAt_date']))

        merchandise_drop_dup_createdAt = \
            merchandise_drop_dup_createdAt.groupby(['brandId', 'date_group'])[value_col].sum().reset_index()
        merchandise_drop_dup_createdAt = pd.merge(merchandise_drop_dup_createdAt, date_group_period)
        merchandise_drop_dup_createdAt = merchandise_drop_dup_createdAt.drop(['date_group'], axis=1)
        merchandise_drop_dup_updatedAt = \
            pd.concat([merchandise_drop_dup,
                       (merchandise_drop_dup['createdAt_prod'] < merchandise_drop_dup['updatedAt_prod'])],
                      axis=1)
        merchandise_drop_dup_updatedAt = \
            merchandise_drop_dup_updatedAt.groupby(['brandId', 'updatedAt_date'])['productId'].count().reset_index()
        merchandise_drop_dup_updatedAt['updatedAt_date'] = merchandise_drop_dup_updatedAt['updatedAt_date'].astype(
            'str')
        date_ind = pd.date_range(np.min(merchandise_drop_dup_updatedAt['updatedAt_date']),
                                 np.max(merchandise_drop_dup_updatedAt['updatedAt_date']))
        temp = DataFrame({'updatedAt_date': date_ind})
        temp['updatedAt_wd'] = temp['updatedAt_date'].apply(lambda x: x.weekday())
        temp['updatedAt_date'] = temp['updatedAt_date'].astype('str')
        temp.loc[temp['updatedAt_wd'] == self.weekly_start_day, 'date_group'] = 1
        temp['date_group'] = temp['date_group'].cumsum().fillna(method='ffill').fillna(0)

        date_group_period = \
            temp.groupby('date_group').apply(
                lambda x: ' ~ '.join([x['updatedAt_date'].iloc[0], x['updatedAt_date'].iloc[-1]])).reset_index(
                name='period')
        merchandise_drop_dup_updatedAt = pd.merge(merchandise_drop_dup_updatedAt,
                                                  temp,
                                                  on='updatedAt_date',
                                                  how='left')

        merchandise_drop_dup_updatedAt = \
            merchandise_drop_dup_updatedAt.groupby(['brandId', 'date_group'])['productId'].sum().reset_index(
                name='SKUUpdated')
        merchandise_drop_dup_updatedAt = pd.merge(merchandise_drop_dup_updatedAt,
                                                  date_group_period)
        merchandise_drop_dup_updatedAt = merchandise_drop_dup_updatedAt.drop(['date_group'], axis=1)
        marketing_dm_seller = pd.merge(merchandise_drop_dup_createdAt,
                                       merchandise_drop_dup_updatedAt,
                                       on=['brandId', 'period'],
                                       how='outer').fillna(0)

        marketing_dm_seller = \
            marketing_dm_seller[
                ['brandId', 'period', 'SKUCreated', 'SKUUpdated', 'WOMEN', 'MEN', 'KIDS', 'Accessories', 'SHOES',
                 'JEWELRY']]

        marketing_dm_seller.columns = ['브랜드ID',
                                       '기간',
                                       '신규등록 총 상품수',
                                       '끌어올리기 이용횟수',
                                       '여성복 신규등록 상품수',
                                       '남성복 신규등록 상품수',
                                       '아동복 신규등록 상품수',
                                       '잡화 신규등록 상품수',
                                       '신발 신규등록 상품수',
                                       '쥬얼리 신규등록 상품수']

        self.marketing_dm = pd.merge(marketing_dm_seller,
                                     dataframe_seller[['brandId', 'name']].rename({'brandId': '브랜드ID',
                                                                                   'name': '브랜드명'}, axis=1))