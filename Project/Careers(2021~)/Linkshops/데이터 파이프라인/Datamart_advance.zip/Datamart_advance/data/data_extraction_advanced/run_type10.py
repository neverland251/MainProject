import Buyer, Seller
from pymongo import MongoClient
import time
import pandas as pd
import datetime
from dateutil.relativedelta import relativedelta
import gc
import os

# type2 : 매주 월 실행

password = '$dpdlvmflf4'
id_mongo = 'vida'
password_mongo = 'qwer123$'
email_id = 'ji.kwon@linkshops.com'
email_pw = 'cjswp25*'

client = MongoClient(host='10.10.224.28',
                     port=27017,
                     username = id_mongo,
                     password = password_mongo)

db_datamart = client['datamart']

# ----- running start ------ #
if __name__ == '__main__':
    current_dir = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.dirname(current_dir) + '/datamart_advanced/datamart_result.txt', mode='r') as f:
        result = f.read()
    if result == 'True':
        time_now = pd.Timestamp(datetime.datetime.now(), tz='UTC')
        time_from = str(datetime.datetime.strptime(str(time_now.date()), '%Y-%m-%d') - relativedelta(days=30)).split(' ')[0]
        '''
        # ---- 땡처리 기획전 ----#
        start_time = time.time()
        dm_extractor = Seller.ETLFireSales('restore.cy1gcw3mvrbf.ap-northeast-2.rds.amazonaws.com',
                                      'linkshops',
                                      '5432',
                                      'linkshops',
                                      password,
                                      email_id, email_pw,
                                      time_from,
                                      client)
        dm_extractor.load_table()
        dm_extractor.run()
        dm_extractor.send_email('linkshops_bigdata',
                                f'{current_dir}/email_address/email_FireSales.csv',
                                dm_extractor.dm_marketing,
                                f'마케팅_땡처리_{time_now.date()}')
        '''
    else :
        print("Datamart batch code has occured Error before. Please check logs before run ETL codes.")