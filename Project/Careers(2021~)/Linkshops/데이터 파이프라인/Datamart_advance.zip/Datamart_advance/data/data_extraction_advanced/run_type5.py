import Buyer, Seller
from pymongo import MongoClient
import time
import pandas as pd
import datetime
from dateutil.relativedelta import relativedelta
import gc
import os

# type5 : 10일 간격 실행

password = '$dpdlvmflf4'
id_mongo = 'vida'
password_mongo = 'qwer123$'
email_id = 'ji.kwon@linkshops.com'
email_pw = 'cjswp25*'

client = MongoClient(host='10.10.224.28',
                     port=27017,
                     username = id_mongo,
                     password = password_mongo)

db_datamart = client['datamart']

# ----- running start ------ #
if __name__ == '__main__':
    date = pd.Timestamp(datetime.datetime.now())
    lastday_date = date + relativedelta(months = 1)
    lastday = (pd.Timestamp(str(lastday_date.year) + '-' + str(lastday_date.month) + '-01') -\
               pd.Timedelta(days = 1)).day
    if pd.Timestamp(date, tz='UTC').tz_convert('Asia/Seoul').day in [11, 21, lastday]:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        with open(os.path.dirname(current_dir) + '/datamart_advanced/datamart_result.txt', mode='r') as f:
            result = f.read()
        if result == 'True':
            time_now = pd.Timestamp(datetime.datetime.now(), tz='UTC').tz_convert('Asia/Seoul')
            time_from = \
                '-'.join(
                    str(datetime.datetime.strptime(str(time_now.date()), '%Y-%m-%d')).split(' ')[0].split('-')[0:2]) + \
                '-01'
            time_from_to = str(time_now.date())

            # ---- 주글로벌매출 ----#
            start_time = time.time()
            dm_extractor = Buyer.ETLBuyingReport('restore.cy1gcw3mvrbf.ap-northeast-2.rds.amazonaws.com',
                                                        'linkshops',
                                                        '5432',
                                                        'linkshops',
                                                        password,
                                                        email_id, email_pw,
                                                        time_from, time_from_to,
                                                        client)
            dm_extractor.load_table()
            dm_extractor.run()
            dm_extractor.send_email('linkshops_bigdata',
                                    f'{current_dir}/email_address/email_BuyingReport.csv',
                                    dm_extractor.marketing_dm,
                                    f'마케팅_10일간구매리포트_{time_from}_{time_from_to}')

        else:
            print("Datamart batch code has occured Error before. Please check logs before run ETL codes.")
    else :
        print(f"Today is not day 11, 21 or {lastday}.")